/* ─────────────────────────────────────────────────────────
 *  inline-single.mjs
 *  把 dist-single 的 JS / CSS 内联进 HTML，产出可双击打开的单文件离线版
 *
 *  注意：替换时必须用「函数形式」的 replace，
 *  否则打包代码里的 $&、$`、$' 等序列会被当成替换模式，导致代码损坏。
 * ───────────────────────────────────────────────────────── */

import { readFileSync, writeFileSync, rmSync, existsSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';

const DIR = 'dist-single';
const ASSETS = join(DIR, 'assets');

/* Vite 可能把资源放在 dist-single/ 根目录或 assets/ 子目录，两处都找 */
function findAsset(ext) {
  const dirs = [DIR, ASSETS].filter((d) => existsSync(d));
  for (const d of dirs) {
    const hit = readdirSync(d).find((f) => f.endsWith(ext));
    if (hit) return join(d, hit);
  }
  return null;
}

if (!existsSync(join(DIR, 'index.html'))) {
  console.error('✗ 未找到 dist-single/index.html，请先执行 vite build --config vite.config.single.ts');
  process.exit(1);
}

let html = readFileSync(join(DIR, 'index.html'), 'utf8');
const jsPath = findAsset('.js');
const cssPath = findAsset('.css');

if (!jsPath) {
  console.error('✗ 未找到打包后的 JS 文件');
  process.exit(1);
}

/* 转义会提前终止 <script> / <style> 的序列（</script、</style，含无 ">" 的写法） */
const js = readFileSync(jsPath, 'utf8').replace(/<\/script/gi, '<\\/script');
const css = cssPath ? readFileSync(cssPath, 'utf8').replace(/<\/style/gi, '<\\/style') : '';

/* 去掉外链标签（保留 data URI 的 favicon） */
html = html
  .replace(/<script[^>]*src="[^"]*"[^>]*>\s*<\/script>/gi, '')
  .replace(/<link[^>]*rel="(stylesheet|modulepreload)"[^>]*>/gi, '');

/* 关键：用函数返回值做替换，避免 $ 序列被解释 */
if (css) {
  html = html.replace('</head>', () => `  <style>\n${css}\n  </style>\n</head>`);
}
html = html.replace('</body>', () => `  <script>\n${js}\n  </script>\n</body>`);

const OUT = join(DIR, '数智睿测-AI测绘机器人智慧服务平台.html');
writeFileSync(OUT, html, 'utf8');

/* 清理中间产物，只留单文件 */
if (existsSync(ASSETS)) rmSync(ASSETS, { recursive: true, force: true });
if (jsPath) rmSync(jsPath, { force: true });
if (cssPath) rmSync(cssPath, { force: true });
rmSync(join(DIR, 'index.html'), { force: true });

const kb = (statSync(OUT).size / 1024).toFixed(0);
console.log(`✓ 单文件离线版已生成：${OUT}  (${kb} KB)`);
console.log('  双击即可用浏览器打开，无需 Node / 无需本地服务器。');
