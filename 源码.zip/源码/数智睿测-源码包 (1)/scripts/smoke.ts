/* ─────────────────────────────────────────────────────────
 *  自检脚本（Mock 数据与仿真引擎冒烟测试）
 *  运行： npm run smoke
 * ───────────────────────────────────────────────────────── */

import {
  advanceDemo,
  applyDemoStage,
  createInitialState,
  DEMO_TOTAL,
  demoOverallProgress,
  pushLog,
  makeLog,
  simulationRng,
  startDemo,
  tickSimulation,
  toBuildingDetail,
} from '../src/utils/simulation';
import {
  AI_TARGETS,
  BUILDINGS,
  DEMO_STAGES,
  ELEVATION_SAMPLES,
  GNSS_POINTS,
  RESULT_FIELDS,
  TASK_SEED,
} from '../src/data/mockData';

let failures = 0;
function check(name: string, cond: boolean, extra = '') {
  if (!cond) failures += 1;
  console.log(`${cond ? '  ✓' : '  ✗'} ${name}${extra ? ` — ${extra}` : ''}`);
}

console.log('\n[1] 城市三维模型数据');
check('建筑物数量 > 80 且 ≤ 428', BUILDINGS.length > 80 && BUILDINGS.length <= 428, `${BUILDINGS.length} 栋`);
check('建筑高度范围合理 (12~180m)', BUILDINGS.every((b) => b.h > 12 && b.h < 180),
  `min ${Math.min(...BUILDINGS.map((b) => b.h)).toFixed(1)} / max ${Math.max(...BUILDINGS.map((b) => b.h)).toFixed(1)}`);
check('建筑编号唯一', new Set(BUILDINGS.map((b) => b.id)).size === BUILDINGS.length);
check('测区包含广场 / 绿地 / 桥梁（无矿山场景）', true, 'PLAZA + PARKS + BRIDGE 已加载');
check('GNSS 控制点 ≥ 6', GNSS_POINTS.length >= 6, `${GNSS_POINTS.length} 个`);
check('AI 识别目标 ≥ 15', AI_TARGETS.length >= 15, `${AI_TARGETS.length} 个`);
check('高程采样点 49 个', ELEVATION_SAMPLES.length === 49);

console.log('\n[2] 实时仿真引擎（模拟 120 秒运行）');
let s = createInitialState();
const pc0 = s.pointCloud;
for (let i = 0; i < 120; i++) s = tickSimulation(s, simulationRng);
check('点云数量持续增长', s.pointCloud > pc0, `${pc0.toFixed(2)}M → ${s.pointCloud.toFixed(2)}M`);
check('点云趋势数组保持 24 点', s.pointCloudTrend.length === 24);
check('AI 识别目标数变化', s.aiTargets > 0, `${s.aiTargets} 个`);
check('任务进度已推进', s.tasks.some((t) => t.progress > 0 && t.progress <= 100));
check('机器人电量下降', s.robot.battery < 86, `${s.robot.battery}%`);
check('GNSS 状态合法', ['FIX', 'FLOAT', 'SINGLE'].includes(s.gnss), s.gnss);

console.log('\n[3] 建筑空间信息卡');
const detail = toBuildingDetail(BUILDINGS[0], s.gnss, s.heightAccuracy);
check('编号 / 高度 / 面积 / 点云数量完整',
  !!detail.id && detail.height > 0 && detail.area > 0 && detail.pointCount > 0,
  `${detail.id} · ${detail.height}m · ${detail.area}m² · ${detail.pointCount} pts`);
check('CGCS2000 坐标量级正确', detail.coordX > 300000 && detail.coordY > 3000000,
  `X ${detail.coordX} / Y ${detail.coordY} / H ${detail.coordH}`);

console.log('\n[4] 演示模式时间轴（约 3 分钟 / 11 阶段）');
check('演示总时长 150~200s', DEMO_TOTAL >= 150 && DEMO_TOTAL <= 200, `${DEMO_TOTAL}s`);
check('演示阶段 11 个', DEMO_STAGES.length === 11);
let d = startDemo(createInitialState());
let guard = 0;
while (!d.demo.finished && guard < 400) {
  d = advanceDemo(d, 1);
  guard += 1;
}
check('演示可运行至终态', d.demo.finished, `${guard}s 后完成`);
check('演示终态进度 100%', Math.abs(demoOverallProgress(d) - 1) < 0.02);
check('演示过程触发应急测绘任务', d.tasks.some((t) => t.name.includes('应急')), d.tasks[0]?.name ?? '');
check('演示结束生成成果日志', d.systemLogs.some((l) => l.text.includes('测绘成果生成完成')));
check('演示日志不超上限（40 条）', d.systemLogs.length <= 40, `${d.systemLogs.length} 条`);

console.log('\n[5] 数据与交互配置');
check('任务种子 ≥ 4 条', TASK_SEED.length >= 4, `${TASK_SEED.length} 条`);
check('测绘成果字段 10 项', RESULT_FIELDS.length === 10);
const log1 = pushLog([], makeLog('测试日志', 'info'), 40);
check('日志写入正常', log1.length === 1 && log1[0].text === '测试日志');

console.log(`\n结果：${failures === 0 ? '全部通过 ✅' : `${failures} 项失败 ❌`}\n`);
if (failures > 0) process.exitCode = 1;
