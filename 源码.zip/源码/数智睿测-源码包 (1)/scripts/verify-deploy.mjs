/* ─────────────────────────────────────────────────────────
 *  verify-deploy.mjs —— 上线前 / 上线后自检
 *
 *  用法：node scripts/verify-deploy.mjs <URL>
 *  例：  node scripts/verify-deploy.mjs https://shuzhi-ruice.pages.dev
 *
 *  检查：资源是否全部 200（无 404）、控制台是否报错、三维是否真的渲染、
 *        首屏加载页是否正常移除、关键交互元素是否存在。
 *
 *  依赖：puppeteer-core（临时安装：npm i -D puppeteer-core），
 *        并需本机已安装 Chrome / Edge。
 * ───────────────────────────────────────────────────────── */

import puppeteer from 'puppeteer-core';
import { existsSync } from 'node:fs';

const URL_ARG = process.argv[2];
if (!URL_ARG) {
  console.error('用法：node scripts/verify-deploy.mjs <URL>');
  process.exit(1);
}

const CANDIDATES = [
  process.env.CHROME_PATH,
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
  `${process.env.LOCALAPPDATA}\\Google\\Chrome\\Application\\chrome.exe`,
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
].filter(Boolean);
const CHROME = CANDIDATES.find((p) => existsSync(p));
if (!CHROME) {
  console.error('✗ 未找到 Chrome / Edge，可通过环境变量 CHROME_PATH 指定');
  process.exit(1);
}

const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const bad = [];
const errors = [];
const hosts = new Set();

const browser = await puppeteer.launch({
  executablePath: CHROME,
  headless: 'new',
  args: ['--enable-unsafe-swiftshader', '--no-sandbox', '--hide-scrollbars'],
  defaultViewport: { width: 1920, height: 1080 },
});
const page = await browser.newPage();

page.on('console', (m) => m.type() === 'error' && errors.push(`[console] ${m.text()}`));
page.on('pageerror', (e) => errors.push(`[pageerror] ${e.message}`));
page.on('requestfailed', (r) => bad.push(`请求失败 ${r.url()} (${r.failure()?.errorText})`));
page.on('response', (r) => {
  try {
    hosts.add(new URL(r.url()).host);
  } catch {
    /* data: URL */
  }
  if (r.status() >= 400) bad.push(`HTTP ${r.status()}  ${r.url()}`);
});

const t0 = Date.now();
await page.goto(URL_ARG, { waitUntil: 'domcontentloaded', timeout: 60000 });
const splash = await page.evaluate(() => !!document.querySelector('#boot-splash'));
await wait(8000);
const firstPaint = Date.now() - t0;

const state = await page.evaluate(() => {
  const h = window.__DSH_CITY__;
  return {
    title: document.title,
    splashRemoved: !document.querySelector('#boot-splash'),
    panels: document.querySelectorAll('.panel').length,
    canvas: document.querySelectorAll('canvas').length,
    calls: h?.renderer.info.render.calls ?? 0,
    triangles: h?.renderer.info.render.triangles ?? 0,
    buildings: h?.buildingMeshes.length ?? 0,
    buttons: [...document.querySelectorAll('button')].map((b) => b.textContent?.trim()).filter(Boolean),
  };
});

/* 关键元素抽查（以页面可见文本为准） */
const need = ['城市三维', '开始演示', '测绘成果', 'AI语音指令', '智能处理流程'];
const domText = await page.evaluate(() => document.body.innerText);
const missingText = need.filter((t) => !domText.includes(t));

console.log('\n══ 上线自检报告 ══════════════════════════════');
console.log(`地址      : ${URL_ARG}`);
console.log(`标题      : ${state.title}`);
console.log(`首屏耗时  : ${firstPaint} ms（含加载占位页：${splash ? '已显示' : '本地太快未捕捉到'}）`);
console.log(`加载页移除: ${state.splashRemoved ? '✓' : '✗'}`);
console.log(`面板/图表 : ${state.panels} 个面板 / ${state.canvas} 个 canvas`);
console.log(`三维渲染  : drawCalls=${state.calls}  三角面=${state.triangles}  建筑=${state.buildings}`);
console.log(`外部域名  : ${[...hosts].join(', ') || '无（全部本地资源）'}`);
console.log(`关键模块  : ${missingText.length === 0 ? '✓ 全部存在' : '✗ 缺失 ' + missingText.join('/')}`);
console.log(`资源异常  : ${bad.length === 0 ? '✓ 无 404 / 无失败请求' : '✗ ' + bad.length + ' 条'}`);
bad.slice(0, 8).forEach((b) => console.log('   -', b));
console.log(`控制台错误: ${errors.length === 0 ? '✓ 无' : '✗ ' + errors.length + ' 条'}`);
errors.slice(0, 8).forEach((e) => console.log('   -', e));
console.log('══════════════════════════════════════════════\n');

await browser.close();

const ok = bad.length === 0 && errors.length === 0 && state.calls > 0 && state.splashRemoved && missingText.length === 0;
console.log(ok ? '结论：可以直接提交 ✅' : '结论：存在问题，请先修复 ❌');
if (!ok) process.exitCode = 1;
