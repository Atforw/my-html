/* ─────────────────────────────────────────────────────────
 *  serve.mjs —— 零依赖静态服务器（把平台变成固定链接）
 *
 *  用法：
 *    node scripts/serve.mjs dist 8080        # 托管常规构建产物
 *    node scripts/serve.mjs dist-single 8080 # 托管单文件离线版
 *
 *  启动后会打印局域网访问地址，同一 Wi-Fi 下的手机 / 其它电脑可直接打开。
 * ───────────────────────────────────────────────────────── */

import { createServer } from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { join, extname, normalize, sep } from 'node:path';
import { networkInterfaces } from 'node:os';
import { existsSync } from 'node:fs';

const ROOT = process.argv[2] || 'dist';
const PORT = Number(process.env.PORT || process.argv[3] || 8080);

if (!existsSync(ROOT)) {
  console.error(`✗ 目录不存在：${ROOT}`);
  console.error('  请先执行 npm run build（或 npm run build:single）');
  process.exit(1);
}

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.map': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
  '.txt': 'text/plain; charset=utf-8',
  '.md': 'text/plain; charset=utf-8',
};

/** 解析请求路径到磁盘文件，阻止越界访问 */
async function resolveFile(urlPath) {
  let p = decodeURIComponent(urlPath.split('?')[0]);
  if (p === '/' || p === '') p = '/index.html';
  // 单文件离线版目录：目录请求返回其中的 html
  const target = normalize(join(ROOT, p));
  if (!target.startsWith(normalize(ROOT) + sep) && normalize(ROOT) !== target) return null;
  try {
    const st = await stat(target);
    if (st.isDirectory()) {
      for (const name of ['index.html', '数智睿测-AI测绘机器人智慧服务平台.html']) {
        const f = join(target, name);
        try {
          if ((await stat(f)).isFile()) return f;
        } catch {
          /* ignore */
        }
      }
      return null;
    }
    return target;
  } catch {
    return null;
  }
}

const server = createServer(async (req, res) => {
  const reqPath = decodeURIComponent((req.url || '/').split('?')[0]);
  const file = await resolveFile(reqPath);
  if (!file) {
    /* 只有在「无扩展名的前端路由」上才回退到入口页；
       带扩展名的资源（.js/.css/...）缺失必须返回 404，否则会掩盖真实的资源缺失问题 */
    const looksLikeAsset = /\.[a-z0-9]{2,6}$/i.test(reqPath);
    const fallback = looksLikeAsset ? null : await resolveFile('/');
    if (!fallback) {
      res.writeHead(404, { 'Content-Type': MIME['.txt'] });
      res.end('404 Not Found');
      return;
    }
    const html = await readFile(fallback);
    res.writeHead(200, { 'Content-Type': MIME['.html'], 'Cache-Control': 'no-cache' });
    res.end(html);
    return;
  }
  const body = await readFile(file);
  const ext = extname(file).toLowerCase();
  res.writeHead(200, {
    'Content-Type': MIME[ext] || 'application/octet-stream',
    'Cache-Control': ext === '.html' ? 'no-cache' : 'public, max-age=3600',
    'Access-Control-Allow-Origin': '*',
  });
  res.end(body);
});

const ips = Object.values(networkInterfaces())
  .flat()
  .filter((i) => i && i.family === 'IPv4' && !i.internal)
  .map((i) => i.address);

server.listen(PORT, '0.0.0.0', () => {
  console.log('\n  数智睿测 —— 平台链接已就绪');
  console.log('  ─────────────────────────────────────────────');
  console.log(`  本机访问：   http://127.0.0.1:${PORT}/`);
  ips.forEach((ip) => console.log(`  局域网访问： http://${ip}:${PORT}/   ← 手机/其它电脑用这个`));
  console.log(`  托管目录：   ${ROOT}`);
  console.log('  ─────────────────────────────────────────────');
  console.log('  提示：首次被其它设备访问时，Windows 会弹防火墙提示，请勾选「专用网络」并允许。');
  console.log('  按 Ctrl+C 停止服务。\n');
});

server.on('error', (e) => {
  if (e.code === 'EADDRINUSE') {
    console.error(`✗ 端口 ${PORT} 已被占用，请换一个端口，例如：node scripts/serve.mjs ${ROOT} 8090`);
  } else {
    console.error('✗ 服务启动失败：', e.message);
  }
  process.exit(1);
});
