import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

/**
 * 单文件离线版构建配置
 * 产物：dist-single/ 下一个自包含 HTML（JS / CSS 全部内联）
 * 可直接双击用浏览器打开，也可拷 U 盘 / 挂任意静态服务器
 */
export default defineConfig({
  plugins: [react()],
  base: './',
  build: {
    outDir: 'dist-single',
    emptyOutDir: true,
    cssCodeSplit: false,
    assetsInlineLimit: 100_000_000,
    modulePreload: false,
    chunkSizeWarningLimit: 4000,
    rollupOptions: {
      output: {
        format: 'iife',
        inlineDynamicImports: true,
        entryFileNames: 'app.js',
        assetFileNames: 'app.[ext]',
      },
    },
  },
});
