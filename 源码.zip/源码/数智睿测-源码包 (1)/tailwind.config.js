/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        base: '#07111F',
        'base-2': '#081422',
        panel: '#0A1729',
        'panel-2': '#0C1E33',
        line: 'rgba(0,194,255,0.16)',
        'line-strong': 'rgba(0,194,255,0.34)',
        primary: '#1677FF',
        cyanx: '#00C2FF',
        success: '#20C997',
        warn: '#FFB020',
        danger: '#FF4D4F',
        ink: '#E6F1FF',
        'ink-2': '#9FB6CE',
        'ink-3': '#6B839C',
      },
      fontFamily: {
        sans: [
          '"Microsoft YaHei"',
          '"PingFang SC"',
          '"Hiragino Sans GB"',
          'system-ui',
          'sans-serif',
        ],
        num: ['"Rajdhani"', 'Consolas', '"SF Mono"', 'ui-monospace', 'monospace'],
      },
      fontSize: {
        '2xs': ['10px', '13px'],
        '3xs': ['9px', '12px'],
      },
      boxShadow: {
        panel: '0 0 0 1px rgba(0,194,255,0.10), 0 6px 22px -12px rgba(0,0,0,0.9)',
        glow: '0 0 12px rgba(0,194,255,0.35)',
      },
      keyframes: {
        blink: {
          '0%,100%': { opacity: '1' },
          '50%': { opacity: '0.25' },
        },
        pulseRing: {
          '0%': { transform: 'scale(0.7)', opacity: '0.8' },
          '100%': { transform: 'scale(1.9)', opacity: '0' },
        },
        scanline: {
          '0%': { transform: 'translateY(-100%)' },
          '100%': { transform: 'translateY(1200%)' },
        },
        sweep: {
          '0%': { transform: 'translateX(-100%)' },
          '100%': { transform: 'translateX(220%)' },
        },
        floatY: {
          '0%,100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-3px)' },
        },
        fadeUp: {
          '0%': { opacity: '0', transform: 'translateY(8px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
      },
      animation: {
        blink: 'blink 1.6s ease-in-out infinite',
        'pulse-ring': 'pulseRing 2s ease-out infinite',
        scanline: 'scanline 6s linear infinite',
        sweep: 'sweep 2.6s ease-in-out infinite',
        'float-y': 'floatY 3s ease-in-out infinite',
        'fade-up': 'fadeUp 0.35s ease-out both',
      },
    },
  },
  plugins: [],
};
