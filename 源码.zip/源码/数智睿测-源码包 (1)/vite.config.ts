import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  // 相对路径：dist 可挂在任意子目录 / 静态服务器下
  base: './',
  server: {
    host: '127.0.0.1',
    port: 5183,
    open: false,
    watch: {
      // 忽略临时文件 / 截图目录，避免 Windows 下文件监听报 EBUSY
      ignored: [
        '**/.git/**',
        '**/node_modules/**',
        '**/dist/**',
        '**/.shots/**',
        '**/.chrome-profile/**',
        '**/.*.tmpdir/**',
        '**/*.tmp',
      ],
    },
  },
  build: {
    chunkSizeWarningLimit: 2000,
  },
});
