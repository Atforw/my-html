/* ─────────────────────────────────────────────────────────
 *  cityScene.ts
 *  三维城市数字孪生场景构建器（Three.js）
 *  —— 城市建筑 / 道路网络 / 城市广场 / 绿地 / 跨江大桥 / 点云 /
 *     GNSS 控制点 / 无人机与机器人轨迹 / AI 识别框 / 高程采样
 * ───────────────────────────────────────────────────────── */

import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import {
  AI_TARGETS,
  BRIDGE,
  BUILDINGS,
  ELEVATION_SAMPLES,
  GNSS_POINTS,
  PARKS,
  PLAZA,
  RIVER,
  ROAD_COORDS,
  ROADS,
  ROBOT_ROUTE,
  UAV_ROUTE,
  mulberry32,
} from '../data/mockData';
import type { BuildingSpec } from '../types';

const WORLD = 1600; // 纹理覆盖范围（米）
const TEX = 2048; // 纹理像素
const K = TEX / WORLD;
const cx = (v: number) => (v + WORLD / 2) * K;
const cs = (v: number) => v * K;

export interface CityHandles {
  scene: THREE.Scene;
  camera: THREE.PerspectiveCamera;
  renderer: THREE.WebGLRenderer;
  controls: OrbitControls;
  groups: Record<LayerGroupKey, THREE.Group>;
  buildingMeshes: THREE.Mesh[];
  robot: THREE.Group;
  uav: THREE.Group;
  robotCurve: THREE.CatmullRomCurve3;
  uavCurve: THREE.CatmullRomCurve3;
  robotTrailLine: THREE.Line;
  robotProgressLine: THREE.Line;
  hoverTargets: THREE.Object3D[];
  pickTargets: THREE.Object3D[];
  highlightMaterials: Map<string, THREE.MeshStandardMaterial>;
  selectedId: string | null;
  tween: { from: THREE.Vector3; to: THREE.Vector3; targetFrom: THREE.Vector3; targetTo: THREE.Vector3; t: number; dur: number } | null;
  clock: THREE.Clock;
  pulseRings: THREE.Mesh[];
  rotatingRotors: THREE.Object3D[];
  blinkingLights: THREE.Mesh[];
  pointCloudMat: THREE.PointsMaterial;
  labelSprites: THREE.Sprite[];
  disposed: boolean;
}

export type LayerGroupKey =
  | 'buildings'
  | 'roads'
  | 'pointCloud'
  | 'gnss'
  | 'uavTrail'
  | 'robotTrail'
  | 'aiTargets'
  | 'elevation'
  | 'devices';

/* ═══════════════ 纹理绘制 ═══════════════ */
function newCanvas(size: number) {
  const c = document.createElement('canvas');
  c.width = size;
  c.height = size;
  return c;
}

function roundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

/** 城市底图：街区 / 绿地 / 广场 / 水系 / 基础网格 */
function buildBaseTexture(): THREE.CanvasTexture {
  const c = newCanvas(TEX);
  const ctx = c.getContext('2d')!;
  ctx.fillStyle = '#08131F';
  ctx.fillRect(0, 0, TEX, TEX);

  // 基础网格（50m）
  ctx.lineWidth = 1;
  ctx.strokeStyle = 'rgba(0,194,255,0.055)';
  for (let v = -WORLD / 2; v <= WORLD / 2; v += 50) {
    ctx.beginPath();
    ctx.moveTo(cx(v), 0);
    ctx.lineTo(cx(v), TEX);
    ctx.moveTo(0, cx(v));
    ctx.lineTo(TEX, cx(v));
    ctx.stroke();
  }

  // 城市街区底板
  const half = 13;
  for (let i = 0; i < 5; i++) {
    for (let j = 0; j < 5; j++) {
      const bx = -240 + 120 * i;
      const bz = -240 + 120 * j;
      const x = cx(bx - 47);
      const y = cx(bz - 47);
      const s = cs(94);
      ctx.fillStyle = 'rgba(24,50,78,0.55)';
      roundRect(ctx, x, y, s, s, 4);
      ctx.fill();
      ctx.strokeStyle = 'rgba(0,194,255,0.10)';
      ctx.lineWidth = 1.5;
      ctx.stroke();
    }
  }

  // 南部滨江片区地块
  for (let i = 0; i < 3; i++) {
    const bx = -160 + 160 * i;
    ctx.fillStyle = 'rgba(24,50,78,0.45)';
    roundRect(ctx, cx(bx - 48), cx(560 - 48), cs(96), cs(96), 4);
    ctx.fill();
  }

  // 绿地
  PARKS.forEach((p) => {
    ctx.fillStyle = 'rgba(18,58,42,0.92)';
    roundRect(ctx, cx(p.x - p.w / 2), cx(p.z - p.d / 2), cs(p.w), cs(p.d), 6);
    ctx.fill();
    ctx.strokeStyle = 'rgba(32,201,151,0.22)';
    ctx.lineWidth = 1.6;
    ctx.stroke();
    const r = mulberry32(p.x * 13 + p.z * 7);
    ctx.fillStyle = 'rgba(32,201,151,0.16)';
    for (let n = 0; n < 90; n++) {
      const px = cx(p.x - p.w / 2) + r() * cs(p.w);
      const py = cx(p.z - p.d / 2) + r() * cs(p.d);
      ctx.beginPath();
      ctx.arc(px, py, 2 + r() * 4, 0, Math.PI * 2);
      ctx.fill();
    }
  });

  // 城市广场（含环形铺装）
  ctx.save();
  ctx.beginPath();
  ctx.arc(cx(PLAZA.x), cx(PLAZA.z), cs(PLAZA.radius), 0, Math.PI * 2);
  ctx.fillStyle = 'rgba(30,62,96,0.95)';
  ctx.fill();
  ctx.strokeStyle = 'rgba(0,194,255,0.28)';
  ctx.lineWidth = 2;
  ctx.stroke();
  for (let r = 10; r < PLAZA.radius; r += 10) {
    ctx.beginPath();
    ctx.arc(cx(PLAZA.x), cx(PLAZA.z), cs(r), 0, Math.PI * 2);
    ctx.strokeStyle = `rgba(0,194,255,${0.15 - r * 0.001})`;
    ctx.lineWidth = 1;
    ctx.stroke();
  }
  for (let a = 0; a < Math.PI * 2; a += Math.PI / 8) {
    ctx.beginPath();
    ctx.moveTo(cx(PLAZA.x), cx(PLAZA.z));
    ctx.lineTo(cx(PLAZA.x) + Math.cos(a) * cs(PLAZA.radius), cx(PLAZA.z) + Math.sin(a) * cs(PLAZA.radius));
    ctx.strokeStyle = 'rgba(0,194,255,0.10)';
    ctx.stroke();
  }
  ctx.restore();

  // 城市水系
  ctx.fillStyle = 'rgba(9,42,64,0.98)';
  ctx.fillRect(0, cx(RIVER.cz - RIVER.d / 2), TEX, cs(RIVER.d));
  ctx.strokeStyle = 'rgba(0,194,255,0.20)';
  ctx.lineWidth = 2;
  for (let n = 0; n < 40; n++) {
    const y = cx(RIVER.cz - RIVER.d / 2) + 6 + n * (cs(RIVER.d) / 40);
    ctx.beginPath();
    for (let x = 0; x <= TEX; x += 32) {
      const yy = y + Math.sin((x / TEX) * Math.PI * 8 + n) * 2.2;
      x === 0 ? ctx.moveTo(x, yy) : ctx.lineTo(x, yy);
    }
    ctx.strokeStyle = 'rgba(0,194,255,0.07)';
    ctx.stroke();
  }

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  return tex;
}

/** 道路网络纹理（独立图层，可单独开关） */
function buildRoadTexture(): THREE.CanvasTexture {
  const c = newCanvas(TEX);
  const ctx = c.getContext('2d')!;
  ctx.clearRect(0, 0, TEX, TEX);

  ROADS.forEach((r) => {
    const x = cx(r.cx - r.w / 2);
    const y = cx(r.cz - r.d / 2);
    const w = cs(r.w);
    const h = cs(r.d);
    ctx.fillStyle = r.level === 'main' ? '#1B2938' : '#17222E';
    roundRect(ctx, x, y, w, h, 3);
    ctx.fill();

    // 路缘线
    ctx.strokeStyle = 'rgba(0,194,255,0.20)';
    ctx.lineWidth = 1.6;
    roundRect(ctx, x + 2, y + 2, w - 4, h - 4, 3);
    ctx.stroke();

    // 中心虚线
    const horizontal = r.w > r.d;
    const center = horizontal ? cx(r.cz) : cx(r.cx);
    ctx.setLineDash([cs(9), cs(7)]);
    ctx.strokeStyle = 'rgba(216,180,80,0.50)';
    ctx.lineWidth = 2.2;
    ctx.beginPath();
    if (horizontal) {
      ctx.moveTo(x + cs(8), center);
      ctx.lineTo(x + w - cs(8), center);
    } else {
      ctx.moveTo(center, y + cs(8));
      ctx.lineTo(center, y + h - cs(8));
    }
    ctx.stroke();
    ctx.setLineDash([]);
  });

  // 交叉口斑马线
  ctx.fillStyle = 'rgba(220,235,250,0.30)';
  ROAD_COORDS.forEach((gx) => {
    ROAD_COORDS.forEach((gz) => {
      const hw = 13;
      for (let s = -1; s <= 1; s += 2) {
        for (let n = -4; n <= 4; n++) {
          if (n === 0) continue;
          // 南北向斑马线
          ctx.fillRect(cx(gx + s * (hw + 4)) - cs(3), cx(gz + n * 2.6) - cs(0.7), cs(2.2), cs(1.2));
          // 东西向斑马线
          ctx.fillRect(cx(gx + n * 2.6) - cs(0.7), cx(gz + s * (hw + 4)) - cs(3), cs(1.2), cs(2.2));
        }
      }
    });
  });

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  return tex;
}

/* ═══════════════ Sprite 标签 ═══════════════ */
function makeLabelSprite(
  text: string,
  opts: { color?: string; sub?: string; worldHeight?: number; depthTest?: boolean; bg?: string } = {},
): THREE.Sprite {
  const { color = '#00C2FF', sub, worldHeight = 7, depthTest = true, bg = 'rgba(5,16,29,0.78)' } = opts;
  const fontSize = 32;
  const subSize = 21;
  const pad = 14;
  const probe = document.createElement('canvas').getContext('2d')!;
  probe.font = `600 ${fontSize}px "Microsoft YaHei", sans-serif`;
  const w1 = probe.measureText(text).width;
  let w2 = 0;
  if (sub) {
    probe.font = `500 ${subSize}px "Microsoft YaHei", sans-serif`;
    w2 = probe.measureText(sub).width;
  }
  const W = Math.ceil(Math.max(w1, w2) + pad * 2);
  const H = sub ? 78 : 52;

  const c = document.createElement('canvas');
  c.width = W;
  c.height = H;
  const ctx = c.getContext('2d')!;
  ctx.fillStyle = bg;
  roundRect(ctx, 0.5, 0.5, W - 1, H - 1, 6);
  ctx.fill();
  ctx.strokeStyle = `${color}88`;
  ctx.lineWidth = 1.6;
  ctx.stroke();
  ctx.fillStyle = color;
  ctx.fillRect(0, H * 0.2, 3, H * 0.6);

  ctx.textBaseline = 'middle';
  ctx.font = `600 ${fontSize}px "Microsoft YaHei", sans-serif`;
  ctx.fillStyle = '#E6F1FF';
  ctx.fillText(text, pad, sub ? H * 0.34 : H / 2);
  if (sub) {
    ctx.font = `500 ${subSize}px "Microsoft YaHei", sans-serif`;
    ctx.fillStyle = color;
    ctx.fillText(sub, pad, H * 0.72);
  }

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  const mat = new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false, depthTest });
  const sprite = new THREE.Sprite(mat);
  const h = worldHeight * (H / 52);
  sprite.scale.set((h * W) / H, h, 1);
  return sprite;
}

/* ═══════════════ 场景创建 ═══════════════ */
export function createCityScene(container: HTMLElement): CityHandles {
  const width = container.clientWidth || 1080;
  const height = container.clientHeight || 620;

  const scene = new THREE.Scene();
  scene.background = new THREE.Color('#050e1a');
  scene.fog = new THREE.Fog('#050e1a', 620, 1900);

  const camera = new THREE.PerspectiveCamera(45, width / height, 1, 4200);
  camera.position.set(400, 300, 500);
  camera.lookAt(0, 28, 24);

  const renderer = new THREE.WebGLRenderer({
    antialias: true,
    powerPreference: 'high-performance',
    // 带 ?capture=1 时保留绘图缓冲，便于自动截图 / 汇报留档
    preserveDrawingBuffer:
      typeof window !== 'undefined' && new URLSearchParams(window.location.search).has('capture'),
  });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(width, height);
  renderer.setClearColor('#050e1a', 1);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.05;
  container.appendChild(renderer.domElement);

  const controls = new OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;
  controls.dampingFactor = 0.07;
  controls.maxPolarAngle = 1.42;
  controls.minDistance = 120;
  controls.maxDistance = 1500;
  controls.target.set(0, 28, 24);
  controls.autoRotateSpeed = 0.35;

  /* ── 灯光 ─────────────────────────────────────── */
  scene.add(new THREE.HemisphereLight(0x2f6d9e, 0x061020, 1.05));
  scene.add(new THREE.AmbientLight(0x123049, 1.1));
  const dir = new THREE.DirectionalLight(0xa9dcff, 1.35);
  dir.position.set(320, 520, 260);
  scene.add(dir);
  const rim = new THREE.DirectionalLight(0x00c2ff, 0.45);
  rim.position.set(-420, 220, -380);
  scene.add(rim);

  const groups: Record<LayerGroupKey, THREE.Group> = {
    buildings: new THREE.Group(),
    roads: new THREE.Group(),
    pointCloud: new THREE.Group(),
    gnss: new THREE.Group(),
    uavTrail: new THREE.Group(),
    robotTrail: new THREE.Group(),
    aiTargets: new THREE.Group(),
    elevation: new THREE.Group(),
    devices: new THREE.Group(),
  };
  Object.entries(groups).forEach(([k, g]) => {
    g.name = k;
    scene.add(g);
  });

  /* ── 地面 + 道路 ──────────────────────────────── */
  const baseMat = new THREE.MeshBasicMaterial({ map: buildBaseTexture() });
  const basePlane = new THREE.Mesh(new THREE.PlaneGeometry(WORLD, WORLD), baseMat);
  basePlane.rotation.x = -Math.PI / 2;
  basePlane.position.y = 0;
  groups.buildings.add(basePlane);

  const roadMat = new THREE.MeshBasicMaterial({
    map: buildRoadTexture(),
    transparent: true,
    depthWrite: false,
  });
  const roadPlane = new THREE.Mesh(new THREE.PlaneGeometry(WORLD, WORLD), roadMat);
  roadPlane.rotation.x = -Math.PI / 2;
  roadPlane.position.y = 0.06;
  groups.roads.add(roadPlane);

  /* ── 建筑 ─────────────────────────────────────── */
  const buildingMeshes: THREE.Mesh[] = [];
  const highlightMaterials = new Map<string, THREE.MeshStandardMaterial>();
  const labelSprites: THREE.Sprite[] = [];
  const colorByCategory: Record<BuildingSpec['category'], number> = {
    高层建筑: 0x2f6ea8,
    低层建筑: 0x4a7d8c,
    商业综合体: 0x2c5c9a,
    公共建筑: 0x3b82a8,
  };

  BUILDINGS.forEach((b) => {
    const geom = new THREE.BoxGeometry(b.w, b.h, b.d);
    const color = new THREE.Color(colorByCategory[b.category]);
    color.offsetHSL(0, 0, ((b.pointCount % 97) / 97 - 0.5) * 0.06);
    const mat = new THREE.MeshStandardMaterial({
      color,
      transparent: true,
      opacity: b.landmark ? 0.46 : 0.6,
      metalness: 0.42,
      roughness: 0.42,
      emissive: color.clone().multiplyScalar(0.22),
      depthWrite: true,
    });
    const mesh = new THREE.Mesh(geom, mat);
    mesh.position.set(b.x, b.h / 2, b.z);
    mesh.userData.building = b;
    mat.userData.baseColor = color.clone();
    mat.userData.opacity = mat.opacity;
    buildingMeshes.push(mesh);
    highlightMaterials.set(b.id, mat);
    groups.buildings.add(mesh);

    // 科技感轮廓
    const edges = new THREE.LineSegments(
      new THREE.EdgesGeometry(geom),
      new THREE.LineBasicMaterial({
        color: b.landmark ? 0x7fe3ff : 0x35c6ff,
        transparent: true,
        opacity: b.landmark ? 0.6 : 0.34,
      }),
    );
    edges.position.copy(mesh.position);
    groups.buildings.add(edges);

    // 屋顶面（GIS 俯视可读）
    const roof = new THREE.Mesh(
      new THREE.PlaneGeometry(b.w * 0.96, b.d * 0.96),
      new THREE.MeshBasicMaterial({
        color: b.landmark ? 0x59e0ff : 0x1f7fbf,
        transparent: true,
        opacity: b.landmark ? 0.4 : 0.22,
        depthWrite: false,
      }),
    );
    roof.rotation.x = -Math.PI / 2;
    roof.position.set(b.x, b.h + 0.12, b.z);
    groups.buildings.add(roof);

    if (b.landmark) {
      const beacon = new THREE.Mesh(
        new THREE.SphereGeometry(1.6, 8, 8),
        new THREE.MeshBasicMaterial({ color: 0xff4d4f }),
      );
      beacon.position.set(b.x, b.h + 4, b.z);
      groups.buildings.add(beacon);
    }

    // 少量建筑编号标签，避免界面杂乱
    if (b.landmark || b.h > 100) {
      const label = makeLabelSprite(`BLD-${b.id.split('-')[1]}`, {
        color: '#7FE3FF',
        sub: `${b.category} · ${b.h.toFixed(1)}m`,
        worldHeight: 8,
        depthTest: true,
      });
      label.position.set(b.x, b.h + 16, b.z);
      groups.buildings.add(label);
      labelSprites.push(label);
    }
  });

  /* ── 跨江大桥 ─────────────────────────────────── */
  const bridge = new THREE.Group();
  const deckLen = BRIDGE.to - BRIDGE.from;
  const deck = new THREE.Mesh(
    new THREE.BoxGeometry(BRIDGE.width, 3, deckLen),
    new THREE.MeshStandardMaterial({
      color: 0x2f4a63,
      metalness: 0.5,
      roughness: 0.5,
      transparent: true,
      opacity: 0.85,
    }),
  );
  deck.position.set(BRIDGE.x, BRIDGE.deckY, (BRIDGE.from + BRIDGE.to) / 2);
  bridge.add(deck);
  const deckEdge = new THREE.LineSegments(
    new THREE.EdgesGeometry(new THREE.BoxGeometry(BRIDGE.width, 3, deckLen)),
    new THREE.LineBasicMaterial({ color: 0x63d8ff, transparent: true, opacity: 0.5 }),
  );
  deckEdge.position.copy(deck.position);
  bridge.add(deckEdge);

  [BRIDGE.from + 26, BRIDGE.to - 26].forEach((z) => {
    [-1, 1].forEach((side) => {
      const pylon = new THREE.Mesh(
        new THREE.BoxGeometry(5, BRIDGE.pylonH, 5),
        new THREE.MeshStandardMaterial({ color: 0x3a5f80, metalness: 0.5, roughness: 0.45 }),
      );
      pylon.position.set(BRIDGE.x + side * (BRIDGE.width / 2 + 3), BRIDGE.pylonH / 2, z);
      bridge.add(pylon);
      const top = new THREE.Vector3(pylon.position.x, BRIDGE.pylonH, z);
      const cablePts = [new THREE.Vector3(top.x, top.y, top.z)];
      for (let i = 0; i < 5; i++) {
        cablePts.push(
          new THREE.Vector3(
            BRIDGE.x,
            BRIDGE.deckY + 2.4,
            z + (i - 2) * (deckLen / 12),
          ),
        );
      }
      const cable = new THREE.Line(
        new THREE.BufferGeometry().setFromPoints(cablePts),
        new THREE.LineBasicMaterial({ color: 0x63d8ff, transparent: true, opacity: 0.45 }),
      );
      bridge.add(cable);
    });
  });
  // 桥面照明
  for (let z = BRIDGE.from + 12; z < BRIDGE.to; z += 24) {
    const lamp = new THREE.Mesh(
      new THREE.SphereGeometry(1.1, 6, 6),
      new THREE.MeshBasicMaterial({ color: 0xffd479 }),
    );
    lamp.position.set(BRIDGE.x + BRIDGE.width / 2 - 2, BRIDGE.deckY + 3.6, z);
    bridge.add(lamp);
  }
  groups.buildings.add(bridge);

  /* ── 点云 ─────────────────────────────────────── */
  const pcRnd = mulberry32(20260101);
  const pcPositions: number[] = [];
  const pcColors: number[] = [];
  const cyan = new THREE.Color(0x38d9ff);
  BUILDINGS.forEach((b, idx) => {
    if (idx % 2 === 1) return;
    const n = 90;
    for (let i = 0; i < n; i++) {
      const face = Math.floor(pcRnd() * 4);
      const u = (pcRnd() - 0.5) * 1.02;
      const v = pcRnd() * 1.02;
      let x = b.x;
      let z = b.z;
      if (face === 0) {
        x = b.x + u * b.w;
        z = b.z + (b.d / 2) * 1.05;
      } else if (face === 1) {
        x = b.x + u * b.w;
        z = b.z - (b.d / 2) * 1.05;
      } else if (face === 2) {
        x = b.x + (b.w / 2) * 1.05;
        z = b.z + u * b.d;
      } else {
        x = b.x - (b.w / 2) * 1.05;
        z = b.z + u * b.d;
      }
      const y = Math.min(b.h, v * b.h);
      pcPositions.push(x, y, z);
      const c = cyan.clone().offsetHSL(0, 0, (pcRnd() - 0.5) * 0.35);
      pcColors.push(c.r, c.g, c.b);
    }
  });
  // 地面扫描散点
  for (let i = 0; i < 3400; i++) {
    const x = (pcRnd() - 0.5) * 1100;
    const z = (pcRnd() - 0.5) * 1100;
    const y = pcRnd() * 6;
    pcPositions.push(x, y, z);
    const c = cyan.clone().offsetHSL(pcRnd() * 0.06 - 0.03, 0, (pcRnd() - 0.5) * 0.3);
    pcColors.push(c.r, c.g, c.b);
  }
  const pcGeom = new THREE.BufferGeometry();
  pcGeom.setAttribute('position', new THREE.Float32BufferAttribute(pcPositions, 3));
  pcGeom.setAttribute('color', new THREE.Float32BufferAttribute(pcColors, 3));
  const pointCloudMat = new THREE.PointsMaterial({
    size: 2.3,
    sizeAttenuation: true,
    vertexColors: true,
    transparent: true,
    opacity: 0.85,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
  });
  const pointCloud = new THREE.Points(pcGeom, pointCloudMat);
  groups.pointCloud.add(pointCloud);

  /* ── GNSS 控制点 ──────────────────────────────── */
  const pulseRings: THREE.Mesh[] = [];
  GNSS_POINTS.forEach((p) => {
    const gnss = new THREE.Group();
    const okColor = p.status === 'FIX' ? 0x20c997 : 0xffb020;
    const mast = new THREE.Mesh(
      new THREE.CylinderGeometry(0.5, 0.5, 14, 6),
      new THREE.MeshBasicMaterial({ color: 0x2a6f9e }),
    );
    mast.position.set(p.x, 7, p.z);
    gnss.add(mast);
    const ball = new THREE.Mesh(
      new THREE.SphereGeometry(2.1, 12, 12),
      new THREE.MeshBasicMaterial({ color: okColor }),
    );
    ball.position.set(p.x, 15, p.z);
    gnss.add(ball);
    const ring = new THREE.Mesh(
      new THREE.RingGeometry(5, 7.4, 32),
      new THREE.MeshBasicMaterial({
        color: okColor,
        transparent: true,
        opacity: 0.75,
        side: THREE.DoubleSide,
        depthWrite: false,
      }),
    );
    ring.rotation.x = -Math.PI / 2;
    ring.position.set(p.x, 0.4, p.z);
    gnss.add(ring);
    pulseRings.push(ring);
    const label = makeLabelSprite(p.id, {
      color: p.status === 'FIX' ? '#20C997' : '#FFB020',
      sub: `${p.status} · ${p.satellite}星 · PDOP ${p.pdop}`,
      worldHeight: 6.4,
      depthTest: true,
    });
    label.position.set(p.x, 24, p.z);
    gnss.add(label);
    labelSprites.push(label);
    groups.gnss.add(gnss);
  });

  /* ── 高程采样柱 ───────────────────────────────── */
  ELEVATION_SAMPLES.forEach((s) => {
    const h = Math.max(2, (s.h - 116) * 5.2);
    const t = (s.h - 116) / 20;
    const col = new THREE.Color().setHSL(0.52 - t * 0.42, 0.85, 0.55);
    const pillar = new THREE.Mesh(
      new THREE.CylinderGeometry(0.7, 0.7, h, 5),
      new THREE.MeshBasicMaterial({ color: col, transparent: true, opacity: 0.62 }),
    );
    pillar.position.set(s.x, h / 2, s.z);
    groups.elevation.add(pillar);
    const cap = new THREE.Mesh(
      new THREE.SphereGeometry(1.2, 8, 8),
      new THREE.MeshBasicMaterial({ color: col }),
    );
    cap.position.set(s.x, h + 1, s.z);
    groups.elevation.add(cap);
  });

  /* ── 轨迹线 ───────────────────────────────────── */
  const robotCurve = new THREE.CatmullRomCurve3(
    ROBOT_ROUTE.map((p) => new THREE.Vector3(p.x, p.y, p.z)),
    true,
    'catmullrom',
    0.15,
  );
  const robotPts = robotCurve.getPoints(600);
  const robotTrail = new THREE.Line(
    new THREE.BufferGeometry().setFromPoints(robotPts),
    new THREE.LineBasicMaterial({ color: 0x00c2ff, transparent: true, opacity: 0.45 }),
  );
  groups.robotTrail.add(robotTrail);

  const robotProgress = new THREE.Line(
    new THREE.BufferGeometry().setFromPoints(robotPts),
    new THREE.LineBasicMaterial({ color: 0x7fffd4, transparent: true, opacity: 0.95 }),
  );
  robotProgress.geometry.setDrawRange(0, 2);
  groups.robotTrail.add(robotProgress);

  const uavCurve = new THREE.CatmullRomCurve3(
    UAV_ROUTE.map((p) => new THREE.Vector3(p.x, p.y, p.z)),
    true,
    'catmullrom',
    0.1,
  );
  const uavPts = uavCurve.getPoints(600);
  const uavTrail = new THREE.Line(
    new THREE.BufferGeometry().setFromPoints(uavPts),
    new THREE.LineDashedMaterial({
      color: 0xffb020,
      dashSize: 12,
      gapSize: 8,
      transparent: true,
      opacity: 0.6,
    }),
  );
  uavTrail.computeLineDistances();
  groups.uavTrail.add(uavTrail);
  // 航点
  UAV_ROUTE.forEach((p, i) => {
    const wp = new THREE.Mesh(
      new THREE.OctahedronGeometry(2.6),
      new THREE.MeshBasicMaterial({ color: 0xffb020, transparent: true, opacity: 0.8 }),
    );
    wp.position.set(p.x, p.y, p.z);
    groups.uavTrail.add(wp);
    if (i % 3 === 0) {
      const l = makeLabelSprite(`WP-${String(i + 1).padStart(2, '0')}`, {
        color: '#FFB020',
        sub: `H ${p.y.toFixed(0)}m`,
        worldHeight: 5.4,
      });
      l.position.set(p.x, p.y + 10, p.z);
      groups.uavTrail.add(l);
    }
  });

  /* ── AI 识别目标框 ────────────────────────────── */
  AI_TARGETS.forEach((t) => {
    const geo = new THREE.BoxGeometry(t.size[0], t.size[1], t.size[2]);
    const color = t.kind === 'anomaly' ? 0xff8a3d : t.kind === 'vehicle' ? 0xffd479 : 0x00e0ff;
    const box = new THREE.LineSegments(
      new THREE.EdgesGeometry(geo),
      new THREE.LineBasicMaterial({ color, transparent: true, opacity: 0.85 }),
    );
    box.position.set(t.x, t.y, t.z);
    groups.aiTargets.add(box);
    const label = makeLabelSprite(t.kind === 'anomaly' ? '⚠ 空间异常' : t.label.split(' · ')[1] ?? 'AI 目标', {
      color: t.kind === 'anomaly' ? '#FF8A3D' : '#00E0FF',
      sub: `AI ${(t.confidence * 100).toFixed(1)}% · ${t.id}`,
      worldHeight: 5.2,
      depthTest: false,
    });
    label.position.set(t.x, t.y + t.size[1] / 2 + 6, t.z);
    groups.aiTargets.add(label);
  });

  /* ── 测绘机器人-01 ────────────────────────────── */
  const robot = new THREE.Group();
  const bodyMat = new THREE.MeshStandardMaterial({
    color: 0x1f4f74,
    metalness: 0.75,
    roughness: 0.32,
    emissive: 0x0a3550,
  });
  const body = new THREE.Mesh(new THREE.BoxGeometry(9, 4.4, 13), bodyMat);
  body.position.y = 3.4;
  robot.add(body);
  const mast = new THREE.Mesh(
    new THREE.CylinderGeometry(1.1, 1.1, 7, 8),
    new THREE.MeshStandardMaterial({ color: 0x0e2c44, metalness: 0.6, roughness: 0.4 }),
  );
  mast.position.y = 9;
  robot.add(mast);
  const scanner = new THREE.Mesh(
    new THREE.CylinderGeometry(2.6, 2.6, 1.5, 16),
    new THREE.MeshBasicMaterial({ color: 0x00c2ff, transparent: true, opacity: 0.85 }),
  );
  scanner.position.y = 12.6;
  robot.add(scanner);
  const rotors: THREE.Object3D[] = [];
  rotors.push(scanner);

  // 轮组
  [-1, 1].forEach((sx) => {
    [-4.4, 4.4].forEach((sz) => {
      const wheel = new THREE.Mesh(
        new THREE.CylinderGeometry(1.7, 1.7, 1.2, 12),
        new THREE.MeshStandardMaterial({ color: 0x0a1a28, metalness: 0.3, roughness: 0.8 }),
      );
      wheel.rotation.z = Math.PI / 2;
      wheel.position.set(sx * 4.6, 1.7, sz);
      robot.add(wheel);
    });
  });
  const ring = new THREE.Mesh(
    new THREE.RingGeometry(6.5, 9, 32),
    new THREE.MeshBasicMaterial({
      color: 0x20c997,
      transparent: true,
      opacity: 0.7,
      side: THREE.DoubleSide,
      depthWrite: false,
    }),
  );
  ring.rotation.x = -Math.PI / 2;
  ring.position.y = 0.5;
  robot.add(ring);
  pulseRings.push(ring);
  const robotLabel = makeLabelSprite('测绘机器人-01', {
    color: '#20C997',
    sub: '● 在线 · RTK FIX',
    worldHeight: 9,
    depthTest: false,
  });
  robotLabel.position.set(0, 22, 0);
  robot.add(robotLabel);
  robot.traverse((o) => {
    o.userData.device = 'robot';
  });
  groups.devices.add(robot);

  /* ── 无人机 UAV-02 ────────────────────────────── */
  const uav = new THREE.Group();
  const uavBody = new THREE.Mesh(
    new THREE.BoxGeometry(6.4, 2, 6.4),
    new THREE.MeshStandardMaterial({ color: 0x123247, metalness: 0.7, roughness: 0.35, emissive: 0x08344c }),
  );
  uav.add(uavBody);
  const uavRotors: THREE.Object3D[] = [];
  [
    [3.6, 3.6],
    [-3.6, 3.6],
    [3.6, -3.6],
    [-3.6, -3.6],
  ].forEach(([ax, az]) => {
    const arm = new THREE.Mesh(
      new THREE.BoxGeometry(6.2, 0.5, 0.7),
      new THREE.MeshStandardMaterial({ color: 0x1b4a68, metalness: 0.6, roughness: 0.4 }),
    );
    arm.position.set(ax / 2, 0.6, az / 2);
    arm.rotation.y = Math.atan2(az, ax);
    uav.add(arm);
    const rotor = new THREE.Mesh(
      new THREE.TorusGeometry(2.6, 0.24, 6, 20),
      new THREE.MeshBasicMaterial({ color: 0x8fe8ff, transparent: true, opacity: 0.8 }),
    );
    rotor.rotation.x = -Math.PI / 2;
    rotor.position.set(ax, 1.1, az);
    uav.add(rotor);
    uavRotors.push(rotor);
  });
  const navLight = new THREE.Mesh(
    new THREE.SphereGeometry(0.8, 8, 8),
    new THREE.MeshBasicMaterial({ color: 0xff4d4f }),
  );
  navLight.position.set(0, 1.8, 0);
  uav.add(navLight);
  const uavLabel = makeLabelSprite('UAV-02', {
    color: '#FFB020',
    sub: '测绘作业中 · H 168m',
    worldHeight: 8,
    depthTest: false,
  });
  uavLabel.position.set(0, 12, 0);
  uav.add(uavLabel);
  uav.traverse((o) => {
    o.userData.device = 'uav';
  });
  groups.devices.add(uav);

  /* ── 初始图层状态 ─────────────────────────────── */
  const handles: CityHandles = {
    scene,
    camera,
    renderer,
    controls,
    groups,
    buildingMeshes,
    robot,
    uav,
    robotCurve,
    uavCurve,
    robotTrailLine: robotTrail,
    robotProgressLine: robotProgress,
    hoverTargets: buildingMeshes,
    pickTargets: [...buildingMeshes, robot, uav],
    highlightMaterials,
    selectedId: null,
    tween: null,
    clock: new THREE.Clock(),
    pulseRings,
    rotatingRotors: [...rotors, ...uavRotors],
    blinkingLights: [navLight],
    pointCloudMat,
    labelSprites,
    disposed: false,
  };

  return handles;
}

/* ═══════════════ 每帧更新 ═══════════════ */
export interface FrameCtx {
  robotT: number;
  robotSpeed: number;
  uavT: number;
  demoActive: boolean;
  demoStage: number;
  onRobotMove?: (t: number) => void;
  robotAccum: { t: number; acc: number };
  uavAccum: number;
}

export function updateCity(h: CityHandles, dt: number, ctx: FrameCtx) {
  const d = Math.min(dt, 0.06);

  /* 相机补间（演示模式镜头飞行） */
  if (h.tween) {
    h.tween.t += d / h.tween.dur;
    const p = Math.min(1, h.tween.t);
    const e = 1 - Math.pow(1 - p, 3);
    h.camera.position.lerpVectors(h.tween.from, h.tween.to, e);
    h.controls.target.lerpVectors(h.tween.targetFrom, h.tween.targetTo, e);
    if (p >= 1) h.tween = null;
  }

  /* 机器人沿城市道路巡航 */
  ctx.robotAccum.acc += d * (0.0068 * ctx.robotSpeed * (ctx.demoActive ? 2.1 : 1));
  if (ctx.robotAccum.acc > 0.0004) {
    ctx.robotAccum.t = (ctx.robotAccum.t + ctx.robotAccum.acc) % 1;
    ctx.robotAccum.acc = 0;
    const t = ctx.robotAccum.t;
    const pos = h.robotCurve.getPointAt(t);
    const tan = h.robotCurve.getTangentAt(t);
    h.robot.position.set(pos.x, pos.y, pos.z);
    h.robot.rotation.y = Math.atan2(tan.x, tan.z);
    const total = h.robotProgressLine.geometry.attributes.position.count;
    h.robotProgressLine.geometry.setDrawRange(0, Math.max(2, Math.floor(total * t)));
    ctx.onRobotMove?.(t);
  }

  /* 无人机沿航线飞行 */
  ctx.uavAccum = (ctx.uavAccum + d * 0.0075) % 1;
  const up = h.uavCurve.getPointAt(ctx.uavAccum);
  const utan = h.uavCurve.getTangentAt(ctx.uavAccum);
  h.uav.position.set(up.x, up.y + Math.sin(performance.now() / 900) * 2.4, up.z);
  h.uav.rotation.y = Math.atan2(utan.x, utan.z);

  /* 旋翼旋转 */
  h.rotatingRotors.forEach((r, i) => {
    r.rotation.y += d * (6 + i * 0.6);
    const mesh = r as THREE.Mesh;
    if (mesh.geometry instanceof THREE.TorusGeometry) r.rotation.z += d * 3;
  });

  /* 呼吸效果 */
  const time = performance.now() / 1000;
  h.pointCloudMat.opacity = 0.62 + Math.sin(time * 1.6) * 0.14;
  h.pulseRings.forEach((r, i) => {
    const s = 1 + Math.sin(time * 1.8 + i * 0.7) * 0.22;
    r.scale.set(s, s, s);
    (r.material as THREE.MeshBasicMaterial).opacity = 0.4 + Math.sin(time * 1.8 + i * 0.7) * 0.28;
  });
  h.blinkingLights.forEach((l, i) => {
    const on = Math.sin(time * 4 + i) > 0;
    (l.material as THREE.MeshBasicMaterial).opacity = on ? 1 : 0.12;
    (l.material as THREE.MeshBasicMaterial).transparent = true;
  });

  /* 演示镜头 */
  h.controls.autoRotate = ctx.demoActive && ctx.demoStage <= 1;
  h.controls.update();

  /* 每帧渲染（三维场景真正出图的唯一入口） */
  h.renderer.render(h.scene, h.camera);
}

export function flyCamera(
  h: CityHandles,
  pos: [number, number, number],
  target: [number, number, number],
  dur = 2.4,
) {
  h.tween = {
    from: h.camera.position.clone(),
    to: new THREE.Vector3(...pos),
    targetFrom: h.controls.target.clone(),
    targetTo: new THREE.Vector3(...target),
    t: 0,
    dur,
  };
}

export function setLayerVisible(h: CityHandles, key: LayerGroupKey, visible: boolean) {
  h.groups[key].visible = visible;
}

export function highlightBuilding(h: CityHandles, id: string | null) {
  if (h.selectedId) {
    const prev = h.highlightMaterials.get(h.selectedId);
    if (prev) {
      const base = prev.userData.baseColor as THREE.Color | undefined;
      if (base) {
        prev.color.copy(base);
        prev.emissive.copy(base.clone().multiplyScalar(0.22));
      }
      prev.opacity = (prev.userData.opacity as number) ?? 0.6;
    }
  }
  h.selectedId = id;
  if (id) {
    const mat = h.highlightMaterials.get(id);
    if (mat) {
      if (!mat.userData.baseColor) mat.userData.baseColor = mat.color.clone();
      if (mat.userData.opacity === undefined) mat.userData.opacity = mat.opacity;
      mat.color.set(0x7fe3ff);
      mat.emissive.set(0x2fa6d6);
      mat.opacity = 0.85;
    }
  }
}

export function disposeCityScene(h: CityHandles) {
  h.disposed = true;
  h.controls.dispose();
  h.scene.traverse((obj) => {
    const any = obj as unknown as {
      geometry?: THREE.BufferGeometry;
      material?: THREE.Material | THREE.Material[];
    };
    any.geometry?.dispose?.();
    const m = any.material;
    if (Array.isArray(m)) m.forEach((mm) => mm.dispose());
    else m?.dispose?.();
  });
  h.renderer.dispose();
  if (h.renderer.domElement.parentElement) {
    h.renderer.domElement.parentElement.removeChild(h.renderer.domElement);
  }
}

export function resizeCity(h: CityHandles, w: number, hgt: number) {
  h.camera.aspect = w / Math.max(1, hgt);
  h.camera.updateProjectionMatrix();
  h.renderer.setSize(w, hgt);
}
