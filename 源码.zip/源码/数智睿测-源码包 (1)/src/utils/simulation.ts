/* ─────────────────────────────────────────────────────────
 *  simulation.ts
 *  平台仿真引擎：状态初始化 / 实时数据漂移 / 演示模式时间轴
 *  纯函数实现，便于后续替换为真实后端 WebSocket 推送
 * ───────────────────────────────────────────────────────── */

import type {
  AITask,
  BuildingDetail,
  BuildingSpec,
  GnssStatus,
  LogLine,
  PlatformState,
} from '../types';
import {
  AI_ANALYSIS_POOL,
  AI_TARGETS,
  BUILDING_TOTAL,
  DEMO_STAGES,
  DEVICE_ENDPOINTS,
  ELEVATION_STATS,
  FLOW_STEPS,
  INITIAL_VOICE,
  POINT_CLOUD_TREND,
  ROAD_LENGTH_KM,
  SYSTEM_LOGS_SEED,
  TASK_SEED,
  mulberry32,
} from '../data/mockData';

/* ── 工具函数 ────────────────────────────────────────── */
export const clamp = (v: number, min: number, max: number) => Math.min(max, Math.max(min, v));
export const pad2 = (n: number) => String(n).padStart(2, '0');

export function formatClock(d: Date): string {
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())} ${pad2(
    d.getHours(),
  )}:${pad2(d.getMinutes())}:${pad2(d.getSeconds())}`;
}

export function formatTimeShort(d: Date): string {
  return `${pad2(d.getHours())}:${pad2(d.getMinutes())}:${pad2(d.getSeconds())}`;
}

export function fmtNum(n: number, digits = 2): string {
  return n.toFixed(digits);
}

/** 千分位格式化 */
export function thousands(n: number): string {
  return n.toLocaleString('en-US');
}

let logSeq = 1000;
export function makeLog(text: string, kind: LogLine['kind'] = 'info', date = new Date()): LogLine {
  logSeq += 1;
  return { id: logSeq, time: formatTimeShort(date), text, kind };
}

export function pushLog(list: LogLine[], line: LogLine, max = 40): LogLine[] {
  return [...list, line].slice(-max);
}

/* ── 建筑 → 空间信息卡 ────────────────────────────────── */
function hashCode(str: string): number {
  let h = 0;
  for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) % 100000;
  return h;
}

export function toBuildingDetail(b: BuildingSpec, gnss: GnssStatus, accuracy: number): BuildingDetail {
  const seed = hashCode(b.id);
  const fx = (seed % 900) / 1000;
  const fy = (Math.floor(seed / 7) % 900) / 1000;
  const fh = (Math.floor(seed / 13) % 900) / 1000;
  return {
    id: b.id,
    category: b.category,
    height: Number(b.h.toFixed(1)),
    area: b.area,
    floors: b.floors,
    pointCount: b.pointCount,
    gnss,
    modelState: '已更新',
    accuracy: Number(accuracy.toFixed(1)),
    coordX: Number((324560 + b.x + fx).toFixed(3)),
    coordY: Number((3856200 + b.z + fy).toFixed(3)),
    coordH: Number((b.h + fh).toFixed(3)),
    updatedAt: formatTimeShort(new Date()),
    aiConfidence: Number((93.5 + ((seed % 60) / 10)).toFixed(1)),
  };
}

/* ── 初始状态 ────────────────────────────────────────── */
export function createInitialState(): PlatformState {
  const now = new Date();
  return {
    booted: false,
    pointCloud: 12.68,
    pointCloudTrend: [...POINT_CLOUD_TREND],
    aiTargets: AI_TARGETS.length * 5 + 58,
    aiAccuracy: 96.8,
    modelFaces: 2.68,
    buildingCount: BUILDING_TOTAL,
    roadLength: ROAD_LENGTH_KM,
    gnss: 'FIX',
    planeAccuracy: 2.1,
    heightAccuracy: 3.2,
    avgElevation: ELEVATION_STATS.avg,
    elevationAnomalies: ELEVATION_STATS.anomalies,
    fusionMissing: ELEVATION_STATS.missingAreas,
    modelUpdatedAt: formatTimeShort(now),
    robot: {
      t: 0.06,
      progress: 68,
      battery: 86,
      online: true,
      speed: 1.2,
      rtk: 'FIX',
      satellites: 32,
      taskName: '城市道路三维测绘',
    },
    uav: {
      t: 0.3,
      online: true,
      altitude: 168,
      speed: 6.4,
      battery: 74,
      coverage: 82,
      taskName: '高层建筑三维建模',
    },
    tasks: TASK_SEED.map((t) => ({ ...t })),
    devices: DEVICE_ENDPOINTS.map((d) => ({ ...d })),
    layers: {
      buildings: true,
      roads: true,
      pointCloud: true,
      gnss: true,
      uavTrail: true,
      robotTrail: true,
      aiTargets: true,
      elevation: true,
    },
    selectedBuilding: null,
    selectedDevice: null,
    aiLogs: [],
    systemLogs: SYSTEM_LOGS_SEED.map((t, i) =>
      makeLog(t, i === SYSTEM_LOGS_SEED.length - 1 ? 'success' : 'info'),
    ),
    voice: { ...INITIAL_VOICE },
    demo: { active: false, stage: 0, stageElapsed: 0, finished: false, playing: false },
    flowStep: 2,
    cloudSync: '正常',
    commState: '正常',
    realtimeState: '正常',
    resultOpen: false,
    emergencyActive: false,
    emergencyStep: -1,
  };
}

/* ── 实时数据漂移（1Hz） ──────────────────────────────── */
export function tickSimulation(prev: PlatformState, rng: () => number): PlatformState {
  const s = { ...prev };
  const demoBoost = s.demo.active && s.demo.playing ? 3.2 : 1;

  /* 点云增长 */
  const growth = (0.008 + rng() * 0.045) * demoBoost;
  s.pointCloud = Number(clamp(s.pointCloud + growth, 11.6, 19.99).toFixed(3));
  s.pointCloudTrend = [...s.pointCloudTrend.slice(1), s.pointCloud];

  /* AI 识别 */
  if (rng() < 0.3 * demoBoost) s.aiTargets += 1;
  s.aiAccuracy = Number(clamp(s.aiAccuracy + (rng() - 0.5) * 0.22, 95.6, 98.6).toFixed(2));

  /* 三维模型面数 */
  if (rng() < 0.45) s.modelFaces = Number(clamp(s.modelFaces + 0.004 + rng() * 0.012, 2.6, 3.2).toFixed(3));

  /* GNSS 状态 & 精度 */
  s.gnss = rng() < 0.055 ? 'FLOAT' : 'FIX';
  s.planeAccuracy = Number(clamp(2.1 + (rng() - 0.5) * 0.7, 1.4, 3.0).toFixed(1));
  s.heightAccuracy = Number(clamp(3.2 + (rng() - 0.5) * 0.9, 2.4, 4.2).toFixed(1));
  s.avgElevation = Number((ELEVATION_STATS.avg + (rng() - 0.5) * 0.6).toFixed(3));

  /* 机器人 / 无人机遥测 */
  const nextProgress = clamp(s.robot.progress + 0.05 + rng() * 0.22, 8, 100);
  s.robot = {
    ...s.robot,
    progress: nextProgress >= 100 ? 18 : Number(nextProgress.toFixed(1)),
    battery: Number(clamp(s.robot.battery - 0.05, 18, 100).toFixed(2)),
    speed: Number(clamp(1.2 + (rng() - 0.5) * 0.5, 0.5, 2.4).toFixed(2)),
    rtk: s.gnss === 'FIX' ? 'FIX' : rng() < 0.5 ? 'FIX' : 'FLOAT',
    satellites: Math.round(30 + rng() * 4),
  };
  s.uav = {
    ...s.uav,
    altitude: Number((168 + (rng() - 0.5) * 14).toFixed(1)),
    speed: Number((6.4 + (rng() - 0.5) * 1.6).toFixed(1)),
    battery: Number(clamp(s.uav.battery - 0.04, 20, 100).toFixed(2)),
    coverage: Number(clamp(s.uav.coverage + rng() * 0.35, 60, 99.9).toFixed(1)),
  };

  /* 任务进度推进 */
  s.tasks = s.tasks.map((t) => {
    if (t.status === 'running') {
      const next = clamp(t.progress + 0.25 + rng() * 0.9, 0, 100);
      if (next >= 100) {
        return { ...t, progress: 100, status: 'done' as const, eta: '已完成', metric: '已完成', metricLabel: '状态' };
      }
      return { ...t, progress: Number(next.toFixed(1)) };
    }
    if (t.status === 'pending' && rng() < 0.08) {
      return { ...t, status: 'running' as const, startedAt: formatTimeShort(new Date()), progress: 1.5 };
    }
    return t;
  });

  /* 模型更新时间 */
  if (rng() < 0.35) s.modelUpdatedAt = formatTimeShort(new Date());

  /* 云端链路质量 */
  s.cloudSync = rng() < 0.96 ? '正常' : '延迟';
  s.commState = rng() < 0.97 ? '正常' : '延迟';
  s.realtimeState = rng() < 0.98 ? '正常' : '延迟';

  /* AI 分析日志 */
  if (rng() < 0.18) s.aiLogs = pushLog(s.aiLogs, makeLog(AI_ANALYSIS_POOL[Math.floor(rng() * AI_ANALYSIS_POOL.length)], 'ai'), 14);

  return s;
}

/* ── 演示模式：阶段 → 流程高亮 映射 ───────────────────── */
export const DEMO_TO_FLOW: number[] = [0, 0, 1, 2, 3, 4, 5, 5, 6, 6, 6];

/* ── 演示模式：进入某阶段的即时效果 ───────────────────── */
export function applyDemoStage(prev: PlatformState, stageIndex: number): PlatformState {
  const s = { ...prev };
  const def = DEMO_STAGES[stageIndex];
  s.flowStep = DEMO_TO_FLOW[stageIndex] ?? 0;
  s.systemLogs = pushLog(s.systemLogs, makeLog(def.message, 'info'), 40);

  switch (stageIndex) {
    case 0:
      s.booted = true;
      s.layers = { ...s.layers, buildings: true, roads: true, pointCloud: false, elevation: false };
      break;
    case 1:
      s.devices = s.devices.map((d) => ({ ...d, online: true }));
      s.robot = { ...s.robot, online: true, rtk: 'FIX' };
      s.uav = { ...s.uav, online: true };
      s.gnss = 'FIX';
      s.layers = { ...s.layers, gnss: true, pointCloud: true };
      break;
    case 2:
      s.pointCloud = Number((s.pointCloud + 0.24).toFixed(3));
      s.robot = { ...s.robot, speed: 1.8 };
      break;
    case 3:
      s.aiTargets += 6;
      s.aiAccuracy = 96.8;
      s.layers = { ...s.layers, aiTargets: true };
      s.aiLogs = pushLog(s.aiLogs, makeLog('AI空间目标识别中……', 'ai'), 14);
      break;
    case 4:
      s.aiLogs = pushLog(s.aiLogs, makeLog('点云精细配准中，ICP 残差 0.9cm', 'ai'), 14);
      break;
    case 5:
      s.modelFaces = Number((s.modelFaces + 0.12).toFixed(3));
      s.modelUpdatedAt = formatTimeShort(new Date());
      break;
    case 6:
      s.elevationAnomalies = 3;
      s.systemLogs = pushLog(s.systemLogs, makeLog('AI检测到异常空间数据（高程突变 / 数据缺失）', 'warn'), 40);
      s.layers = { ...s.layers, elevation: true };
      break;
    case 7:
      s.emergencyActive = true;
      s.emergencyStep = 0;
      s.tasks = [
        {
          id: `TSK-EMG-${Math.floor(Math.random() * 9000 + 1000)}`,
          name: '应急测绘 · 高程异常区域核查',
          status: 'running',
          device: '测绘机器人-02',
          deviceKind: 'robot',
          progress: 4,
          metric: '应急采集',
          metricLabel: '模式',
          priority: '高',
          startedAt: formatTimeShort(new Date()),
          eta: '18:20',
          scene: '应急测绘',
        },
        ...s.tasks,
      ];
      break;
    case 8:
      s.robot = { ...s.robot, speed: 2.1, taskName: '应急测绘 · 高程异常区域核查' };
      s.emergencyStep = 2;
      break;
    case 9:
      s.pointCloud = Number((s.pointCloud + 0.38).toFixed(3));
      s.emergencyStep = 4;
      break;
    case 10:
      s.emergencyStep = 6;
      s.systemLogs = pushLog(s.systemLogs, makeLog('测绘成果生成完成：DLG / DEM / 3D / 报告', 'success'), 40);
      break;
    default:
      break;
  }
  return s;
}

/** 演示时间轴推进（dt 为秒） */
export function advanceDemo(prev: PlatformState, dt: number): PlatformState {
  if (!prev.demo.active || !prev.demo.playing) return prev;
  let s = prev;
  let stageElapsed = s.demo.stageElapsed + dt;
  let stage = s.demo.stage;
  let guard = 0;
  while (guard < 4 && stageElapsed >= DEMO_STAGES[stage].duration) {
    stageElapsed -= DEMO_STAGES[stage].duration;
    if (stage >= DEMO_STAGES.length - 1) {
      return {
        ...s,
        demo: { ...s.demo, finished: true, playing: false, stageElapsed: 0, stage: DEMO_STAGES.length - 1 },
        flowStep: FLOW_STEPS.length - 1,
        systemLogs: pushLog(s.systemLogs, makeLog('城市三维测绘任务完成', 'success'), 40),
      };
    }
    stage += 1;
    s = applyDemoStage(s, stage);
    guard += 1;
  }
  return { ...s, demo: { ...s.demo, stage, stageElapsed } };
}

export function startDemo(prev: PlatformState): PlatformState {
  let s: PlatformState = {
    ...prev,
    demo: { active: true, stage: 0, stageElapsed: 0, finished: false, playing: true },
    systemLogs: pushLog(prev.systemLogs, makeLog('进入演示模式：城市三维数字孪生全流程答辩演示', 'success'), 40),
  };
  s = applyDemoStage(s, 0);
  return s;
}

export function exitDemo(prev: PlatformState): PlatformState {
  return {
    ...prev,
    demo: { active: false, stage: 0, stageElapsed: 0, finished: false, playing: false },
    emergencyActive: false,
    emergencyStep: -1,
  };
}

/* ── 任务辅助 ────────────────────────────────────────── */
export function taskStatusText(status: AITask['status']): string {
  return { running: '执行中', pending: '等待执行', done: '已完成', error: '异常' }[status];
}

export const DEMO_TOTAL = DEMO_STAGES.reduce((s, d) => s + d.duration, 0);

/** 演示模式全局进度（0~1） */
export function demoOverallProgress(s: PlatformState): number {
  const passed = DEMO_STAGES.slice(0, s.demo.stage).reduce((a, d) => a + d.duration, 0);
  const cur = s.demo.finished ? DEMO_STAGES[s.demo.stage].duration : s.demo.stageElapsed;
  return clamp((passed + cur) / DEMO_TOTAL, 0, 1);
}

export const simulationRng = mulberry32(88112233);
