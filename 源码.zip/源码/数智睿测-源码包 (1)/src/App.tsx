import { useEffect, useState } from 'react';
import Header from './components/Header';
import LeftAnalytics from './components/LeftAnalytics';
import CityTwin from './components/CityTwin';
import TaskCenter from './components/TaskCenter';
import VoiceCommand from './components/VoiceCommand';
import DeviceStatus from './components/DeviceStatus';
import BottomStatus from './components/BottomStatus';
import MeasurementResult from './components/MeasurementResult';
import DemoMode from './components/DemoMode';
import { PlatformProvider, usePlatform } from './store/PlatformContext';
import { CheckCircle2, Info, TriangleAlert, XCircle } from 'lucide-react';

/* 设计稿 1920×1080 等比缩放，保证大屏与 1280×720 均可完整呈现 */
function useDesignScale() {
  const [scale, setScale] = useState(() =>
    Math.min(window.innerWidth / 1920, window.innerHeight / 1080),
  );
  useEffect(() => {
    const onResize = () =>
      setScale(Math.min(window.innerWidth / 1920, window.innerHeight / 1080));
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);
  return scale;
}

function ToastHost() {
  const { toasts, dispatch } = usePlatform();
  return (
    <div className="pointer-events-none absolute left-1/2 top-[76px] z-50 flex -translate-x-1/2 flex-col items-center gap-1.5">
      {toasts.map((t) => {
        const Icon =
          t.kind === 'success'
            ? CheckCircle2
            : t.kind === 'warn'
              ? TriangleAlert
              : t.kind === 'danger'
                ? XCircle
                : Info;
        const color =
          t.kind === 'success'
            ? 'text-success border-success/40'
            : t.kind === 'warn'
              ? 'text-warn border-warn/40'
              : t.kind === 'danger'
                ? 'text-danger border-danger/40'
                : 'text-cyanx border-cyanx/40';
        return (
          <div
            key={t.id}
            className={`panel pointer-events-auto flex items-center gap-2 border px-3 py-1.5 animate-fade-up ${color}`}
          >
            <Icon size={13} />
            <span className="text-[11.5px] text-ink">{t.text}</span>
            <button
              className="text-ink-3 transition-colors hover:text-ink"
              onClick={() => dispatch({ type: 'DISMISS_TOAST', id: t.id })}
            >
              ×
            </button>
          </div>
        );
      })}
    </div>
  );
}

function Shell() {
  const scale = useDesignScale();
  const { log } = usePlatform();

  /* 平台启动自检日志（Mock） */
  useEffect(() => {
    const seq: [number, string, 'info' | 'success' | 'warn'][] = [
      [800, '加载城市三维数字孪生底座（428 栋 / 2.68M 面）……', 'info'],
      [1800, 'GNSS/RTK 基准站数据链建立：CGCS2000 坐标系统', 'info'],
      [2800, '无人机 UAV-02 航线装订完成，等待起飞指令', 'info'],
      [3800, '测绘机器人-01 沿城市道路开始巡检测绘', 'success'],
      [4800, 'AI 推理引擎就绪：building-seg-v3 / roadnet-v2', 'success'],
      [5800, 'P.S. 当前为 Mock 数据演示环境，可直接点击「开始演示」', 'warn'],
    ];
    const timers = seq.map(([ms, text, kind]) => window.setTimeout(() => log(text, kind), ms));
    return () => timers.forEach((t) => window.clearTimeout(t));
  }, [log]);

  return (
    <div className="fixed inset-0 overflow-hidden bg-base">
      <div
        className="absolute left-1/2 top-1/2 origin-center"
        style={{
          width: 1920,
          height: 1080,
          transform: `translate(-50%, -50%) scale(${scale})`,
        }}
      >
        <div className="flex h-full w-full flex-col">
          <Header />
          <main className="flex min-h-0 flex-1 gap-2 px-3 py-2">
            <LeftAnalytics />
            <CityTwin />
            {/* 右侧：任务调度 + AI语音指令 + 三端协同 */}
            <aside className="flex min-h-0 w-[422px] shrink-0 flex-col gap-2">
              <TaskCenter />
              <VoiceCommand />
              <DeviceStatus />
            </aside>
          </main>
          <BottomStatus />
        </div>

        <DemoMode />
        <MeasurementResult />
        <ToastHost />
      </div>

      {/* 屏幕过小时的比例提示 */}
      {scale < 0.62 && (
        <div className="absolute bottom-1 left-2 text-[10px] text-ink-3">
          提示：当前窗口较小，界面按 1920×1080 等比缩放显示，建议全屏（F11）获得最佳演示效果
        </div>
      )}
    </div>
  );
}

export default function App() {
  return (
    <PlatformProvider>
      <Shell />
    </PlatformProvider>
  );
}
