import { useEffect, useRef, useState } from 'react';

/**
 * 数字滚动动画：数值变化时平滑过渡，避免大屏数字跳变
 */
export function useCountUp(target: number, duration = 650, digits = 2): string {
  const [display, setDisplay] = useState(target);
  const fromRef = useRef(target);
  const rafRef = useRef<number | undefined>(undefined);
  const startRef = useRef(0);

  useEffect(() => {
    fromRef.current = display;
    startRef.current = performance.now();
    const from = fromRef.current;
    const delta = target - from;

    const step = (t: number) => {
      const p = Math.min(1, (t - startRef.current) / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      setDisplay(from + delta * eased);
      if (p < 1) rafRef.current = requestAnimationFrame(step);
    };
    rafRef.current = requestAnimationFrame(step);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [target, duration]);

  return display.toFixed(digits);
}

/** 千分位整数滚动 */
export function useCountUpInt(target: number, duration = 650): string {
  const v = useCountUp(target, duration, 0);
  return Number(v).toLocaleString('en-US');
}
