/* ─────────────────────────────────────────────────────────
 * 全局类型定义 —— 数智睿测平台
 * ───────────────────────────────────────────────────────── */

export type GnssStatus = 'FIX' | 'FLOAT' | 'SINGLE';

export type TaskStatus = 'running' | 'pending' | 'done' | 'error';

export type BuildingCategory = '高层建筑' | '低层建筑' | '商业综合体' | '公共建筑';

export interface BuildingSpec {
  id: string;
  /** 世界坐标 X（米） */
  x: number;
  /** 世界坐标 Z（米） */
  z: number;
  /** 底面宽（X 方向） */
  w: number;
  /** 底面进深（Z 方向） */
  d: number;
  /** 建筑高度（米） */
  h: number;
  category: BuildingCategory;
  floors: number;
  area: number;
  pointCount: number;
  /** 是否为地标建筑（渲染强调） */
  landmark?: boolean;
}

export interface GnssPoint {
  id: string;
  x: number;
  z: number;
  h: number;
  status: GnssStatus;
  satellite: number;
  pdop: number;
}

export interface AiTarget {
  id: string;
  label: string;
  kind: 'building' | 'road' | 'vehicle' | 'vegetation' | 'anomaly';
  x: number;
  z: number;
  y: number;
  size: [number, number, number];
  confidence: number;
}

export interface ElevationSample {
  x: number;
  z: number;
  h: number;
}

export interface RoutePoint {
  x: number;
  y: number;
  z: number;
}

export interface AITask {
  id: string;
  name: string;
  status: TaskStatus;
  /** 执行设备 */
  device: string;
  deviceKind: 'robot' | 'uav' | 'gnss' | 'cloud';
  progress: number;
  /** 数据量描述，如 "点云 4.82M" */
  metric?: string;
  metricLabel?: string;
  aiAccuracy?: number;
  priority: '高' | '中' | '低';
  startedAt: string;
  eta: string;
  scene: string;
}

export interface DeviceEndpoint {
  id: string;
  name: string;
  kind: 'web' | 'robot' | 'uav' | 'gnss';
  online: boolean;
  detail: string;
  latency: number;
}

export interface LayerFlags {
  buildings: boolean;
  roads: boolean;
  pointCloud: boolean;
  gnss: boolean;
  uavTrail: boolean;
  robotTrail: boolean;
  aiTargets: boolean;
  elevation: boolean;
}

export type LayerKey = keyof LayerFlags;

export interface BuildingDetail {
  id: string;
  category: BuildingCategory;
  height: number;
  area: number;
  floors: number;
  pointCount: number;
  gnss: GnssStatus;
  modelState: string;
  accuracy: number;
  coordX: number;
  coordY: number;
  coordH: number;
  updatedAt: string;
  aiConfidence: number;
}

export interface RobotTelemetry {
  /** 轨迹参数 0~1 */
  t: number;
  progress: number;
  battery: number;
  online: boolean;
  speed: number;
  rtk: GnssStatus;
  satellites: number;
  taskName: string;
}

export interface UavTelemetry {
  t: number;
  online: boolean;
  altitude: number;
  speed: number;
  battery: number;
  coverage: number;
  taskName: string;
}

export interface LogLine {
  id: number;
  time: string;
  text: string;
  kind: 'info' | 'success' | 'warn' | 'danger' | 'ai';
}

export interface DemoStageDef {
  key: string;
  index: number;
  title: string;
  message: string;
  detail: string;
  /** 该阶段持续时间（秒），全部阶段合计约 3 分钟 */
  duration: number;
  tags: string[];
}

export interface DemoState {
  active: boolean;
  stage: number;
  /** 当前阶段内已过秒数 */
  stageElapsed: number;
  finished: boolean;
  playing: boolean;
}

export interface FlowStep {
  id: string;
  name: string;
  short: string;
  desc: string;
}

export interface ResultField {
  label: string;
  value: string;
  unit?: string;
  highlight?: boolean;
}

export interface ToastMsg {
  id: number;
  text: string;
  kind: 'success' | 'info' | 'warn' | 'danger';
}

export interface PlatformState {
  booted: boolean;
  /** 点云总量（百万点） */
  pointCloud: number;
  pointCloudTrend: number[];
  /** AI 识别目标数 */
  aiTargets: number;
  aiAccuracy: number;
  /** 三维模型面数（百万） */
  modelFaces: number;
  buildingCount: number;
  roadLength: number;
  gnss: GnssStatus;
  planeAccuracy: number;
  heightAccuracy: number;
  avgElevation: number;
  elevationAnomalies: number;
  fusionMissing: number;
  modelUpdatedAt: string;
  robot: RobotTelemetry;
  uav: UavTelemetry;
  tasks: AITask[];
  devices: DeviceEndpoint[];
  layers: LayerFlags;
  selectedBuilding: BuildingDetail | null;
  selectedDevice: 'robot' | 'uav' | null;
  aiLogs: LogLine[];
  systemLogs: LogLine[];
  voice: VoiceState;
  demo: DemoState;
  flowStep: number;
  cloudSync: '正常' | '延迟' | '中断';
  commState: '正常' | '延迟' | '中断';
  realtimeState: '正常' | '延迟' | '中断';
  resultOpen: boolean;
  emergencyActive: boolean;
  emergencyStep: number;
}

export interface VoiceState {
  listening: boolean;
  recognizing: boolean;
  /** 0~5，对应 语音识别→指令解析→任务验证→设备匹配→任务下发→执行反馈 */
  stage: number;
  command: string;
  replies: string[];
  visibleReplies: number;
}
