import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import {
  Activity,
  AlertTriangle,
  Bot,
  Boxes,
  Brain,
  CheckCircle2,
  ChevronRight,
  Cpu,
  Crosshair,
  Mountain,
  Plane,
  Radio,
  Satellite,
  ScanLine,
  Sparkles,
  Waypoints,
} from 'lucide-react';
import { Panel } from './ui/Panel';
import { Chip, Dot, KV, Metric, Progress } from './ui/bits';
import { MiniBars, Sparkline } from './ui/charts';
import { useCountUp, useCountUpInt } from '../hooks/useCountUp';
import { usePlatform } from '../store/PlatformContext';
import {
  AI_ANALYSIS_POOL,
  AI_ANALYSIS_SCRIPT,
  ELEVATION_HISTOGRAM,
  ELEVATION_STATS,
  FLOW_STEPS,
  pickRandom,
} from '../data/mockData';

/* ── 通用小卡片 ───────────────────────────────────────── */
function Card({
  icon: Icon,
  title,
  extra,
  children,
  className = '',
}: {
  icon: typeof Activity;
  title: string;
  extra?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className={`panel-flat corner relative px-2.5 pb-2 pt-2 ${className}`}>
      <div className="flex items-center justify-between">
        <span className="flex items-center gap-1.5 text-[10.5px] tracking-wide text-ink-2">
          <Icon size={11} className="text-cyanx" />
          {title}
        </span>
        {extra}
      </div>
      {children}
    </div>
  );
}

/* ── AI 空间智能分析窗口 ─────────────────────────────── */
function AiAnalysis() {
  const [lines, setLines] = useState<{ id: number; text: string; kind: string }[]>([]);
  const idx = useRef(0);

  useEffect(() => {
    const push = () => {
      let text: string;
      let kind = 'info';
      if (idx.current < AI_ANALYSIS_SCRIPT.length) {
        text = AI_ANALYSIS_SCRIPT[idx.current];
        if (text.includes('异常')) kind = 'warn';
        else if (text.includes('缺失')) kind = 'danger';
        else if (text.includes('完成')) kind = 'success';
        else kind = 'ai';
        idx.current += 1;
      } else {
        text = pickRandom(AI_ANALYSIS_POOL);
        kind = 'ai';
      }
      setLines((prev) => [...prev, { id: Date.now() + Math.random(), text, kind }].slice(-7));
    };
    push();
    const t = window.setInterval(push, 1600);
    return () => window.clearInterval(t);
  }, []);

  const summary = [
    { label: '建筑物', value: '428', tone: 'cyan' as const, icon: Boxes },
    { label: '道路', value: '86', tone: 'primary' as const, icon: Waypoints },
    { label: '异常高程', value: '3', tone: 'warn' as const, icon: AlertTriangle },
    { label: '数据缺失', value: '1', tone: 'danger' as const, icon: Crosshair },
  ];

  const colorOf = (kind: string) =>
    ({
      ai: 'text-cyanx',
      warn: 'text-warn',
      danger: 'text-danger',
      success: 'text-success',
      info: 'text-ink-2',
    })[kind] ?? 'text-ink-2';

  return (
    <Panel
      title="AI空间智能分析"
      subtitle="building-seg-v3 · roadnet-v2"
      extra={
        <Chip tone="cyan">
          <Sparkles size={9} /> 推理中
        </Chip>
      }
      className="shrink-0"
      dense
    >
      <div className="flex items-center justify-between gap-1 rounded-sm border border-line bg-[#0B1B2E]/60 px-2 py-[3px]">
        {summary.map((s) => (
          <span key={s.label} className="flex items-center gap-1">
            <s.icon
              size={10}
              className={s.tone === 'warn' ? 'text-warn' : s.tone === 'danger' ? 'text-danger' : 'text-cyanx'}
            />
            <span className="text-[9.5px] text-ink-3">{s.label}</span>
            <span className={`num text-[12.5px] ${s.tone === 'warn' ? 'text-warn' : s.tone === 'danger' ? 'text-danger' : 'text-ink'}`}>
              {s.value}
            </span>
          </span>
        ))}
      </div>

      <div className="scroll-thin mt-1.5 h-[54px] rounded-sm border border-line/70 bg-[#061021]/70 p-1.5 font-num text-[10px] leading-[16px]">
        {lines.map((l) => (
          <div key={l.id} className="flex items-start gap-1.5 animate-fade-up">
            <span className="mt-[5px] text-ink-3">›</span>
            <span className={`${colorOf(l.kind)}`}>{l.text}</span>
          </div>
        ))}
        <div className="flex items-center gap-1 text-cyanx">
          <span>›</span>
          <span className="inline-block h-[10px] w-[6px] animate-blink bg-cyanx" />
        </div>
      </div>
    </Panel>
  );
}

/* ── 智能处理流程 ─────────────────────────────────────── */
function ProcessFlow() {
  const { platform, dispatch, log } = usePlatform();
  const active = platform.flowStep;

  const onPick = (i: number) => {
    dispatch({ type: 'SET_FLOW_STEP', step: i });
    log(`手动切换处理流程节点：${FLOW_STEPS[i].name}`, 'info');
  };

  return (
    <Panel
      title="智能处理流程"
      subtitle="采集 → 感知 → 分析 → 建模 → 调度 → 成果"
      extra={<Chip tone="success">Step {active + 1}/7</Chip>}
      className="min-h-0 flex-1"
      bodyClassName="scroll-thin"
      dense
    >
      <div className="relative">
        <div className="absolute bottom-2 left-[9px] top-2 w-px bg-gradient-to-b from-cyanx/50 via-line to-transparent" />
        {FLOW_STEPS.map((s, i) => {
          const done = i < active;
          const cur = i === active;
          return (
            <button
              key={s.id}
              onClick={() => onPick(i)}
              className={`relative mb-[2px] flex w-full items-center gap-2 rounded-sm border px-2 py-[2px] text-left transition-all duration-300 ${
                cur
                  ? 'border-cyanx/55 bg-cyanx/10 shadow-[inset_0_0_16px_-8px_rgba(0,194,255,0.9)]'
                  : done
                    ? 'border-success/25 bg-success/[0.05] hover:border-success/50'
                    : 'border-line/60 bg-white/[0.012] hover:border-line-strong'
              }`}
            >
              <span
                className={`relative z-10 flex h-[16px] w-[16px] shrink-0 items-center justify-center rounded-full border text-[9px] ${
                  cur
                    ? 'border-cyanx bg-[#062033] text-cyanx shadow-[0_0_10px_rgba(0,194,255,0.6)]'
                    : done
                      ? 'border-success/60 bg-[#08251d] text-success'
                      : 'border-line bg-[#0A1729] text-ink-3'
                }`}
              >
                {done ? <CheckCircle2 size={11} /> : i + 1}
              </span>
              <span className="min-w-0 shrink-0 text-[10.5px] font-medium" style={{ color: cur ? '#00C2FF' : done ? '#E6F1FF' : '#9FB6CE' }}>
                {s.name}
              </span>
              <span className="min-w-0 flex-1 truncate text-[9px] text-ink-3">{s.desc}</span>
              <span className="num shrink-0 text-[8.5px] tracking-wider text-ink-3">{s.short}</span>
              {cur && <ChevronRight size={11} className="shrink-0 animate-blink text-cyanx" />}
            </button>
          );
        })}
      </div>
    </Panel>
  );
}

/* ── 主体：左侧可视化分析与深度学习 ───────────────────── */
export default function LeftAnalytics() {
  const { platform } = usePlatform();

  const pointCloud = useCountUp(platform.pointCloud, 700, 2);
  const modelFaces = useCountUp(platform.modelFaces, 700, 2);
  const avgElev = useCountUp(platform.avgElevation, 700, 3);
  const aiTargets = useCountUpInt(platform.aiTargets);

  const gnssOk = platform.gnss === 'FIX';
  const accuracyRate = useMemo(() => Math.min(99.4, 88 + platform.aiAccuracy * 0.1), [platform.aiAccuracy]);

  return (
    <aside className="flex min-h-0 w-[422px] shrink-0 flex-col gap-2">
      <div className="panel corner flex min-h-0 flex-1 flex-col gap-2 p-2.5">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="sec-title">可视化分析与深度学习</h2>
            <p className="mt-1 pl-[11px] text-[10px] tracking-wide text-ink-3">多源测绘数据智能分析</p>
          </div>
          <Chip tone="primary">
            <Radio size={9} /> 12.68M pts
          </Chip>
        </div>

        <div className="scroll-thin flex min-h-0 flex-1 flex-col gap-2 pr-0.5">
          {/* 卡片1 · 点云数据 */}
          <Card
            icon={ScanLine}
            title="点云数据"
            extra={
              <Chip tone="success">
                <Dot color="#20C997" size={5} /> 实时更新
              </Chip>
            }
          >
            <div className="mt-1 flex items-end justify-between gap-2">
              <Metric value={pointCloud} unit="M" size={27} color="#00C2FF" />
              <div className="w-[150px]">
                <Sparkline data={platform.pointCloudTrend} height={44} />
              </div>
            </div>
            <div className="mt-0.5 flex items-center justify-between text-[9.5px] text-ink-3">
              <span>LiDAR 多站融合 · 去噪完成率 99.2%</span>
              <span className="num text-success">+{(platform.pointCloud - 11.42).toFixed(2)}M</span>
            </div>
          </Card>

          {/* 卡片2 + 卡片3 */}
          <div className="grid grid-cols-2 gap-2">
            <Card
              icon={Satellite}
              title="GNSS/RTK"
              extra={<Chip tone={gnssOk ? 'success' : 'warn'}>{platform.gnss}</Chip>}
            >
              <div className="mt-1">
                <Metric value={platform.gnss} size={22} color={gnssOk ? '#20C997' : '#FFB020'} />
              </div>
              <div className="mt-1">
                <KV label="平面精度" value={`±${platform.planeAccuracy.toFixed(1)}`} unit="cm" tone="cyan" />
                <KV label="高程精度" value={`±${platform.heightAccuracy.toFixed(1)}`} unit="cm" tone="cyan" />
                <KV label="卫星 / PDOP" value={`${platform.robot.satellites} / 0.8`} />
              </div>
            </Card>

            <Card
              icon={Brain}
              title="AI视觉识别"
              extra={
                <Chip tone="cyan">
                  <Cpu size={9} /> AI推理中
                </Chip>
              }
            >
              <div className="mt-1">
                <Metric value={platform.aiAccuracy.toFixed(1)} unit="%" size={22} color="#00C2FF" />
              </div>
              <Progress value={accuracyRate} color="#00C2FF" height={4} striped />
              <div className="mt-1">
                <KV label="识别目标" value={aiTargets} unit="个" tone="cyan" />
                <KV label="误检率" value="0.42" unit="%" tone="success" />
              </div>
            </Card>
          </div>

          {/* 卡片4 + 卡片5 */}
          <div className="grid grid-cols-2 gap-2">
            <Card
              icon={Boxes}
              title="三维模型"
              extra={<Chip tone="success">实时更新</Chip>}
            >
              <div className="mt-1">
                <KV label="模型面数" value={modelFaces} unit="M" tone="cyan" />
                <KV label="建筑物" value={platform.buildingCount} unit="栋" />
                <KV label="LOD 层级" value="LOD2 / LOD3" />
              </div>
              <div className="mt-1 text-[9px] text-ink-3">
                模型更新：<span className="num text-cyanx">{platform.modelUpdatedAt}</span>
              </div>
            </Card>

            <Card icon={Mountain} title="高程分析" extra={<Chip tone="warn">异常 {platform.elevationAnomalies}</Chip>}>
              <div className="mt-1">
                <KV label="平均高程" value={avgElev} unit="m" tone="cyan" />
                <KV label="高程异常" value={platform.elevationAnomalies} unit="处" tone="warn" />
                <KV label="DEM 精度" value="1:500" />
              </div>
              <MiniBars bins={ELEVATION_HISTOGRAM.bins} values={ELEVATION_HISTOGRAM.values} height={40} />
            </Card>
          </div>

          {/* 卡片6 · 数据融合 */}
          <Card
            icon={Waypoints}
            title="数据融合"
            extra={<Chip tone="primary">多源同步 {ELEVATION_STATS.avg.toFixed(1)}m 基准</Chip>}
          >
            <div className="mt-1.5 grid grid-cols-2 gap-x-3 gap-y-1">
              {[
                { icon: Plane, label: '无人机', value: platform.uav.online ? '在线' : '离线', ok: platform.uav.online },
                { icon: Bot, label: '地面机器人', value: platform.robot.online ? '在线' : '离线', ok: platform.robot.online },
                { icon: Satellite, label: 'GNSS', value: platform.gnss, ok: gnssOk },
                { icon: ScanLine, label: '点云', value: '同步', ok: true },
              ].map((r) => (
                <div key={r.label} className="flex items-center justify-between rounded-sm border border-line/60 bg-[#0B1B2E]/50 px-1.5 py-[3px]">
                  <span className="flex items-center gap-1 text-[10px] text-ink-3">
                    <r.icon size={10} className="text-cyanx/80" />
                    {r.label}
                  </span>
                  <span className={`num text-[10.5px] ${r.ok ? 'text-success' : 'text-warn'}`}>{r.value}</span>
                </div>
              ))}
            </div>
          </Card>

          <AiAnalysis />
          <ProcessFlow />
        </div>
      </div>
    </aside>
  );
}
