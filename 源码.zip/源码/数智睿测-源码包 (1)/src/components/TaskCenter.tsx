import { useEffect, useState } from 'react';
import {
  AlertTriangle,
  Bot,
  CheckCircle2,
  Cloud,
  Cpu,
  ListChecks,
  Plane,
  RefreshCw,
  Satellite,
  Siren,
  Timer,
  TriangleAlert,
} from 'lucide-react';
import { Chip, Dot, Progress } from './ui/bits';
import { usePlatform } from '../store/PlatformContext';
import { EMERGENCY_FLOW, EMERGENCY_LOGS, TASK_STATS } from '../data/mockData';
import { taskStatusText } from '../utils/simulation';
import type { AITask } from '../types';

const STATUS_STYLE: Record<
  AITask['status'],
  { tone: 'cyan' | 'muted' | 'success' | 'danger'; color: string; icon: typeof Cpu }
> = {
  running: { tone: 'cyan', color: '#00C2FF', icon: Cpu },
  pending: { tone: 'muted', color: '#6B839C', icon: Timer },
  done: { tone: 'success', color: '#20C997', icon: CheckCircle2 },
  error: { tone: 'danger', color: '#FF4D4F', icon: TriangleAlert },
};

const DEVICE_ICON = {
  robot: Bot,
  uav: Plane,
  gnss: Satellite,
  cloud: Cloud,
} as const;

/* ── 任务卡片 ─────────────────────────────────────────── */
function TaskCard({ task }: { task: AITask }) {
  const style = STATUS_STYLE[task.status];
  const Icon = DEVICE_ICON[task.deviceKind];
  const StatusIcon = style.icon;
  return (
    <div
      className={`panel-flat corner relative px-2.5 py-[7px] transition-colors ${
        task.status === 'running' ? 'border-cyanx/35' : task.status === 'error' ? 'border-danger/35' : ''
      }`}
    >
      <div className="flex items-start justify-between gap-2">
        <div className="flex min-w-0 items-start gap-1.5">
          <Icon size={12} className="mt-[2px] shrink-0 text-cyanx/80" />
          <div className="min-w-0">
            <div className="truncate text-[11.5px] text-ink">{task.name}</div>
            <div className="mt-[2px] flex items-center gap-1.5 text-[9px] text-ink-3">
              <span className="num">{task.id}</span>
              <span>·</span>
              <span className="truncate">{task.device}</span>
            </div>
          </div>
        </div>
        <span className="flex shrink-0 items-center gap-1" style={{ color: style.color }}>
          <StatusIcon size={10} />
          <span className="text-[10px]">{taskStatusText(task.status)}</span>
        </span>
      </div>

      {task.status !== 'pending' && (
        <div className="mt-1">
          <Progress value={task.progress} color={style.color} height={3} striped={task.status === 'running'} />
        </div>
      )}

      <div className="mt-1 flex items-center justify-between text-[9px]">
        <span className="text-ink-3">
          {task.metricLabel}：<span className="num text-ink-2">{task.metric}</span>
        </span>
        <span className="flex items-center gap-1.5">
          <Chip tone={task.priority === '高' ? 'warn' : task.priority === '中' ? 'cyan' : 'muted'}>
            {task.priority}
          </Chip>
          <span className="num text-ink-3">{task.status === 'pending' ? '—' : `${task.progress.toFixed(0)}%`}</span>
        </span>
      </div>
    </div>
  );
}

/* ── 应急测绘能力（AI 发现异常 → 自动生成任务 → 自动调度） ── */
function EmergencyCapability() {
  const { platform, dispatch, pushToast } = usePlatform();
  const [step, setStep] = useState(-1);

  useEffect(() => {
    if (platform.emergencyActive) setStep(platform.emergencyStep);
  }, [platform.emergencyActive, platform.emergencyStep]);

  const runEmergency = () => {
    dispatch({ type: 'START_DEMO' });
    dispatch({ type: 'DEMO_JUMP', stage: 6 });
    pushToast('已启动应急测绘演练：AI识别异常 → 自动调度', 'warn');
  };

  const active = Math.max(0, step);
  const logText =
    step >= 0
      ? EMERGENCY_LOGS[Math.min(EMERGENCY_LOGS.length - 1, step)]
      : '实时监测空间数据异常，AI 自动生成应急测绘任务';

  return (
    <div className={`panel-flat corner px-2 py-1.5 ${step >= 0 ? 'border-warn/40' : 'border-line'}`}>
      <div className="flex items-center justify-between">
        <span className={`flex items-center gap-1.5 text-[10.5px] ${step >= 0 ? 'text-warn' : 'text-ink-2'}`}>
          <Siren size={11} /> 应急测绘能力
        </span>
        <button className="btn px-1.5 py-[2px] text-[10px]" onClick={runEmergency}>
          <RefreshCw size={10} /> 模拟异常
        </button>
      </div>
      <div className="mt-1 flex items-center gap-[3px]">
        {EMERGENCY_FLOW.map((f, i) => (
          <span
            key={f}
            title={`${i + 1}. ${f}`}
            className={`h-[4px] flex-1 rounded-full transition-colors duration-500 ${
              i <= step ? 'bg-warn shadow-[0_0_6px_rgba(255,176,32,0.8)]' : 'bg-[#0d2136]'
            }`}
          />
        ))}
      </div>
      <div className="mt-1 flex items-center gap-1 text-[9.5px]">
        <AlertTriangle size={9} className={step >= 0 ? 'text-warn' : 'text-ink-3'} />
        <span className={`truncate ${step >= 0 ? 'text-warn/90' : 'text-ink-3'}`}>
          {step >= 0 ? `${logText} · ${EMERGENCY_FLOW[Math.min(EMERGENCY_FLOW.length - 1, active)]}` : logText}
        </span>
      </div>
    </div>
  );
}

/* ── 主体：云通信与AI全域任务调度 ─────────────────────── */
export default function TaskCenter() {
  const { platform } = usePlatform();
  const stats = [
    { label: '任务总数', value: TASK_STATS.total, color: '#E6F1FF' },
    { label: '执行中', value: TASK_STATS.running + (platform.demo.active ? 1 : 0), color: '#00C2FF' },
    { label: '已完成', value: TASK_STATS.done + (platform.demo.active ? 1 : 0), color: '#20C997' },
    { label: '异常', value: TASK_STATS.error, color: '#FF4D4F' },
  ];

  return (
    <section className="panel corner flex h-[398px] shrink-0 flex-col gap-2 p-2.5">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="sec-title">云通信与AI全域任务调度</h2>
          <p className="mt-1 pl-[11px] text-[10px] tracking-wide text-ink-3">三端协同 + AI赋能</p>
        </div>
        <Chip tone="success">
          <Dot color="#20C997" size={5} /> 调度器在线
        </Chip>
      </div>

      {/* 任务统计 */}
      <div className="grid grid-cols-4 gap-1.5">
        {stats.map((s) => (
          <div key={s.label} className="panel-flat corner px-1 py-1 text-center">
            <div className="num text-[17px] font-semibold" style={{ color: s.color }}>
              {s.value}
            </div>
            <div className="text-[9.5px] text-ink-3">{s.label}</div>
          </div>
        ))}
      </div>

      <EmergencyCapability />

      {/* 任务列表 */}
      <div className="flex items-center justify-between">
        <span className="flex items-center gap-1.5 text-[10.5px] text-ink-2">
          <ListChecks size={11} className="text-cyanx" /> AI 任务列表
        </span>
        <span className="num text-[9.5px] text-ink-3">共 {platform.tasks.length} 条 · 实时刷新</span>
      </div>
      <div className="scroll-thin flex min-h-0 flex-1 flex-col gap-1.5 pr-0.5">
        {platform.tasks.map((t) => (
          <TaskCard key={t.id} task={t} />
        ))}
      </div>
    </section>
  );
}
