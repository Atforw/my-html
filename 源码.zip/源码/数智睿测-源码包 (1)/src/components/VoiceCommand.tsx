import { useEffect, useRef, useState } from 'react';
import { AudioLines, CheckCircle2, Mic, MicOff, Play, Send, Sparkles, Volume2 } from 'lucide-react';
import { Chip, Dot } from './ui/bits';
import { usePlatform } from '../store/PlatformContext';
import { VOICE_FLOW, VOICE_REPLIES, VOICE_SAMPLES } from '../data/mockData';

export default function VoiceCommand() {
  const { platform, dispatch, pushToast } = usePlatform();
  const [stage, setStage] = useState(-1);
  const [sampleIdx, setSampleIdx] = useState(0);
  const [replies, setReplies] = useState<string[]>([]);
  const [typing, setTyping] = useState(false);
  const [wave, setWave] = useState(0);
  const timers = useRef<number[]>([]);

  const command = VOICE_SAMPLES[sampleIdx];
  const listening = platform.voice.listening;

  useEffect(() => () => timers.current.forEach((t) => window.clearTimeout(t)), []);

  /* 语音波形动画 */
  useEffect(() => {
    if (!typing) return;
    const t = window.setInterval(() => setWave((w) => w + 1), 160);
    return () => window.clearInterval(t);
  }, [typing]);

  const runVoice = () => {
    timers.current.forEach((t) => window.clearTimeout(t));
    timers.current = [];
    setReplies([]);
    setTyping(true);
    pushToast(`麦克风已开启，模拟识别：「${command}」`, 'info');

    VOICE_FLOW.forEach((_, i) => {
      timers.current.push(window.setTimeout(() => setStage(i), 480 * i));
    });

    const replyAt: Record<number, number> = { 0: 0, 2: 1, 3: 2, 5: 3 };
    Object.entries(replyAt).forEach(([st, ri]) => {
      timers.current.push(
        window.setTimeout(() => setReplies((prev) => [...prev, VOICE_REPLIES[ri]]), 480 * Number(st) + 240),
      );
    });

    timers.current.push(
      window.setTimeout(() => {
        setTyping(false);
        dispatch({ type: 'SET_FLOW_STEP', step: 1 });
        dispatch({ type: 'PUSH_LOG', text: `AI语音指令已执行：${command}`, kind: 'success' });
        dispatch({
          type: 'SELECT_DEVICE',
          device: command.includes('无人机') || command.includes('高层建筑') ? 'uav' : 'robot',
        });
        pushToast('AI 已完成指令解析与任务下发', 'success');
      }, 480 * VOICE_FLOW.length + 420),
    );
  };

  const nextSample = () => {
    setSampleIdx((i) => (i + 1) % VOICE_SAMPLES.length);
    setStage(-1);
    setReplies([]);
    setTyping(false);
  };

  return (
    <section className="panel corner flex h-[264px] shrink-0 flex-col p-2.5">
      <header className="flex items-center justify-between">
        <div className="flex min-w-0 items-center gap-2">
          <span className="h-[12px] w-[3px] shrink-0 rounded-sm bg-cyanx shadow-[0_0_6px_rgba(0,194,255,0.8)]" />
          <h2 className="truncate text-[12.5px] font-semibold tracking-wide text-ink">AI语音指令</h2>
          <span className="truncate text-[10px] text-ink-3">语音直达任务调度</span>
        </div>
        <Chip tone={listening ? 'success' : 'muted'}>
          <Dot color={listening ? '#20C997' : '#6B839C'} size={5} />
          {listening ? 'AI正在监听' : '已静音'}
        </Chip>
      </header>

      {/* 识别到的指令 */}
      <div className="mt-2 flex items-center gap-2 rounded-sm border border-line bg-[#061021]/70 px-2 py-1.5">
        <span className="relative flex h-[26px] w-[26px] shrink-0 items-center justify-center rounded-full border border-cyanx/40 bg-cyanx/10">
          {listening ? <Mic size={13} className="text-cyanx" /> : <MicOff size={13} className="text-ink-3" />}
          {listening && <span className="absolute inset-0 animate-pulse-ring rounded-full bg-cyanx/40" />}
        </span>
        <div className="min-w-0 flex-1">
          <div className="text-[9px] text-ink-3">示例指令</div>
          <div className="truncate text-[11.5px] text-ink">“{command}”</div>
        </div>
        <button className="btn px-1.5 py-1" title="切换示例指令" onClick={nextSample}>
          <AudioLines size={11} />
        </button>
      </div>

      {/* 指令处理链路：语音识别 → 指令解析 → 任务验证 → 设备匹配 → 任务下发 → 执行反馈 */}
      <div className="mt-2 flex items-center gap-[3px]">
        {VOICE_FLOW.map((f, i) => {
          const done = stage >= i;
          const cur = stage === i;
          return (
            <span
              key={f}
              className={`flex-1 truncate rounded-sm border px-0.5 py-[3px] text-center text-[9px] transition-all duration-300 ${
                cur
                  ? 'border-cyanx/70 bg-cyanx/15 text-cyanx shadow-[0_0_10px_-2px_rgba(0,194,255,0.8)]'
                  : done
                    ? 'border-success/40 bg-success/10 text-success'
                    : 'border-line text-ink-3'
              }`}
            >
              {done && !cur ? '✓ ' : ''}
              {f}
            </span>
          );
        })}
      </div>

      {/* 语音波形 */}
      <div className="mt-2 flex h-[22px] items-end gap-[2px] rounded-sm border border-line/70 bg-[#061021]/70 px-1.5 py-1">
        {Array.from({ length: 44 }).map((_, i) => {
          const active = typing && stage >= 0;
          const h = active ? 3 + Math.abs(Math.sin(wave * 0.5 + i)) * 10 : 2 + (i % 5) * 1.4;
          return (
            <span
              key={i}
              className="flex-1 rounded-sm transition-all duration-150"
              style={{
                height: h,
                background: active && i % 7 !== 3 ? 'rgba(0,194,255,0.75)' : 'rgba(0,194,255,0.18)',
              }}
            />
          );
        })}
      </div>

      {/* AI 回复 */}
      <div className="scroll-thin mt-2 h-[52px] rounded-sm border border-line/70 bg-[#061021]/70 p-1.5">
        {replies.length === 0 && <div className="text-[10px] text-ink-3">等待语音指令输入……</div>}
        {replies.map((r, i) => (
          <div key={r + i} className="flex items-center gap-1.5 text-[10px] text-cyanx animate-fade-up">
            <Sparkles size={10} className="shrink-0" />
            <span className="truncate">“{r}”</span>
          </div>
        ))}
        {stage >= VOICE_FLOW.length - 1 && replies.length >= VOICE_REPLIES.length && (
          <div className="flex items-center gap-1.5 text-[10px] text-success">
            <CheckCircle2 size={10} /> 指令闭环完成 · 任务已进入执行队列
          </div>
        )}
      </div>

      <div className="mt-2 flex items-center gap-1.5">
        <button className="btn flex-1 py-[5px]" onClick={runVoice}>
          {typing ? <Volume2 size={11} className="animate-blink" /> : <Play size={11} />}
          {typing ? '指令执行中…' : '模拟语音指令'}
        </button>
        <button
          className="btn px-2 py-[5px]"
          onClick={() => {
            dispatch({ type: 'VOICE', patch: { listening: !listening } });
            pushToast(listening ? 'AI 语音监听已暂停' : 'AI 语音监听已开启', 'info');
          }}
        >
          <Send size={11} />
        </button>
      </div>
    </section>
  );
}
