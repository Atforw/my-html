import {
  Activity,
  Boxes,
  Cpu,
  Download,
  FileBarChart2,
  FileArchive,
  Gauge,
  Play,
  Satellite,
  ScanLine,
  Server,
  Terminal,
  Bot,
  Plane,
} from 'lucide-react';
import { Chip, Dot } from './ui/bits';
import { usePlatform } from '../store/PlatformContext';

export default function BottomStatus() {
  const { platform, dispatch, pushToast } = usePlatform();

  const items = [
    {
      icon: Satellite,
      label: 'GNSS',
      value: platform.gnss,
      tone: platform.gnss === 'FIX' ? 'success' : 'warn',
    },
    { icon: ScanLine, label: '点云', value: `${platform.pointCloud.toFixed(2)}M`, tone: 'cyan' as const },
    { icon: Boxes, label: '三维模型', value: '实时更新', tone: 'cyan' as const },
    { icon: Cpu, label: 'AI识别', value: `${platform.aiAccuracy.toFixed(1)}%`, tone: 'cyan' as const },
    { icon: Bot, label: '机器人', value: '3/3 在线', tone: 'success' as const },
    { icon: Plane, label: '无人机', value: '2/2 在线', tone: 'success' as const },
    {
      icon: Server,
      label: '数据同步',
      value: platform.cloudSync,
      tone: platform.cloudSync === '正常' ? ('success' as const) : ('warn' as const),
    },
  ];

  const logs = platform.systemLogs.slice(-3).reverse();

  const onAction = (key: string) => {
    if (key === 'result' || key === 'report' || key === 'export') {
      dispatch({ type: 'SET_RESULT', open: true });
      pushToast(key === 'report' ? '数据报告已进入生成队列（Mock）' : '测绘成果交付面板已打开', 'info');
      return;
    }
    dispatch({ type: 'START_DEMO' });
    pushToast('演示模式已启动：城市三维测绘全流程（约 3 分钟）', 'success');
  };

  return (
    <footer className="relative z-20 flex h-[56px] shrink-0 items-center justify-between border-t border-line bg-[#081422] px-4">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-[1px] bg-gradient-to-r from-transparent via-cyanx/60 to-transparent" />

      {/* 左侧：专业测绘数据状态 */}
      <div className="flex items-center gap-3">
        <span className="flex items-center gap-1.5">
          <Activity size={12} className="animate-blink text-cyanx" />
          <span className="text-[10.5px] tracking-wide text-ink-2">平台运行状态</span>
        </span>
        <span className="h-4 w-px bg-line" />
        {items.map((it) => (
          <span key={it.label} className="flex items-center gap-1.5">
            <it.icon size={11} className={it.tone === 'success' ? 'text-success' : it.tone === 'warn' ? 'text-warn' : 'text-cyanx'} />
            <span className="text-[10px] text-ink-3">{it.label}</span>
            <span
              className={`num text-[11px] ${
                it.tone === 'success' ? 'text-success' : it.tone === 'warn' ? 'text-warn' : 'text-cyanx'
              }`}
            >
              {it.value}
            </span>
            <span className="h-3 w-px bg-line/70" />
          </span>
        ))}
        <Chip tone="muted">
          <Gauge size={9} /> v2.6.3 · Mock 数据服务
        </Chip>
      </div>

      {/* 中间：系统日志滚动 */}
      <div className="hidden min-w-0 flex-1 items-center gap-2 px-4 xl:flex">
        <Terminal size={11} className="shrink-0 text-ink-3" />
        <div className="min-w-0 flex-1 overflow-hidden">
          <div className="flex items-center gap-4">
            {logs.map((l) => (
              <span key={l.id} className="flex shrink-0 items-center gap-1.5 text-[9.5px] text-ink-3">
                <span className="num text-ink-3/70">{l.time}</span>
                <span
                  className={
                    l.kind === 'success'
                      ? 'text-success'
                      : l.kind === 'warn'
                        ? 'text-warn'
                        : l.kind === 'danger'
                          ? 'text-danger'
                          : 'text-ink-2'
                  }
                >
                  {l.text}
                </span>
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* 右侧：操作按钮 */}
      <div className="flex items-center gap-1.5">
        {[
          { key: 'result', label: '测绘成果', icon: FileArchive },
          { key: 'report', label: '数据报告', icon: FileBarChart2 },
          { key: 'export', label: '导出', icon: Download },
        ].map((b) => (
          <button key={b.key} className="btn px-2.5 py-1" onClick={() => onAction(b.key)}>
            <b.icon size={11} /> {b.label}
          </button>
        ))}
        <button
          className={`btn px-3 py-1 ${platform.demo.active ? 'btn-active' : ''}`}
          onClick={() => onAction('demo')}
        >
          {platform.demo.active ? <Dot color="#00C2FF" size={5} /> : <Play size={11} />}
          {platform.demo.active ? '演示进行中' : '开始演示'}
        </button>
      </div>
    </footer>
  );
}
