import { useState } from 'react';
import {
  BadgeCheck,
  Boxes,
  Database,
  FileArchive,
  FileDown,
  FileText,
  FolderOpen,
  Layers,
  MapPin,
  Ruler,
  ScanLine,
  Send,
  TriangleAlert,
  X,
} from 'lucide-react';
import { Chip, Dot, Progress } from './ui/bits';
import { usePlatform } from '../store/PlatformContext';
import { RESULT_ACTIONS, RESULT_FIELDS, RESULT_FILES, SURVEY_AREA_KM2 } from '../data/mockData';

const FIELD_ICON: Record<string, typeof Ruler> = {
  项目名称: FolderOpen,
  任务名称: FileText,
  作业时间: Ruler,
  测区面积: MapPin,
  点云数量: ScanLine,
   GNSS控制点: MapPin,
   AI识别目标: BadgeCheck,
  三维模型: Boxes,
  高程数据: Layers,
  异常区域: TriangleAlert,
};

export default function MeasurementResult() {
  const { platform, dispatch, pushToast } = usePlatform();
  const [busy, setBusy] = useState<string | null>(null);

  if (!platform.resultOpen) return null;

  const liveValue = (label: string, fallback: string) => {
    if (label === '点云数量') return platform.pointCloud.toFixed(2);
    if (label === 'AI识别目标') return platform.aiTargets.toLocaleString('en-US');
    if (label === '三维模型') return `${platform.buildingCount} 栋 / ${platform.modelFaces.toFixed(2)} M 面`;
    if (label === '异常区域') return String(platform.elevationAnomalies);
    if (label === 'GNSS控制点') return '46';
    return fallback;
  };

  const onAction = (key: string, label: string) => {
    setBusy(key);
    pushToast(`正在生成「${label}」文件……`, 'info');
    window.setTimeout(() => {
      setBusy(null);
      pushToast('成果文件已生成', 'success');
      dispatch({ type: 'PUSH_LOG', text: `成果文件已生成：${label}`, kind: 'success' });
    }, 1100);
  };

  const close = () => dispatch({ type: 'SET_RESULT', open: false });

  return (
    <div className="absolute inset-0 z-40 flex justify-end" style={{ background: 'rgba(3,9,18,0.55)' }}>
      {/* 点击遮罩关闭 */}
      <button className="flex-1 cursor-default" onClick={close} aria-label="关闭" />

      <div className="panel relative flex h-full w-[720px] flex-col border-l border-cyanx/30 animate-fade-up">
        <div className="pointer-events-none absolute inset-x-0 top-0 h-[2px] bg-gradient-to-r from-cyanx/0 via-cyanx to-cyanx/0" />

        {/* 头部 */}
        <header className="flex items-start justify-between border-b border-line px-4 py-3">
          <div>
            <h2 className="flex items-center gap-2 text-[15px] font-semibold tracking-wide text-ink">
              <FileArchive size={15} className="text-cyanx" />
              测绘成果标准化交付
            </h2>
            <p className="mt-1 text-[10.5px] text-ink-3">
              DLG / DEM / DOM / 三维模型 / 点云 / 成果报告 · 依据 CH/T 1001-2005 与 1:500 地形图测绘规范
            </p>
          </div>
          <button className="text-ink-3 transition-colors hover:text-danger" onClick={close}>
            <X size={16} />
          </button>
        </header>

        <div className="scroll-thin flex min-h-0 flex-1 flex-col gap-3 p-4">
          {/* 成果字段 */}
          <div className="grid grid-cols-2 gap-2">
            {RESULT_FIELDS.map((f) => {
              const Icon = FIELD_ICON[f.label] ?? FileText;
              const value = liveValue(f.label, f.value);
              return (
                <div
                  key={f.label}
                  className={`panel-flat corner px-2.5 py-2 ${f.highlight ? 'border-cyanx/35' : ''}`}
                >
                  <div className="flex items-center gap-1.5 text-[9.5px] text-ink-3">
                    <Icon size={10} className="text-cyanx/80" />
                    {f.label}
                  </div>
                  <div className="mt-1 flex items-baseline gap-1">
                    <span className={`num text-[13px] ${f.highlight ? 'text-cyanx' : 'text-ink'}`}>{value}</span>
                    {f.unit && <span className="text-[9.5px] text-ink-3">{f.unit}</span>}
                  </div>
                </div>
              );
            })}
          </div>

          {/* 交付进度 */}
          <div className="panel-flat corner px-3 py-2.5">
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-1.5 text-[11px] text-ink-2">
                <Database size={11} className="text-cyanx" /> 成果自动化生产流水线
              </span>
              <Chip tone="success">
                <Dot color="#20C997" size={5} /> 已完成 5/5
              </Chip>
            </div>
            <div className="mt-2 space-y-2">
              {[
                { n: '点云去噪与配准（LAS）', v: 100, c: '#00C2FF' },
                { n: 'AI 语义分割与要素提取（DLG）', v: 100, c: '#1677FF' },
                { n: '三维模型重建与纹理映射（OSGB）', v: 100, c: '#20C997' },
                { n: '高程模型生成（DEM 1:500）', v: 100, c: '#FFB020' },
                { n: '成果报告自动编制（PDF）', v: 100, c: '#00C2FF' },
              ].map((r) => (
                <div key={r.n}>
                  <div className="mb-[3px] flex items-center justify-between text-[9.5px]">
                    <span className="text-ink-3">{r.n}</span>
                    <span className="num text-success">完成</span>
                  </div>
                  <Progress value={r.v} color={r.c} height={3} />
                </div>
              ))}
            </div>
          </div>

          {/* 成果文件清单 */}
          <div className="panel-flat corner px-3 py-2.5">
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-1.5 text-[11px] text-ink-2">
                <FileDown size={11} className="text-cyanx" /> 成果文件清单
              </span>
              <span className="num text-[9.5px] text-ink-3">共 {RESULT_FILES.length} 个文件 · 4.46 GB</span>
            </div>
            <div className="mt-2 space-y-1">
              {RESULT_FILES.map((f) => (
                <div
                  key={f.name}
                  className="flex items-center justify-between rounded-sm border border-line/70 bg-[#0A1729]/60 px-2 py-[5px]"
                >
                  <span className="flex min-w-0 items-center gap-2">
                    <FileText size={11} className="shrink-0 text-cyanx/80" />
                    <span className="num truncate text-[10.5px] text-ink">{f.name}</span>
                    <Chip tone="muted">{f.type}</Chip>
                  </span>
                  <span className="flex shrink-0 items-center gap-2">
                    <span className="num text-[9.5px] text-ink-3">{f.size}</span>
                    <button
                      className="text-ink-3 transition-colors hover:text-cyanx"
                      onClick={() => onAction(f.name, f.name)}
                    >
                      <FileDown size={12} />
                    </button>
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* 说明 */}
          <div className="rounded-sm border border-line/70 bg-[#0A1729]/60 px-3 py-2 text-[9.5px] leading-[16px] text-ink-3">
            交付说明：所有成果均基于城市三维数字孪生底座自动生产，点云平面精度 ±{platform.planeAccuracy.toFixed(1)}cm、
            高程精度 ±{platform.heightAccuracy.toFixed(1)}cm，满足 1:500 地形图测绘精度要求；测区面积 {SURVEY_AREA_KM2.toFixed(2)} km²，
            异常区域 {platform.elevationAnomalies} 处已单独标注并生成核查报告。
          </div>
        </div>

        {/* 底部操作 */}
        <footer className="flex items-center gap-2 border-t border-line px-4 py-3">
          {RESULT_ACTIONS.map((a, i) => (
            <button
              key={a.key}
              className={`btn flex-1 py-[7px] ${i === 3 ? 'btn-active' : ''}`}
              onClick={() => onAction(a.key, a.label)}
            >
              {busy === a.key ? (
                <Send size={12} className="animate-blink" />
              ) : i === 0 ? (
                <FolderOpen size={12} />
              ) : i === 3 ? (
                <Boxes size={12} />
              ) : (
                <FileDown size={12} />
              )}
              {a.label}
            </button>
          ))}
        </footer>
      </div>
    </div>
  );
}
