import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import {
  Battery,
  Bot,
  Building2,
  Compass,
  Crosshair,
  Gauge,
  Layers,
  Maximize2,
  Navigation,
  Plane,
  Radio,
  RefreshCw,
  Route,
  ScanLine,
  Satellite,
  Target,
  X,
} from 'lucide-react';
import { Chip, Dot, KV, Progress } from './ui/bits';
import {
  AI_TARGETS,
  BUILDING_TOTAL,
  CITY_HEADLINE_STATS,
  ELEVATION_STATS,
  GNSS_POINTS,
  LAYER_DEFS,
  ROAD_LENGTH_KM,
} from '../data/mockData';
import type { LayerKey } from '../types';
import { usePlatform } from '../store/PlatformContext';
import {
  createCityScene,
  disposeCityScene,
  flyCamera,
  highlightBuilding,
  resizeCity,
  setLayerVisible,
  updateCity,
  type CityHandles,
  type LayerGroupKey,
} from '../utils/cityScene';
import { toBuildingDetail } from '../utils/simulation';

/* 演示模式各阶段镜头（城市三维数字孪生视角） */
const DEMO_CAMERAS: { pos: [number, number, number]; target: [number, number, number] }[] = [
  { pos: [760, 540, 800], target: [0, 28, 24] },
  { pos: [400, 300, 500], target: [0, 28, 24] },
  { pos: [-260, 215, 380], target: [-60, 20, 0] },
  { pos: [200, 285, -350], target: [60, 20, -60] },
  { pos: [10, 470, 470], target: [0, 0, 0] },
  { pos: [350, 265, 350], target: [0, 30, 0] },
  { pos: [500, 205, -400], target: [180, 10, -180] },
  { pos: [570, 395, 620], target: [0, 20, 40] },
  { pos: [-280, 125, -40], target: [-60, 10, -60] },
  { pos: [0, 630, 650], target: [0, 0, 140] },
  { pos: [590, 345, 670], target: [0, 20, 60] },
];
const DEFAULT_CAM = { pos: [400, 300, 500] as [number, number, number], target: [0, 28, 24] as [number, number, number] };

export default function CityTwin() {
  const { platform, dispatch, pushToast } = usePlatform();
  const hostRef = useRef<HTMLDivElement>(null);
  const handlesRef = useRef<CityHandles | null>(null);
  const stateRef = useRef(platform);
  const raycasterRef = useRef(new THREE.Raycaster());
  const [fps, setFps] = useState(60);
  const [ready, setReady] = useState(false);
  const [cursor, setCursor] = useState<'grab' | 'pointer'>('grab');

  stateRef.current = platform;

  /* ══ 场景初始化（仅一次） ══ */
  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;
    const h = createCityScene(host);
    handlesRef.current = h;
    // 调试/留档句柄：控制台可检查三维场景状态、导出画布图片
    (window as unknown as Record<string, unknown>).__DSH_CITY__ = h;

    const ro = new ResizeObserver(() => {
      const w = host.clientWidth;
      const hh = host.clientHeight;
      if (w > 0 && hh > 0) resizeCity(h, w, hh);
    });
    ro.observe(host);

    const robotAccum = { t: stateRef.current.robot.t, acc: 0 };
    let uavAccum = stateRef.current.uav.t;
    let lastPush = 0;
    let frames = 0;
    let fpsTime = performance.now();

    h.renderer.setAnimationLoop(() => {
      const dt = h.clock.getDelta();
      const p = stateRef.current;
      updateCity(h, dt, {
        robotT: p.robot.t,
        robotSpeed: p.robot.speed,
        uavT: p.uav.t,
        demoActive: p.demo.active,
        demoStage: p.demo.stage,
        robotAccum,
        uavAccum,
        onRobotMove: (t) => {
          const now = performance.now();
          if (now - lastPush > 1200) {
            lastPush = now;
            dispatch({ type: 'ROBOT_T', t, progress: stateRef.current.robot.progress });
          }
        },
      });
      frames += 1;
      const now = performance.now();
      if (now - fpsTime > 1000) {
        setFps(Math.round((frames * 1000) / (now - fpsTime)));
        frames = 0;
        fpsTime = now;
      }
    });
    setReady(true);

    return () => {
      ro.disconnect();
      h.renderer.setAnimationLoop(null);
      disposeCityScene(h);
      handlesRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* ══ 图层联动 ══ */
  useEffect(() => {
    const h = handlesRef.current;
    if (!h) return;
    (Object.keys(platform.layers) as LayerKey[]).forEach((k) => {
      setLayerVisible(h, k as LayerGroupKey, platform.layers[k]);
    });
  }, [platform.layers]);

  /* ══ 建筑高亮联动 ══ */
  useEffect(() => {
    const h = handlesRef.current;
    if (!h) return;
    highlightBuilding(h, platform.selectedBuilding?.id ?? null);
  }, [platform.selectedBuilding]);

  /* ══ 演示模式镜头联动 ══ */
  useEffect(() => {
    const h = handlesRef.current;
    if (!h || !ready) return;
    if (!platform.demo.active) {
      flyCamera(h, DEFAULT_CAM.pos, DEFAULT_CAM.target, 1.6);
      return;
    }
    const cam = DEMO_CAMERAS[Math.min(platform.demo.stage, DEMO_CAMERAS.length - 1)];
    flyCamera(h, cam.pos, cam.target, 2.6);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [platform.demo.stage, platform.demo.active, ready]);

  /* ══ 点击拾取 ══ */
  useEffect(() => {
    const h = handlesRef.current;
    if (!h) return;
    const el = h.renderer.domElement;
    let downPos = { x: 0, y: 0 };
    let downTime = 0;

    const pick = (clientX: number, clientY: number) => {
      const rect = el.getBoundingClientRect();
      const ndc = new THREE.Vector2(
        ((clientX - rect.left) / rect.width) * 2 - 1,
        -((clientY - rect.top) / rect.height) * 2 + 1,
      );
      const ray = raycasterRef.current;
      ray.setFromCamera(ndc, h.camera);
      const hits = ray.intersectObjects(h.pickTargets, true);
      for (const hit of hits) {
        let cur: THREE.Object3D | null = hit.object;
        while (cur && !cur.userData.building && !cur.userData.device) cur = cur.parent;
        if (!cur) continue;
        if (cur.userData.device === 'robot' || cur.userData.device === 'uav') {
          dispatch({ type: 'SELECT_DEVICE', device: cur.userData.device });
          return true;
        }
        const spec = cur.userData.building;
        if (spec) {
          const p = stateRef.current;
          dispatch({ type: 'SELECT_BUILDING', detail: toBuildingDetail(spec, p.gnss, p.heightAccuracy) });
          return true;
        }
      }
      dispatch({ type: 'SELECT_BUILDING', detail: null });
      dispatch({ type: 'SELECT_DEVICE', device: null });
      return false;
    };

    const onDown = (e: PointerEvent) => {
      downPos = { x: e.clientX, y: e.clientY };
      downTime = performance.now();
      setCursor('grab');
    };
    const onUp = (e: PointerEvent) => {
      const moved = Math.hypot(e.clientX - downPos.x, e.clientY - downPos.y);
      if (moved < 5 && performance.now() - downTime < 700) pick(e.clientX, e.clientY);
    };
    let lastHover = 0;
    const onMove = (e: PointerEvent) => {
      const now = performance.now();
      if (now - lastHover < 120) return;
      lastHover = now;
      const rect = el.getBoundingClientRect();
      const ndc = new THREE.Vector2(
        ((e.clientX - rect.left) / rect.width) * 2 - 1,
        -((e.clientY - rect.top) / rect.height) * 2 + 1,
      );
      raycasterRef.current.setFromCamera(ndc, h.camera);
      const hits = raycasterRef.current.intersectObjects(h.hoverTargets, false);
      setCursor(hits.length ? 'pointer' : 'grab');
    };

    el.addEventListener('pointerdown', onDown);
    el.addEventListener('pointerup', onUp);
    el.addEventListener('pointermove', onMove);
    return () => {
      el.removeEventListener('pointerdown', onDown);
      el.removeEventListener('pointerup', onUp);
      el.removeEventListener('pointermove', onMove);
    };
  }, [dispatch, ready]);

  const headline = CITY_HEADLINE_STATS.map((s) => {
    const value =
      s.key === 'building'
        ? String(platform.buildingCount)
        : s.key === 'road'
          ? platform.roadLength.toFixed(1)
          : s.key === 'point'
            ? platform.pointCloud.toFixed(2)
            : s.key === 'gnss'
              ? platform.gnss
              : s.key === 'model'
                ? '实时'
                : platform.aiTargets.toLocaleString('en-US');
    return { ...s, value, tone: s.key === 'gnss' && platform.gnss !== 'FIX' ? 'warn' : 'cyan' };
  });

  const toggleLayer = (key: LayerKey, label: string) => {
    dispatch({ type: 'SET_LAYER', key });
    pushToast(`图层「${label}」${platform.layers[key] ? '已隐藏' : '已显示'}`, 'info');
  };

  const allOn = Object.values(platform.layers).every(Boolean);

  return (
    <section className="relative flex min-h-0 min-w-0 flex-1 flex-col gap-2">
      {/* ══ 中央标题 ══ */}
      <div className="panel corner flex items-center justify-between px-3 py-[7px]">
        <div className="flex items-baseline gap-3">
          <h2 className="flex items-center gap-2 text-[15px] font-semibold tracking-wide text-ink">
            <span className="h-[14px] w-[3px] rounded-sm bg-cyanx shadow-[0_0_8px_rgba(0,194,255,0.9)]" />
            城市三维数字孪生
          </h2>
          <span className="text-[10.5px] text-ink-3">
            多源测绘数据 → 点云处理 → 三维建模 → 空间分析
          </span>
        </div>
        <div className="flex items-center gap-2">
          <Chip tone="success">
            <Dot color="#20C997" size={5} /> 数字孪生在线
          </Chip>
          <Chip tone="cyan">
            <Radio size={9} /> {GNSS_POINTS.length} 控制点
          </Chip>
          <Chip tone="muted">
            <Gauge size={9} /> {fps} FPS
          </Chip>
        </div>
      </div>

      {/* ══ 实时数据条 ══ */}
      <div className="panel corner grid shrink-0 grid-cols-6 divide-x divide-line/70 px-1 py-[6px]">
        {headline.map((s) => (
          <div key={s.key} className="flex flex-col items-center gap-[1px]">
            <span className="text-[9.5px] tracking-wide text-ink-3">{s.label}</span>
            <span className="flex items-baseline gap-1">
              <span className={`num text-[16px] font-semibold ${s.tone === 'warn' ? 'text-warn' : 'text-cyanx'}`}>
                {s.value}
              </span>
              {s.unit && <span className="text-[9.5px] text-ink-3">{s.unit}</span>}
            </span>
          </div>
        ))}
      </div>

      {/* ══ 三维场景 ══ */}
      <div className="panel corner relative min-h-0 flex-1 overflow-hidden">
        <div ref={hostRef} className="three-host absolute inset-0" style={{ cursor }} />
        <div className="hud-scan" />
        {/* 边缘暗角，增强专业大屏质感 */}
        <div
          className="pointer-events-none absolute inset-0"
          style={{
            background:
              'radial-gradient(120% 100% at 50% 40%, rgba(0,0,0,0) 45%, rgba(3,10,20,0.55) 100%)',
          }}
        />

        {/* 左上：场景信息 */}
        <div className="pointer-events-none absolute left-2.5 top-2.5 flex flex-col gap-1.5">
          <div className="panel-flat corner px-2 py-1.5 backdrop-blur-sm">
            <div className="flex items-center gap-1.5 text-[10px] text-ink-2">
              <Building2 size={11} className="text-cyanx" /> 测区：城市中心区 · 12.86 km²
            </div>
            <div className="mt-1 flex items-center gap-3 text-[9.5px] text-ink-3">
              <span>建筑 {BUILDING_TOTAL} 栋</span>
              <span>道路 {ROAD_LENGTH_KM} km</span>
              <span>点云 {platform.pointCloud.toFixed(2)} M</span>
              <span>AI 目标 {platform.aiTargets}</span>
            </div>
          </div>
          {platform.demo.active && (
            <div className="panel-flat corner border-cyanx/40 px-2 py-1.5 backdrop-blur-sm">
              <div className="flex items-center gap-1.5 text-[10px] text-cyanx">
                <Dot color="#00C2FF" size={5} /> 演示模式 · 阶段 {platform.demo.stage + 1}/11
              </div>
            </div>
          )}
        </div>

        {/* 右上：图例 */}
        <div className="panel-flat corner absolute right-2.5 top-2.5 px-2 py-1.5">
          <div className="mb-1 flex items-center gap-1 text-[9.5px] text-ink-3">
            <Layers size={10} /> 数据图例
          </div>
          {[
            { c: '#00C2FF', t: '三维建筑模型（LOD2）' },
            { c: '#38D9FF', t: '点云（LiDAR 多站融合）' },
            { c: '#20C997', t: 'GNSS/RTK 控制点' },
            { c: '#FFB020', t: '无人机航线 / 航点' },
            { c: '#FF8A3D', t: 'AI 识别 / 异常区域' },
          ].map((l) => (
            <div key={l.t} className="flex items-center gap-1.5 py-[1px] text-[9.5px] text-ink-2">
              <span className="h-[6px] w-[6px] rounded-sm" style={{ background: l.c }} />
              {l.t}
            </div>
          ))}
        </div>

        {/* 左下：比例尺 + 坐标 */}
        <div className="panel-flat corner absolute bottom-2.5 left-2.5 px-2 py-1.5">
          <div className="flex items-center gap-2 text-[9.5px] text-ink-3">
            <Compass size={11} className="text-cyanx" />
            <span className="num">CGCS2000 · 3° 带 · 中央子午线 114°E</span>
          </div>
          <div className="mt-1 flex items-center gap-2">
            <div className="relative h-[6px] w-[92px] border-b border-l border-r border-cyanx/60">
              <span className="absolute left-1/2 top-0 h-full w-px bg-cyanx/50" />
            </div>
            <span className="num text-[9.5px] text-ink-2">200 m</span>
            <span className="num text-[9.5px] text-ink-3">| 高程基准：1985 国家高程</span>
          </div>
        </div>

        {/* 右下：场景控制 */}
        <div className="absolute bottom-2.5 right-2.5 flex flex-col gap-1">
          <button
            className="btn px-2 py-1"
            onClick={() => {
              const h = handlesRef.current;
              if (!h) return;
              flyCamera(h, DEFAULT_CAM.pos, DEFAULT_CAM.target, 1.2);
              pushToast('视角已重置为城市全景', 'info');
            }}
          >
            <Maximize2 size={11} /> 全景视角
          </button>
          <button
            className="btn px-2 py-1"
            onClick={() => {
              dispatch({ type: 'SET_LAYER', key: 'buildings', value: true });
              dispatch({ type: 'SET_LAYER', key: 'roads', value: true });
              pushToast('已聚焦城市道路与建筑图层', 'info');
            }}
          >
            <Crosshair size={11} /> 聚焦城区
          </button>
        </div>

        {/* ══ 信息卡：建筑物 ══ */}
        {platform.selectedBuilding && (
          <div className="panel corner absolute right-2.5 top-[104px] w-[246px] animate-fade-up p-2.5">
            <div className="flex items-center justify-between">
              <h3 className="sec-title">建筑物空间信息</h3>
              <button
                className="text-ink-3 transition-colors hover:text-danger"
                onClick={() => dispatch({ type: 'SELECT_BUILDING', detail: null })}
              >
                <X size={13} />
              </button>
            </div>
            <div className="mt-1.5 flex items-center justify-between rounded-sm border border-cyanx/25 bg-cyanx/5 px-2 py-1">
              <span className="num text-[13px] text-cyanx">{platform.selectedBuilding.id}</span>
              <Chip tone="primary">{platform.selectedBuilding.category}</Chip>
            </div>
            <div className="mt-1.5">
              <KV label="建筑高度" value={platform.selectedBuilding.height.toFixed(1)} unit="m" tone="cyan" />
              <KV label="建筑面积" value={platform.selectedBuilding.area.toLocaleString('en-US')} unit="m²" />
              <KV label="楼层数" value={platform.selectedBuilding.floors} unit="层" />
              <KV
                label="点云数量"
                value={platform.selectedBuilding.pointCount.toLocaleString('en-US')}
                unit="pts"
                tone="cyan"
              />
              <KV
                label="GNSS状态"
                value={platform.selectedBuilding.gnss}
                tone={platform.selectedBuilding.gnss === 'FIX' ? 'success' : 'warn'}
              />
              <KV label="模型状态" value={platform.selectedBuilding.modelState} tone="success" />
              <KV label="模型精度" value={`±${platform.selectedBuilding.accuracy.toFixed(1)}`} unit="cm" />
              <KV label="AI 置信度" value={`${platform.selectedBuilding.aiConfidence.toFixed(1)}`} unit="%" tone="cyan" />
            </div>
            <div className="divider my-1.5" />
            <div className="grid grid-cols-3 gap-1 text-center">
              {[
                { k: 'X', v: platform.selectedBuilding.coordX.toFixed(3) },
                { k: 'Y', v: platform.selectedBuilding.coordY.toFixed(3) },
                { k: 'H', v: platform.selectedBuilding.coordH.toFixed(3) },
              ].map((c) => (
                <div key={c.k} className="rounded-sm border border-line/70 bg-[#0A1729]/70 py-1">
                  <div className="text-[9px] text-ink-3">{c.k}</div>
                  <div className="num text-[9.5px] text-ink">{c.v}</div>
                </div>
              ))}
            </div>
            <p className="mt-1.5 text-[9px] text-ink-3">
              更新于 {platform.selectedBuilding.updatedAt} · 数据来源：机器人 LiDAR + 无人机倾斜摄影
            </p>
          </div>
        )}

        {/* ══ 信息卡：设备 ══ */}
        {platform.selectedDevice === 'robot' && (
          <div className="panel corner absolute right-2.5 top-[104px] w-[246px] animate-fade-up p-2.5">
            <div className="flex items-center justify-between">
              <h3 className="sec-title">测绘机器人状态</h3>
              <button
                className="text-ink-3 transition-colors hover:text-danger"
                onClick={() => dispatch({ type: 'SELECT_DEVICE', device: null })}
              >
                <X size={13} />
              </button>
            </div>
            <div className="mt-1.5 flex items-center gap-2 rounded-sm border border-success/25 bg-success/5 px-2 py-1.5">
              <Bot size={16} className="text-success" />
              <div>
                <div className="text-[11px] text-ink">测绘机器人-01</div>
                <div className="flex items-center gap-1 text-[9.5px] text-success">
                  <Dot color="#20C997" size={5} /> 在线 · 执行中
                </div>
              </div>
            </div>
            <div className="mt-1.5">
              <KV label="状态" value="执行中" tone="cyan" />
              <KV label="电量" value={platform.robot.battery.toFixed(1)} unit="%" tone={platform.robot.battery < 30 ? 'warn' : 'success'} />
              <KV label="行驶速度" value={platform.robot.speed.toFixed(2)} unit="m/s" />
              <KV label="定位" value={`RTK ${platform.robot.rtk}`} tone={platform.robot.rtk === 'FIX' ? 'success' : 'warn'} />
              <KV label="卫星数" value={platform.robot.satellites} unit="颗" />
              <KV label="任务" value={platform.robot.taskName} tone="cyan" />
            </div>
            <div className="mt-2">
              <div className="mb-1 flex items-center justify-between text-[10px]">
                <span className="text-ink-3">任务进度</span>
                <span className="num text-cyanx">{platform.robot.progress.toFixed(1)}%</span>
              </div>
              <Progress value={platform.robot.progress} color="#00C2FF" height={5} striped />
            </div>
            <p className="mt-1.5 text-[9px] text-ink-3">轨迹参数 t = {platform.robot.t.toFixed(3)} · 沿城市道路巡检测绘</p>
          </div>
        )}

        {platform.selectedDevice === 'uav' && (
          <div className="panel corner absolute right-2.5 top-[104px] w-[246px] animate-fade-up p-2.5">
            <div className="flex items-center justify-between">
              <h3 className="sec-title">无人机状态</h3>
              <button
                className="text-ink-3 transition-colors hover:text-danger"
                onClick={() => dispatch({ type: 'SELECT_DEVICE', device: null })}
              >
                <X size={13} />
              </button>
            </div>
            <div className="mt-1.5 flex items-center gap-2 rounded-sm border border-warn/25 bg-warn/5 px-2 py-1.5">
              <Plane size={16} className="text-warn" />
              <div>
                <div className="text-[11px] text-ink">UAV-02</div>
                <div className="flex items-center gap-1 text-[9.5px] text-warn">
                  <Dot color="#FFB020" size={5} /> 测绘作业中
                </div>
              </div>
            </div>
            <div className="mt-1.5">
              <KV label="状态" value="测绘作业中" tone="cyan" />
              <KV label="飞行高度" value={platform.uav.altitude.toFixed(1)} unit="m" tone="cyan" />
              <KV label="飞行速度" value={platform.uav.speed.toFixed(1)} unit="m/s" />
              <KV label="电量" value={platform.uav.battery.toFixed(1)} unit="%" tone={platform.uav.battery < 30 ? 'warn' : 'success'} />
              <KV label="航带覆盖率" value={platform.uav.coverage.toFixed(1)} unit="%" />
              <KV label="任务" value={platform.uav.taskName} tone="cyan" />
            </div>
            <div className="mt-2">
              <div className="mb-1 flex items-center justify-between text-[10px]">
                <span className="text-ink-3">航带覆盖</span>
                <span className="num text-warn">{platform.uav.coverage.toFixed(1)}%</span>
              </div>
              <Progress value={platform.uav.coverage} color="#FFB020" height={5} />
            </div>
            <p className="mt-1.5 text-[9px] text-ink-3">航线参数 t = {platform.uav.t.toFixed(3)} · 倾斜摄影 + LiDAR 双载荷</p>
          </div>
        )}

        {/* ══ 加载遮罩（演示模式第一阶段） ══ */}
        {platform.demo.active && platform.demo.stage === 0 && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-[#050e1a]/70 backdrop-blur-[2px]">
            <div className="relative h-[62px] w-[62px]">
              <span className="absolute inset-0 animate-pulse-ring rounded-full border border-cyanx/60" />
              <span className="absolute inset-0 rounded-full border-2 border-cyanx/30 border-t-cyanx animate-spin" />
              <Building2 className="absolute inset-0 m-auto text-cyanx" size={24} />
            </div>
            <p className="mt-3 text-[13px] tracking-wider text-cyanx">正在加载城市三维空间数据……</p>
            <p className="mt-1 text-[10px] text-ink-3">3D Tiles 流式加载 · 428 栋建筑 · 2.68M 面</p>
          </div>
        )}

        {/* ══ 实时数据快照（右下角小表） ══ */}
        <div className="panel-flat corner absolute bottom-[92px] right-2.5 w-[176px] px-2 py-1.5">
          <div className="mb-1 flex items-center gap-1 text-[9.5px] text-ink-3">
            <RefreshCw size={10} className="text-cyanx" /> 实时要素统计
          </div>
          <KV label="点云总量" value={platform.pointCloud.toFixed(2)} unit="M" tone="cyan" />
          <KV label="模型面数" value={platform.modelFaces.toFixed(2)} unit="M" tone="cyan" />
          <KV label="平均高程" value={platform.avgElevation.toFixed(3)} unit="m" />
          <KV label="高程异常" value={ELEVATION_STATS.anomalies} unit="处" tone="warn" />
          <KV label="AI 目标" value={platform.aiTargets} unit="个" tone="success" />
        </div>
      </div>

      {/* ══ 图层控制 ══ */}
      <div className="panel corner flex items-center gap-2 px-3 py-[7px]">
        <span className="flex items-center gap-1.5 text-[10.5px] text-ink-2">
          <Layers size={12} className="text-cyanx" /> 图层控制
        </span>
        <div className="flex flex-1 flex-wrap items-center gap-1.5">
          {LAYER_DEFS.map((l) => {
            const on = platform.layers[l.key as LayerKey];
            return (
              <button
                key={l.key}
                onClick={() => toggleLayer(l.key as LayerKey, l.label)}
                className={`chip transition-colors ${
                  on ? 'border-cyanx/45 bg-cyanx/10 text-cyanx' : 'border-line text-ink-3 hover:text-ink-2'
                }`}
              >
                <span
                  className={`flex h-[10px] w-[10px] items-center justify-center rounded-[2px] border text-[8px] ${
                    on ? 'border-cyanx/70 bg-cyanx/20 text-cyanx' : 'border-line'
                  }`}
                >
                  {on ? '✓' : ''}
                </span>
                {l.label}
              </button>
            );
          })}
        </div>
        <button
          className="btn px-2 py-1"
          onClick={() => {
            LAYER_DEFS.forEach((l) => dispatch({ type: 'SET_LAYER', key: l.key as LayerKey, value: !allOn }));
            pushToast(allOn ? '已关闭全部数据图层' : '已开启全部数据图层', 'info');
          }}
        >
          <Target size={11} /> {allOn ? '全部关闭' : '全部开启'}
        </button>
        <span className="flex items-center gap-2 text-[9.5px] text-ink-3">
          <span className="flex items-center gap-1">
            <Route size={10} /> 机器人轨迹
          </span>
          <span className="flex items-center gap-1">
            <Navigation size={10} /> 无人机航线
          </span>
          <span className="flex items-center gap-1">
            <ScanLine size={10} /> {AI_TARGETS.length} AI 识别框
          </span>
          <span className="flex items-center gap-1">
            <Battery size={10} /> 电量 {platform.robot.battery.toFixed(0)}%
          </span>
          <span className="flex items-center gap-1">
            <Satellite size={10} /> {GNSS_POINTS.length} 控制点
          </span>
        </span>
      </div>
    </section>
  );
}
