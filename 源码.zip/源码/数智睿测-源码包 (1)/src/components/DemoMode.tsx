import { useEffect, useState } from 'react';
import { CheckCircle2, ChevronRight, CircleDot, Pause, Play, SkipForward, Sparkles, X } from 'lucide-react';
import { Chip, Dot, Progress } from './ui/bits';
import { usePlatform } from '../store/PlatformContext';
import { DEMO_STAGES, DEMO_TOTAL_SECONDS } from '../data/mockData';
import { demoOverallProgress } from '../utils/simulation';

/** 打字机效果 */
function useTypewriter(text: string, speed = 46) {
  const [out, setOut] = useState('');
  useEffect(() => {
    setOut('');
    let i = 0;
    const t = window.setInterval(() => {
      i += 1;
      setOut(text.slice(0, i));
      if (i >= text.length) window.clearInterval(t);
    }, speed);
    return () => window.clearInterval(t);
  }, [text, speed]);
  return out;
}

export default function DemoMode() {
  const { platform, dispatch, pushToast } = usePlatform();
  const { demo } = platform;
  const elapsedTotal =
    DEMO_STAGES.slice(0, demo.stage).reduce((a, d) => a + d.duration, 0) + demo.stageElapsed;
  const remain = Math.max(0, DEMO_TOTAL_SECONDS - elapsedTotal);
  const stageDef = DEMO_STAGES[demo.stage];
  const typed = useTypewriter(stageDef.message);

  if (!demo.active) return null;

  const jump = (i: number) => dispatch({ type: 'DEMO_JUMP', stage: i });
  const next = () => jump(Math.min(DEMO_STAGES.length - 1, demo.stage + 1));
  const prev = () => jump(Math.max(0, demo.stage - 1));

  return (
    <div className="pointer-events-none absolute inset-0 z-30">
      {/* 顶部流程条 */}
      <div className="pointer-events-auto absolute left-1/2 top-[74px] w-[1040px] -translate-x-1/2">
        <div className="panel corner px-3 py-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles size={14} className="text-cyanx" />
              <span className="text-[13px] font-semibold tracking-wide text-ink">
                城市三维测绘全流程演示
              </span>
              <Chip tone="cyan">
                <Dot color="#00C2FF" size={5} /> 阶段 {demo.stage + 1}/{DEMO_STAGES.length}
              </Chip>
              <Chip tone={demo.finished ? 'success' : 'primary'}>
                {demo.finished ? '演示完成' : demo.playing ? '演示进行中' : '已暂停'}
              </Chip>
            </div>
            <div className="flex items-center gap-2">
              <span className="num text-[10px] text-ink-3">
                总进度 {(demoOverallProgress(platform) * 100).toFixed(0)}% · 剩余 {Math.floor(remain / 60)}:
                {String(remain % 60).padStart(2, '0')}
              </span>
              <button className="btn px-2 py-1" onClick={prev}>
                上一阶段
              </button>
              <button className="btn px-2 py-1" onClick={() => dispatch({ type: 'DEMO_PLAY_TOGGLE' })}>
                {demo.playing ? <Pause size={11} /> : <Play size={11} />}
                {demo.playing ? '暂停' : '继续'}
              </button>
              <button className="btn px-2 py-1" onClick={next}>
                <SkipForward size={11} /> 下一阶段
              </button>
              <button className="btn px-2 py-1" onClick={() => dispatch({ type: 'EXIT_DEMO' })}>
                <X size={11} /> 退出
              </button>
            </div>
          </div>

          {/* 阶段刻度 */}
          <div className="mt-2 flex items-center gap-1">
            {DEMO_STAGES.map((s, i) => {
              const done = i < demo.stage || demo.finished;
              const cur = i === demo.stage && !demo.finished;
              return (
                <button
                  key={s.key}
                  onClick={() => jump(i)}
                  className={`group flex-1 rounded-sm border px-1 py-[3px] text-center transition-all duration-300 ${
                    cur
                      ? 'border-cyanx/70 bg-cyanx/15 text-cyanx'
                      : done
                        ? 'border-success/35 bg-success/10 text-success'
                        : 'border-line text-ink-3 hover:border-line-strong'
                  }`}
                >
                  <div className="num text-[9px]">{String(i + 1).padStart(2, '0')}</div>
                  <div className="truncate text-[9px]">{s.title}</div>
                </button>
              );
            })}
          </div>
          <div className="mt-2">
            <Progress value={demoOverallProgress(platform) * 100} color="#00C2FF" height={4} striped />
          </div>
        </div>
      </div>

      {/* 左下：当前阶段解说 */}
      <div className="pointer-events-auto absolute bottom-[68px] left-3 w-[470px]">
        <div className="panel corner border-cyanx/30 px-3 py-2.5">
          <div className="flex items-center gap-2">
            <CircleDot size={13} className="animate-blink text-cyanx" />
            <span className="text-[11px] tracking-wide text-ink-3">
              阶段 {demo.stage + 1} · {stageDef.title}
            </span>
          </div>
          <div className="mt-1.5 min-h-[22px] text-[15px] font-semibold text-cyanx">
            {typed}
            <span className="ml-[2px] inline-block h-[14px] w-[7px] animate-blink bg-cyanx align-middle" />
          </div>
          <p className="mt-1 text-[10.5px] text-ink-2">{stageDef.detail}</p>
          <div className="mt-2 flex flex-wrap gap-1">
            {stageDef.tags.map((t) => (
              <Chip key={t} tone="primary">
                {t}
              </Chip>
            ))}
          </div>
          <div className="mt-2 flex items-center gap-2">
            <span className="text-[9.5px] text-ink-3">当前阶段进度</span>
            <div className="flex-1">
              <Progress
                value={(demo.stageElapsed / stageDef.duration) * 100}
                color="#1677FF"
                height={3}
              />
            </div>
            <span className="num text-[9.5px] text-ink-3">
              {demo.stageElapsed.toFixed(0)}s / {stageDef.duration}s
            </span>
          </div>
        </div>
      </div>

      {/* 右下：实时指标 */}
      <div className="pointer-events-auto absolute bottom-[68px] right-3 w-[300px]">
        <div className="panel corner px-3 py-2.5">
          <div className="mb-1.5 flex items-center gap-1.5 text-[10.5px] text-ink-2">
            <Sparkles size={11} className="text-cyanx" /> 演示实时指标
          </div>
          <div className="grid grid-cols-2 gap-1.5">
            {[
              { l: '点云', v: `${platform.pointCloud.toFixed(2)} M` },
              { l: 'AI 目标', v: `${platform.aiTargets}` },
              { l: '模型面数', v: `${platform.modelFaces.toFixed(2)} M` },
              { l: 'GNSS', v: platform.gnss },
              { l: '机器人', v: `${platform.robot.progress.toFixed(0)}%` },
              { l: '无人机覆盖', v: `${platform.uav.coverage.toFixed(0)}%` },
            ].map((r) => (
              <div key={r.l} className="rounded-sm border border-line/70 bg-[#0A1729]/60 px-1.5 py-1">
                <div className="text-[9px] text-ink-3">{r.l}</div>
                <div className="num text-[11.5px] text-cyanx">{r.v}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 演示完成结算卡 */}
      {demo.finished && (
        <div className="pointer-events-auto absolute inset-0 flex items-center justify-center bg-[#050e1a]/72">
          <div className="panel corner w-[720px] animate-fade-up p-5">
            <div className="flex items-center gap-3">
              <CheckCircle2 size={26} className="text-success" />
              <div>
                <h3 className="text-[18px] font-semibold tracking-wide text-ink">城市三维测绘任务完成</h3>
                <p className="mt-1 text-[11px] text-ink-3">
                  采集 → 感知 → 分析 → 建模 → 调度 → 成果 · 全流程业务闭环演示结束
                </p>
              </div>
            </div>

            <div className="mt-4 grid grid-cols-5 gap-2">
              {[
                { l: '点云', v: `${platform.pointCloud.toFixed(2)}M`, c: '#00C2FF' },
                { l: 'GNSS', v: platform.gnss, c: '#20C997' },
                { l: '三维模型', v: `${platform.buildingCount} 栋`, c: '#1677FF' },
                { l: 'AI识别', v: `${platform.aiAccuracy.toFixed(1)}%`, c: '#FFB020' },
                { l: '测绘报告', v: '已生成', c: '#20C997' },
              ].map((r) => (
                <div key={r.l} className="panel-flat corner py-2 text-center">
                  <div className="num text-[15px] font-semibold" style={{ color: r.c }}>
                    {r.v}
                  </div>
                  <div className="mt-1 text-[9.5px] text-ink-3">{r.l}</div>
                </div>
              ))}
            </div>

            <div className="mt-4 flex items-center gap-2">
              <button
                className="btn btn-active flex-1 py-[7px]"
                onClick={() => {
                  dispatch({ type: 'SET_RESULT', open: true });
                  pushToast('查看标准化测绘成果交付清单', 'success');
                }}
              >
                <ChevronRight size={12} /> 查看测绘成果
              </button>
              <button
                className="btn flex-1 py-[7px]"
                onClick={() => {
                  dispatch({ type: 'EXIT_DEMO' });
                  pushToast('已退出演示模式，返回平台常态运行', 'info');
                }}
              >
                退出演示模式
              </button>
            </div>
            <p className="mt-3 text-[9.5px] leading-[16px] text-ink-3">
              演示说明：本演示完整覆盖 11 个阶段，包含城市三维模型加载、多源设备接入、点云采集、AI 空间目标识别、
              点云精细配准、三维模型更新、异常空间区域发现、AI 自动创建任务、机器人执行任务、数据回传与测绘成果生成。
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
