import { Bot, Cloud, Cpu, Globe, MonitorSmartphone, Plane, Satellite, Signal, Wifi } from 'lucide-react';
import { Chip, Dot, Progress } from './ui/bits';
import { usePlatform } from '../store/PlatformContext';
import { CLOUD_LINKS } from '../data/mockData';

const KIND_ICON = {
  web: MonitorSmartphone,
  robot: Bot,
  uav: Plane,
  gnss: Satellite,
} as const;

const KIND_LABEL = {
  web: '指挥端',
  robot: '移动测量端',
  uav: '空中测量端',
  gnss: '基准站',
} as const;

export default function DeviceStatus() {
  const { platform } = usePlatform();

  const linkValue: Record<string, string> = {
    sync: platform.cloudSync,
    comm: platform.commState,
    realtime: platform.realtimeState,
  };

  return (
    <section className="panel corner flex h-[264px] shrink-0 flex-col p-2.5">
      <header className="flex items-center justify-between">
        <div className="flex min-w-0 items-center gap-2">
          <span className="h-[12px] w-[3px] shrink-0 rounded-sm bg-cyanx shadow-[0_0_6px_rgba(0,194,255,0.8)]" />
          <h2 className="truncate text-[12.5px] font-semibold tracking-wide text-ink">三端协同</h2>
          <span className="truncate text-[10px] text-ink-3">Web / 机器人 / 无人机 多端联动</span>
        </div>
        <Chip tone="cyan">
          <Wifi size={9} /> MQTT + WebSocket
        </Chip>
      </header>

      {/* 设备列表 */}
      <div className="mt-2 grid grid-cols-2 gap-1.5">
        {platform.devices.map((d) => {
          const Icon = KIND_ICON[d.kind];
          const ok = d.online;
          return (
            <div key={d.id} className={`panel-flat corner px-2 py-1 ${ok ? 'border-success/25' : 'border-danger/30'}`}>
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-1.5 text-[10.5px] text-ink">
                  <Icon size={11} className={ok ? 'text-cyanx' : 'text-danger'} />
                  {d.name}
                </span>
                <span className={`flex items-center gap-1 text-[9.5px] ${ok ? 'text-success' : 'text-danger'}`}>
                  <Dot color={ok ? '#20C997' : '#FF4D4F'} size={5} />
                  {ok ? '在线' : '离线'}
                </span>
              </div>
              <div className="mt-1 flex items-center justify-between text-[9px] text-ink-3">
                <span className="truncate">{KIND_LABEL[d.kind]}</span>
                <span className="num">{d.latency}ms</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* 云端链路 + 算力 */}
      <div className="mt-2 flex items-center gap-1.5 text-[10.5px] text-ink-2">
        <Cloud size={11} className="text-cyanx" /> 云端通信链路
      </div>
      <div className="mt-1 grid grid-cols-3 gap-1.5">
        {CLOUD_LINKS.map((l) => {
          const v = linkValue[l.key];
          const ok = v === '正常';
          return (
            <div key={l.key} className="panel-flat corner px-1.5 py-1">
              <div className="flex items-center gap-1 text-[9px] text-ink-3">
                {l.key === 'sync' ? (
                  <Cloud size={9} className="text-cyanx/80" />
                ) : l.key === 'comm' ? (
                  <Signal size={9} className="text-cyanx/80" />
                ) : (
                  <Globe size={9} className="text-cyanx/80" />
                )}
                {l.label}
              </div>
              <div className={`num mt-[2px] text-[11px] ${ok ? 'text-success' : 'text-warn'}`}>{v}</div>
              <div className="num text-[8.5px] text-ink-3">{l.rate}</div>
            </div>
          );
        })}
      </div>

      {/* 云端算力 */}
      <div className="mt-2 flex items-center justify-between">
        <span className="flex items-center gap-1.5 text-[10.5px] text-ink-2">
          <Cpu size={11} className="text-cyanx" /> 云端算力调度
        </span>
        <span className="num text-[9.5px] text-ink-3">GPU 利用率 76%</span>
      </div>
      <div className="mt-1 flex gap-2">
        {[
          { n: '点云配准', v: 82, c: '#00C2FF' },
          { n: 'AI 推理', v: 76, c: '#1677FF' },
          { n: '三维重建', v: 64, c: '#20C997' },
        ].map((r) => (
          <div key={r.n} className="flex-1">
            <div className="mb-[3px] flex items-center justify-between text-[9px]">
              <span className="text-ink-3">{r.n}</span>
              <span className="num text-ink-2">{r.v}%</span>
            </div>
            <Progress value={r.v} color={r.c} height={3} />
          </div>
        ))}
      </div>
    </section>
  );
}
