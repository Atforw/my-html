import { useEffect, useState } from 'react';
import { Activity, Cpu, Database, Satellite, Settings, Zap } from 'lucide-react';
import { APP_META, NAV_ITEMS } from '../data/mockData';
import { formatClock } from '../utils/simulation';
import { usePlatform } from '../store/PlatformContext';
import { Dot } from './ui/bits';

const NAV_ICON: Record<string, typeof Activity> = {
  city: Database,
  analysis: Activity,
  task: Cpu,
  result: Zap,
  setting: Settings,
};

export default function Header() {
  const { platform, activeNav, dispatch, pushToast } = usePlatform();
  const [now, setNow] = useState(() => new Date());

  useEffect(() => {
    const t = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(t);
  }, []);

  const gnssOk = platform.gnss === 'FIX';

  const onNav = (key: string) => {
    dispatch({ type: 'SET_NAV', nav: key });
    if (key === 'result') {
      dispatch({ type: 'SET_RESULT', open: true });
      return;
    }
    if (key === 'setting') {
      pushToast('系统设置面板（Mock）：数据源 / 精度阈值 / 调度策略可配置', 'info');
      return;
    }
    if (key === 'analysis') pushToast('已切换到「数据分析」视图：左侧多源数据分析面板', 'info');
    if (key === 'task') pushToast('已切换到「AI任务」视图：右侧任务调度中心', 'info');
  };

  return (
    <header className="relative z-20 flex h-[64px] shrink-0 items-center justify-between border-b border-line bg-[#081422] px-4">
      {/* 顶部装饰线 */}
      <div className="pointer-events-none absolute inset-x-0 top-0 h-[2px] bg-gradient-to-r from-transparent via-cyanx/70 to-transparent" />
      <div className="pointer-events-none absolute inset-0 grid-bg opacity-40" />

      {/* ── 左：品牌 ─────────────────────────────── */}
      <div className="relative flex items-center gap-3">
        <div className="relative flex h-[38px] w-[38px] items-center justify-center">
          <svg viewBox="0 0 48 48" className="absolute inset-0 h-full w-full">
            <defs>
              <linearGradient id="lg" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="#00C2FF" />
                <stop offset="100%" stopColor="#1677FF" />
              </linearGradient>
            </defs>
            <path
              d="M24 2.6 43 13.3v21.4L24 45.4 5 34.7V13.3z"
              fill="rgba(0,194,255,0.08)"
              stroke="url(#lg)"
              strokeWidth="1.4"
            />
            <circle cx="24" cy="24" r="8.6" fill="none" stroke="url(#lg)" strokeWidth="1.1" opacity="0.75" />
            <circle cx="24" cy="24" r="3.1" fill="#00C2FF" />
            <path d="M24 8.5v7M24 32.5v7M8.5 24h7M32.5 24h7" stroke="#00C2FF" strokeWidth="1" opacity="0.6" />
          </svg>
        </div>
        <div className="leading-none">
          <div className="flex items-end gap-2">
            <h1 className="text-[21px] font-bold tracking-[3px] text-ink">数智睿测</h1>
            <span className="num mb-[2px] text-[10px] text-cyanx/70">{APP_META.version}</span>
          </div>
          <p className="mt-[5px] text-[10.5px] tracking-[1.4px] text-ink-2">{APP_META.subtitle}</p>
        </div>
      </div>

      {/* ── 中：功能导航 ─────────────────────────── */}
      <nav className="relative flex items-center gap-1.5">
        {NAV_ITEMS.map((item) => {
          const Icon = NAV_ICON[item.key] ?? Activity;
          const active = activeNav === item.key;
          return (
            <button
              key={item.key}
              onClick={() => onNav(item.key)}
              className={`btn ${active ? 'btn-active' : ''} px-3 py-1.5`}
            >
              <Icon size={12} />
              <span className="tracking-wide">{item.label}</span>
              {active && (
                <span className="absolute -bottom-[6px] left-1/2 h-[2px] w-6 -translate-x-1/2 rounded-full bg-cyanx shadow-[0_0_8px_rgba(0,194,255,0.9)]" />
              )}
            </button>
          );
        })}
      </nav>

      {/* ── 右：系统状态 + 时间 ──────────────────── */}
      <div className="relative flex items-center gap-3">
        <div className="flex items-center gap-3 rounded-sm border border-line bg-[#0A1729]/70 px-3 py-[6px]">
          <span className="flex items-center gap-1.5">
            <Dot color="#20C997" />
            <span className="text-[10.5px] text-ink-2">系统在线</span>
          </span>
          <span className="h-3 w-px bg-line" />
          <span className="flex items-center gap-1.5">
            <Satellite size={12} className={gnssOk ? 'text-cyanx' : 'text-warn'} />
            <span className="text-[10.5px] text-ink-3">GNSS：</span>
            <span className={`num text-[11px] ${gnssOk ? 'text-success' : 'text-warn'}`}>{platform.gnss}</span>
          </span>
          <span className="h-3 w-px bg-line" />
          <span className="flex items-center gap-1.5">
            <Cpu size={12} className="text-cyanx" />
            <span className="text-[10.5px] text-ink-3">AI引擎：</span>
            <span className="text-[11px] text-success">运行中</span>
          </span>
          <span className="h-3 w-px bg-line" />
          <span className="flex items-center gap-1.5">
            <Database size={12} className="text-cyanx" />
            <span className="text-[10.5px] text-ink-3">数据同步：</span>
            <span className="text-[11px] text-success">{platform.cloudSync}</span>
          </span>
        </div>

        <div className="flex items-center gap-2 rounded-sm border border-line bg-[#0A1729]/70 px-3 py-[4px]">
          <Activity size={13} className="text-cyanx animate-blink" />
          <div className="text-right leading-none">
            <div className="num text-[15px] tracking-wider text-ink">{formatClock(now)}</div>
            <div className="mt-[3px] text-[9px] tracking-[1.2px] text-ink-3">CST · 北斗 / GPS / GLONASS</div>
          </div>
        </div>
      </div>
    </header>
  );
}
