import { useMemo } from 'react';
import type { EChartsOption } from 'echarts';
import { useECharts } from '../../hooks/useECharts';

/* ── 点云实时折线（区域渐变 + 呼吸动效） ───────────────── */
export function Sparkline({
  data,
  color = '#00C2FF',
  height = 46,
}: {
  data: number[];
  color?: string;
  height?: number;
}) {
  const option = useMemo<EChartsOption>(() => {
    const min = Math.min(...data);
    const max = Math.max(...data);
    return {
      animation: true,
      animationDuration: 600,
      animationEasing: 'cubicOut',
      grid: { left: 2, right: 2, top: 6, bottom: 2 },
      xAxis: { type: 'category', show: false, boundaryGap: false },
      yAxis: { type: 'value', show: false, min: min - (max - min) * 0.4, max: max + (max - min) * 0.3 },
      tooltip: {
        trigger: 'axis',
        backgroundColor: 'rgba(8,20,34,0.94)',
        borderColor: 'rgba(0,194,255,0.35)',
        textStyle: { color: '#E6F1FF', fontSize: 10 },
        formatter: (params: unknown) => {
          const arr = params as { value: number; dataIndex: number }[];
          return `<span style="font-size:10px">T-${data.length - arr[0].dataIndex}s</span><br/><b style="color:${color}">${arr[0].value.toFixed(3)} M</b>`;
        },
      },
      series: [
        {
          type: 'line',
          data,
          smooth: 0.35,
          symbol: 'none',
          lineStyle: { width: 1.4, color },
          areaStyle: {
            color: {
              type: 'linear',
              x: 0,
              y: 0,
              x2: 0,
              y2: 1,
              colorStops: [
                { offset: 0, color: `${color}55` },
                { offset: 1, color: `${color}00` },
              ],
            },
          },
          markPoint: {
            symbol: 'circle',
            symbolSize: 5,
            data: [{ type: 'max', name: '峰值' }],
            itemStyle: { color, shadowBlur: 8, shadowColor: color },
            label: { show: false },
          },
        },
      ],
    };
  }, [data, color]);

  const { hostRef, style } = useECharts(option, height);
  return <div ref={hostRef} style={style} className="w-full" />;
}

/* ── 高程分布直方图 ───────────────────────────────────── */
export function MiniBars({
  bins,
  values,
  height = 52,
  color = '#1677FF',
}: {
  bins: string[];
  values: number[];
  height?: number;
  color?: string;
}) {
  const option = useMemo<EChartsOption>(
    () => ({
      animationDuration: 600,
      grid: { left: 18, right: 4, top: 6, bottom: 12 },
      xAxis: {
        type: 'category',
        data: bins,
        axisLine: { lineStyle: { color: 'rgba(0,194,255,0.2)' } },
        axisTick: { show: false },
        axisLabel: { color: '#6B839C', fontSize: 8, interval: 1 },
      },
      yAxis: {
        type: 'value',
        splitLine: { lineStyle: { color: 'rgba(0,194,255,0.08)' } },
        axisLabel: { color: '#6B839C', fontSize: 8 },
      },
      tooltip: {
        trigger: 'axis',
        backgroundColor: 'rgba(8,20,34,0.94)',
        borderColor: 'rgba(0,194,255,0.35)',
        textStyle: { color: '#E6F1FF', fontSize: 10 },
        formatter: (p: unknown) => {
          const arr = p as { name: string; value: number }[];
          return `高程 ${arr[0].name}m<br/>采样点 <b style="color:${color}">${arr[0].value}</b>`;
        },
      },
      series: [
        {
          type: 'bar',
          data: values,
          barWidth: '58%',
          itemStyle: {
            borderRadius: [1, 1, 0, 0],
            color: {
              type: 'linear',
              x: 0,
              y: 0,
              x2: 0,
              y2: 1,
              colorStops: [
                { offset: 0, color: '#00C2FF' },
                { offset: 1, color: `${color}33` },
              ],
            },
          },
        },
      ],
    }),
    [bins, values, color],
  );

  const { hostRef, style } = useECharts(option, height);
  return <div ref={hostRef} style={style} className="w-full" />;
}

/* ── 精度雷达（GNSS 质量评估） ────────────────────────── */
export function AccuracyRadar({ values, height = 118 }: { values: number[]; height?: number }) {
  const option = useMemo<EChartsOption>(
    () => ({
      animationDuration: 700,
      radar: {
        center: ['50%', '54%'],
        radius: '62%',
        indicator: [
          { name: '平面精度', max: 100 },
          { name: '高程精度', max: 100 },
          { name: '卫星数', max: 100 },
          { name: '固定率', max: 100 },
          { name: '数据完整度', max: 100 },
        ],
        splitNumber: 3,
        axisName: { color: '#9FB6CE', fontSize: 9 },
        splitLine: { lineStyle: { color: 'rgba(0,194,255,0.16)' } },
        splitArea: { areaStyle: { color: ['rgba(0,194,255,0.03)', 'rgba(0,194,255,0.06)'] } },
        axisLine: { lineStyle: { color: 'rgba(0,194,255,0.18)' } },
      },
      series: [
        {
          type: 'radar',
          data: [{ value: values }],
          symbolSize: 3,
          lineStyle: { width: 1.4, color: '#00C2FF' },
          itemStyle: { color: '#00C2FF' },
          areaStyle: { color: 'rgba(0,194,255,0.22)' },
        },
      ],
    }),
    [values],
  );

  const { hostRef, style } = useECharts(option, height);
  return <div ref={hostRef} style={style} className="w-full" />;
}
