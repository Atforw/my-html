import type { ReactNode } from 'react';

interface PanelProps {
  title?: ReactNode;
  subtitle?: ReactNode;
  extra?: ReactNode;
  children?: ReactNode;
  className?: string;
  bodyClassName?: string;
  dense?: boolean;
}

/** 统一风格面板：左侧强调条标题 + 细边框 + 科技角标 */
export function Panel({
  title,
  subtitle,
  extra,
  children,
  className = '',
  bodyClassName = '',
  dense = false,
}: PanelProps) {
  return (
    <section className={`panel corner flex min-h-0 flex-col ${className}`}>
      {title && (
        <header className={`flex items-center justify-between ${dense ? 'px-2.5 pt-2' : 'px-3 pt-2.5'}`}>
          <div className="flex min-w-0 items-center gap-2">
            <span className="h-[12px] w-[3px] shrink-0 rounded-sm bg-cyanx shadow-[0_0_6px_rgba(0,194,255,0.8)]" />
            <h2 className="truncate text-[12.5px] font-semibold tracking-wide text-ink">{title}</h2>
            {subtitle && <span className="truncate text-[10px] text-ink-3">{subtitle}</span>}
          </div>
          {extra}
        </header>
      )}
      <div className={`min-h-0 flex-1 ${dense ? 'p-2' : 'px-3 pb-2.5 pt-2'} ${bodyClassName}`}>{children}</div>
    </section>
  );
}
