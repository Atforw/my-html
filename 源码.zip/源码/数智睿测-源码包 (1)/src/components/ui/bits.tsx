import type { ReactNode } from 'react';
import type { LucideIcon } from 'lucide-react';

/* ── 状态点 ──────────────────────────────────────────── */
export function Dot({
  color = '#20C997',
  pulse = true,
  size = 6,
}: {
  color?: string;
  pulse?: boolean;
  size?: number;
}) {
  return (
    <span className="relative inline-flex shrink-0 items-center justify-center" style={{ width: size, height: size }}>
      <span className="block rounded-full" style={{ width: size, height: size, background: color }} />
      {pulse && (
        <span
          className="absolute inset-0 animate-pulse-ring rounded-full"
          style={{ background: color, opacity: 0.5 }}
        />
      )}
    </span>
  );
}

/* ── 标签 ────────────────────────────────────────────── */
export function Chip({
  children,
  tone = 'cyan',
  className = '',
}: {
  children: ReactNode;
  tone?: 'cyan' | 'success' | 'warn' | 'danger' | 'muted' | 'primary';
  className?: string;
}) {
  const tones: Record<string, string> = {
    cyan: 'border-cyanx/35 text-cyanx bg-cyanx/10',
    success: 'border-success/35 text-success bg-success/10',
    warn: 'border-warn/40 text-warn bg-warn/10',
    danger: 'border-danger/40 text-danger bg-danger/10',
    primary: 'border-primary/45 text-[#5AA9FF] bg-primary/10',
    muted: 'border-line text-ink-3 bg-white/[0.02]',
  };
  return <span className={`chip ${tones[tone]} ${className}`}>{children}</span>;
}

/* ── 进度条 ──────────────────────────────────────────── */
export function Progress({
  value,
  color = '#00C2FF',
  height = 4,
  striped = false,
  track = '#0d2136',
}: {
  value: number;
  color?: string;
  height?: number;
  striped?: boolean;
  track?: string;
}) {
  return (
    <div className="progress-track" style={{ height, background: track }}>
      <div
        className="progress-bar"
        style={{
          width: `${Math.max(0, Math.min(100, value))}%`,
          background: striped
            ? `repeating-linear-gradient(115deg, ${color} 0 6px, ${color}99 6px 12px)`
            : `linear-gradient(90deg, ${color}99, ${color})`,
          boxShadow: `0 0 8px -1px ${color}aa`,
        }}
      />
    </div>
  );
}

/* ── 键值对 ──────────────────────────────────────────── */
export function KV({
  label,
  value,
  unit,
  tone = 'default',
  icon: Icon,
}: {
  label: string;
  value: ReactNode;
  unit?: string;
  tone?: 'default' | 'cyan' | 'success' | 'warn' | 'danger';
  icon?: LucideIcon;
}) {
  const colors: Record<string, string> = {
    default: 'text-ink',
    cyan: 'text-cyanx',
    success: 'text-success',
    warn: 'text-warn',
    danger: 'text-danger',
  };
  return (
    <div className="flex items-baseline justify-between gap-2 py-[3px]">
      <span className="flex items-center gap-1 text-[10.5px] text-ink-3">
        {Icon && <Icon size={10} className="opacity-70" />}
        {label}
      </span>
      <span className={`num text-[12px] ${colors[tone]}`}>
        {value}
        {unit && <span className="ml-0.5 text-[9.5px] text-ink-3">{unit}</span>}
      </span>
    </div>
  );
}

/* ── 数据指标（左侧卡片主数值） ───────────────────────── */
export function Metric({
  value,
  unit,
  size = 26,
  color = '#E6F1FF',
}: {
  value: ReactNode;
  unit?: string;
  size?: number;
  color?: string;
}) {
  return (
    <div className="flex items-baseline gap-1">
      <span className="num font-semibold leading-none" style={{ fontSize: size, color }}>
        {value}
      </span>
      {unit && <span className="num text-[11px] text-ink-3">{unit}</span>}
    </div>
  );
}

/* ── 迷你趋势箭头 ────────────────────────────────────── */
export function Delta({ value, unit = '%' }: { value: number; unit?: string }) {
  const up = value >= 0;
  return (
    <span className={`num text-[10px] ${up ? 'text-success' : 'text-danger'}`}>
      {up ? '▲' : '▼'} {Math.abs(value).toFixed(1)}
      {unit}
    </span>
  );
}
