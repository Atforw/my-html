/* ─────────────────────────────────────────────────────────
 *  PlatformContext.tsx
 *  全局状态中枢：实时仿真调度 + 交互动作派发
 *  后续接入真实后端时，只需把 tick 定时器替换为 WebSocket 数据推送
 * ───────────────────────────────────────────────────────── */

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useReducer,
  useRef,
  type Dispatch,
  type ReactNode,
} from 'react';
import type { BuildingDetail, LayerKey, LogLine, PlatformState, ToastMsg, VoiceState } from '../types';
import {
  advanceDemo,
  applyDemoStage,
  createInitialState,
  exitDemo,
  makeLog,
  pushLog,
  simulationRng,
  startDemo,
  tickSimulation,
} from '../utils/simulation';
import { DEMO_STAGES } from '../data/mockData';

type Action =
  | { type: 'TICK' }
  | { type: 'DEMO_ADVANCE'; dt: number }
  | { type: 'START_DEMO' }
  | { type: 'EXIT_DEMO' }
  | { type: 'DEMO_PLAY_TOGGLE' }
  | { type: 'DEMO_JUMP'; stage: number }
  | { type: 'SET_LAYER'; key: LayerKey; value?: boolean }
  | { type: 'SELECT_BUILDING'; detail: BuildingDetail | null }
  | { type: 'SELECT_DEVICE'; device: 'robot' | 'uav' | null }
  | { type: 'ROBOT_T'; t: number; progress: number }
  | { type: 'VOICE'; patch: Partial<VoiceState> }
  | { type: 'SET_FLOW_STEP'; step: number }
  | { type: 'SET_RESULT'; open: boolean }
  | { type: 'PUSH_LOG'; text: string; kind?: LogLine['kind'] }
  | { type: 'SET_NAV'; nav: string }
  | { type: 'TOAST'; toast: ToastMsg }
  | { type: 'DISMISS_TOAST'; id: number }
  | { type: 'COMPLETE_TASK'; id: string };

interface ReducerState {
  platform: PlatformState;
  toasts: ToastMsg[];
  activeNav: string;
}

function reducer(state: ReducerState, action: Action): ReducerState {
  const p = state.platform;
  switch (action.type) {
    case 'TICK':
      return { ...state, platform: tickSimulation(p, simulationRng) };

    case 'DEMO_ADVANCE':
      return { ...state, platform: advanceDemo(p, action.dt) };

    case 'START_DEMO':
      return { ...state, platform: startDemo(p), activeNav: 'city' };

    case 'EXIT_DEMO':
      return { ...state, platform: exitDemo(p) };

    case 'DEMO_PLAY_TOGGLE':
      return { ...state, platform: { ...p, demo: { ...p.demo, playing: !p.demo.playing } } };

    case 'DEMO_JUMP': {
      const stage = Math.max(0, Math.min(DEMO_STAGES.length - 1, action.stage));
      const jumped = applyDemoStage(
        { ...p, demo: { ...p.demo, stage, stageElapsed: 0, finished: false, playing: true } },
        stage,
      );
      return { ...state, platform: jumped };
    }

    case 'SET_LAYER':
      return {
        ...state,
        platform: {
          ...p,
          layers: { ...p.layers, [action.key]: action.value ?? !p.layers[action.key] },
        },
      };

    case 'SELECT_BUILDING':
      return {
        ...state,
        platform: {
          ...p,
          selectedBuilding: action.detail,
          selectedDevice: action.detail ? null : p.selectedDevice,
          systemLogs: action.detail
            ? pushLog(p.systemLogs, makeLog(`选中建筑物 ${action.detail.id}，读取空间属性`, 'info'), 40)
            : p.systemLogs,
        },
      };

    case 'SELECT_DEVICE':
      return {
        ...state,
        platform: { ...p, selectedDevice: action.device, selectedBuilding: action.device ? null : p.selectedBuilding },
      };

    case 'ROBOT_T':
      return {
        ...state,
        platform: {
          ...p,
          robot: { ...p.robot, t: action.t, progress: action.progress },
        },
      };

    case 'VOICE':
      return { ...state, platform: { ...p, voice: { ...p.voice, ...action.patch } } };

    case 'SET_FLOW_STEP':
      return { ...state, platform: { ...p, flowStep: action.step } };

    case 'SET_RESULT':
      return { ...state, platform: { ...p, resultOpen: action.open } };

    case 'PUSH_LOG':
      return {
        ...state,
        platform: {
          ...p,
          systemLogs: pushLog(p.systemLogs, makeLog(action.text, action.kind ?? 'info'), 40),
        },
      };

    case 'COMPLETE_TASK':
      return {
        ...state,
        platform: {
          ...p,
          tasks: p.tasks.map((t) =>
            t.id === action.id ? { ...t, status: 'done', progress: 100, eta: '已完成' } : t,
          ),
        },
      };

    case 'SET_NAV':
      return { ...state, activeNav: action.nav };

    case 'TOAST':
      return { ...state, toasts: [...state.toasts, action.toast].slice(-4) };

    case 'DISMISS_TOAST':
      return { ...state, toasts: state.toasts.filter((t) => t.id !== action.id) };

    default:
      return state;
  }
}

interface Ctx extends ReducerState {
  dispatch: Dispatch<Action>;
  pushToast: (text: string, kind?: ToastMsg['kind']) => void;
  log: (text: string, kind?: LogLine['kind']) => void;
  setNav: (nav: string) => void;
}

const PlatformContext = createContext<Ctx | null>(null);

export function PlatformProvider({ children }: { children: ReactNode }) {
  const initial = useMemo<ReducerState>(
    () => ({ platform: createInitialState(), toasts: [], activeNav: 'city' }),
    [],
  );
  const [state, dispatch] = useReducer(reducer, initial);
  const stateRef = useRef(state);
  stateRef.current = state;

  /* ── 实时仿真心跳（1Hz） ──────────────────────────── */
  useEffect(() => {
    const timer = window.setInterval(() => {
      dispatch({ type: 'TICK' });
      const p = stateRef.current.platform;
      if (p.demo.active && p.demo.playing) {
        dispatch({ type: 'DEMO_ADVANCE', dt: 1 });
      }
    }, 1000);
    return () => window.clearInterval(timer);
  }, []);

  const pushToast = useCallback((text: string, kind: ToastMsg['kind'] = 'success') => {
    const toast: ToastMsg = { id: Date.now() + Math.floor(Math.random() * 1000), text, kind: kind as ToastMsg['kind'] };
    dispatch({ type: 'TOAST', toast });
    window.setTimeout(() => dispatch({ type: 'DISMISS_TOAST', id: toast.id }), 2800);
  }, []);

  const log = useCallback((text: string, kind: LogLine['kind'] = 'info') => {
    dispatch({ type: 'PUSH_LOG', text, kind });
  }, []);

  const setNav = useCallback((nav: string) => {
    dispatch({ type: 'SET_NAV', nav });
  }, []);

  const value = useMemo<Ctx>(
    () => ({ ...state, dispatch, pushToast, log, setNav }),
    [state, pushToast, log, setNav],
  );

  return <PlatformContext.Provider value={value}>{children}</PlatformContext.Provider>;
}

export function usePlatform(): Ctx {
  const ctx = useContext(PlatformContext);
  if (!ctx) throw new Error('usePlatform must be used within PlatformProvider');
  return ctx;
}
