/* ─────────────────────────────────────────────────────────
 *  mockData.ts
 *  全平台 Mock 数据源：硬件、任务、语音、演示脚本、城市三维模型数据
 *  所有 UI 组件禁止硬编码业务数据，统一从此文件读取
 * ───────────────────────────────────────────────────────── */

import type {
  AITask,
  AiTarget,
  BuildingSpec,
  DemoStageDef,
  DeviceEndpoint,
  ElevationSample,
  FlowStep,
  GnssPoint,
  ResultField,
  RoutePoint,
  VoiceState,
} from '../types';

/* ── 伪随机（固定种子，保证每次刷新城市形态一致） ───────── */
export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return function () {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const rnd = mulberry32(20260928);
const rand = (min: number, max: number) => min + rnd() * (max - min);
const pick = <T,>(arr: T[]): T => arr[Math.floor(rnd() * arr.length)];

/* ═════════════════════════════════════════════════════════
 * 1. 应用元信息 & 顶部导航
 * ═════════════════════════════════════════════════════════ */
export const APP_META = {
  name: '数智睿测',
  subtitle: 'AI+测绘机器人智慧服务平台',
  enName: 'SHUZHI RUICÈ · AI SURVEYING PLATFORM',
  version: 'v2.6.3',
  buildTime: '2026-09-28',
};

export const NAV_ITEMS = [
  { key: 'city', label: '城市三维' },
  { key: 'analysis', label: '数据分析' },
  { key: 'task', label: 'AI任务' },
  { key: 'result', label: '测绘成果' },
  { key: 'setting', label: '系统设置' },
] as const;

export const HEADER_STATUS = [
  { key: 'online', label: '系统在线', value: 'RUNNING', tone: 'success' as const },
  { key: 'gnss', label: 'GNSS', value: 'FIX', tone: 'cyan' as const },
  { key: 'ai', label: 'AI引擎', value: '运行中', tone: 'success' as const },
  { key: 'sync', label: '数据同步', value: '正常', tone: 'cyan' as const },
];

/* ═════════════════════════════════════════════════════════
 * 2. 城市三维模型 —— 路网 / 街区 / 建筑 / 广场 / 绿地 / 桥梁
 *    世界坐标 1 单位 = 1 米，测区范围约 800m × 800m
 * ═════════════════════════════════════════════════════════ */
export const ROAD_COORDS = [-300, -180, -60, 60, 180, 300];
export const ROAD_WIDTH = 26;
/** 城市道路总里程（km） */
export const ROAD_LENGTH_KM = 86.4;
/** 测区面积（km²） */
export const SURVEY_AREA_KM2 = 12.86;

export interface RoadSpec {
  cx: number;
  cz: number;
  w: number;
  d: number;
  level: 'main' | 'branch';
  name: string;
}

const MAIN_ROAD_SPAN = 640;

export const ROADS: RoadSpec[] = [
  ...ROAD_COORDS.map((x, i) => ({
    cx: x,
    cz: 0,
    w: ROAD_WIDTH,
    d: MAIN_ROAD_SPAN,
    level: 'main' as const,
    name: `经 ${i + 1} 路`,
  })),
  ...ROAD_COORDS.map((z, i) => ({
    cx: 0,
    cz: z,
    w: MAIN_ROAD_SPAN,
    d: ROAD_WIDTH,
    level: 'main' as const,
    name: `纬 ${i + 1} 街`,
  })),
  // 跨江桥引道 + 南部滨江片区路网
  { cx: 0, cz: 445, w: 30, d: 330, level: 'main', name: '跨江大桥引道' },
  { cx: 0, cz: 500, w: 520, d: 22, level: 'branch', name: '滨江大道' },
  { cx: -160, cz: 545, w: 20, d: 120, level: 'branch', name: '南片区支路' },
  { cx: 160, cz: 545, w: 20, d: 120, level: 'branch', name: '南片区支路' },
];

/** 城市广场（圆形，位于城市中心街区） */
export const PLAZA = { x: 0, z: 0, radius: 40, name: '中心广场' };
/** 绿地公园 */
export const PARKS = [
  { x: -240, z: 120, w: 92, d: 92, name: '城市绿轴公园' },
  { x: 240, z: -120, w: 92, d: 92, name: '东湖绿地' },
  { x: 120, z: 240, w: 92, d: 92, name: '滨河街头绿地' },
];
/** 跨江大桥 */
export const BRIDGE = {
  x: 0,
  deckZ: 380,
  from: 330,
  to: 430,
  width: 28,
  deckY: 10,
  pylonH: 62,
  name: '城市跨江大桥',
};
/** 水系 */
export const RIVER = { cz: 380, w: 1100, d: 56, name: '城市主干水系' };

/* ── 建筑生成 ────────────────────────────────────────── */
const SPECIAL_BLOCKS: Record<string, 'plaza' | 'park'> = {
  '2-2': 'plaza',
  '0-3': 'park',
  '4-1': 'park',
  '3-4': 'park',
};

function buildBlock(
  bx: number,
  bz: number,
  kind: 'normal' | 'landmark' | 'district',
  out: BuildingSpec[],
  seq: { n: number },
) {
  const blockSize = 120 - ROAD_WIDTH;
  // 地块切分方式：2×2 / 3×3
  const cells = kind === 'landmark' || kind === 'district' ? 2 : rnd() < 0.68 ? 3 : 2;
  const cell = blockSize / cells;
  const gap = kind === 'district' ? 8 : 10;

  for (let i = 0; i < cells; i++) {
    for (let j = 0; j < cells; j++) {
      if (rnd() < 0.1) continue; // 少量空地（街头广场 / 停车场）
      const cx = bx - blockSize / 2 + cell * (i + 0.5) + rand(-2, 2);
      const cz = bz - blockSize / 2 + cell * (j + 0.5) + rand(-2, 2);
      const w = Math.max(14, cell - gap - rand(0, 6));
      const d = Math.max(14, cell - gap - rand(0, 6));
      const distToCenter = Math.hypot(cx, cz);

      let h: number;
      let category: BuildingSpec['category'];
      if (kind === 'landmark') {
        h = rand(118, 168);
        category = '高层建筑';
      } else if (kind === 'district') {
        h = rand(46, 82);
        category = '商业综合体';
      } else if (distToCenter < 140) {
        h = rand(52, 118);
        category = '高层建筑';
      } else if (rnd() < 0.3) {
        h = rand(12, 26);
        category = '低层建筑';
      } else {
        h = rand(26, 62);
        category = rnd() < 0.3 ? '公共建筑' : '高层建筑';
      }

      seq.n += 1;
      const floors = Math.max(3, Math.round(h / 3.2));
      out.push({
        id: `BLD-${String(seq.n).padStart(4, '0')}`,
        x: cx,
        z: cz,
        w,
        d,
        h,
        category,
        floors,
        area: Math.round(w * d * floors * 0.72),
        pointCount: Math.round(h * w * d * rand(1.2, 2.6)) + 1200,
        landmark: kind === 'landmark',
      });
    }
  }
}

export const BUILDINGS: BuildingSpec[] = (() => {
  const out: BuildingSpec[] = [];
  const seq = { n: 0 };
  const GRID = ROAD_COORDS.length - 1; // 5×5 城市街区
  for (let i = 0; i < GRID; i++) {
    for (let j = 0; j < GRID; j++) {
      const key = `${i}-${j}`;
      const special = SPECIAL_BLOCKS[key];
      if (special) continue;
      const bx = -240 + 120 * i;
      const bz = -240 + 120 * j;
      const central = Math.abs(bx) <= 130 && Math.abs(bz) <= 130;
      const kind: 'normal' | 'landmark' | 'district' =
        key === '2-1' ? 'landmark' : central ? 'district' : 'normal';
      buildBlock(bx, bz, kind, out, seq);
    }
  }
  // 南部滨江片区
  [-160, 0, 160].forEach((x) => buildBlock(x, 560, 'district', out, seq));
  return out;
})();

/** 全测区建筑物统计（含未逐栋渲染的模型） */
export const BUILDING_TOTAL = 428;

/* ═════════════════════════════════════════════════════════
 * 3. GNSS/RTK 控制点
 * ═════════════════════════════════════════════════════════ */
export const GNSS_POINTS: GnssPoint[] = [
  { id: 'GNSS-001', x: -300, z: -300, h: 4, status: 'FIX', satellite: 32, pdop: 0.8 },
  { id: 'GNSS-002', x: 60, z: -300, h: 4, status: 'FIX', satellite: 30, pdop: 0.9 },
  { id: 'GNSS-003', x: 300, z: -180, h: 4, status: 'FIX', satellite: 31, pdop: 0.8 },
  { id: 'GNSS-004', x: -180, z: 60, h: 4, status: 'FIX', satellite: 29, pdop: 1.0 },
  { id: 'GNSS-005', x: 300, z: 300, h: 4, status: 'FLOAT', satellite: 26, pdop: 1.6 },
  { id: 'GNSS-006', x: -300, z: 180, h: 4, status: 'FIX', satellite: 33, pdop: 0.7 },
  { id: 'GNSS-007', x: 0, z: 480, h: 4, status: 'FIX', satellite: 30, pdop: 0.9 },
];

/* ═════════════════════════════════════════════════════════
 * 4. AI 视觉识别目标
 * ═════════════════════════════════════════════════════════ */
export const AI_TARGETS: AiTarget[] = (() => {
  const out: AiTarget[] = [];
  const landmarkBuildings = BUILDINGS.filter((b) => b.h > 60).slice(0, 10);
  landmarkBuildings.forEach((b, i) => {
    out.push({
      id: `AI-B${String(i + 1).padStart(3, '0')}`,
      label: `建筑识别 · ${b.category}`,
      kind: 'building',
      x: b.x,
      z: b.z,
      y: b.h + 6,
      size: [b.w + 6, b.h + 12, b.d + 6],
      confidence: 0.94 + rnd() * 0.05,
    });
  });
  ROADS.slice(0, 4).forEach((r, i) => {
    out.push({
      id: `AI-R${String(i + 1).padStart(3, '0')}`,
      label: '道路要素提取 · 路面/标线',
      kind: 'road',
      x: r.cx + rand(-40, 40),
      z: r.cz + rand(-40, 40),
      y: 3,
      size: [34, 6, 34],
      confidence: 0.9 + rnd() * 0.07,
    });
  });
  [
    { x: -60, z: -60 },
    { x: 180, z: 120 },
    { x: -180, z: 60 },
  ].forEach((p, i) => {
    out.push({
      id: `AI-V${String(i + 1).padStart(3, '0')}`,
      label: '移动目标识别 · 车辆',
      kind: 'vehicle',
      x: p.x,
      z: p.z,
      y: 4,
      size: [10, 6, 6],
      confidence: 0.88 + rnd() * 0.09,
    });
  });
  [
    { x: -240, z: 120 },
    { x: 240, z: -120 },
  ].forEach((p, i) => {
    out.push({
      id: `AI-G${String(i + 1).padStart(3, '0')}`,
      label: '绿地提取 · 植被覆盖',
      kind: 'vegetation',
      x: p.x,
      z: p.z,
      y: 4,
      size: [40, 6, 40],
      confidence: 0.92 + rnd() * 0.06,
    });
  });
  out.push({
    id: 'AI-X001',
    label: '异常空间区域 · 高程突变',
    kind: 'anomaly',
    x: 180,
    z: -180,
    y: 12,
    size: [46, 24, 46],
    confidence: 0.87,
  });
  return out;
})();

/* ═════════════════════════════════════════════════════════
 * 5. 高程采样点（DEM）
 * ═════════════════════════════════════════════════════════ */
export const ELEVATION_SAMPLES: ElevationSample[] = (() => {
  const out: ElevationSample[] = [];
  for (let i = -3; i <= 3; i++) {
    for (let j = -3; j <= 3; j++) {
      const x = i * 80;
      const z = j * 80;
      const h = 118 + Math.sin(x / 160) * 5 + Math.cos(z / 140) * 4 + rand(0, 3) + (x + z) * 0.006;
      out.push({ x, z, h: Number(h.toFixed(3)) });
    }
  }
  return out;
})();

export const ELEVATION_STATS = {
  avg: 126.382,
  min: 118.24,
  max: 133.91,
  anomalies: 3,
  missingAreas: 1,
};

/** 高程分布直方图 */
export const ELEVATION_HISTOGRAM = {
  bins: ['118', '120', '122', '124', '126', '128', '130', '132'],
  values: [4, 9, 16, 22, 19, 13, 7, 3],
};

/* ═════════════════════════════════════════════════════════
 * 6. 作业轨迹
 * ═════════════════════════════════════════════════════════ */
/** 测绘机器人-01：沿城市道路的巡检测绘轨迹（闭合环线） */
export const ROBOT_ROUTE: RoutePoint[] = [
  { x: -300, y: 1.2, z: -300 },
  { x: -60, y: 1.2, z: -300 },
  { x: -60, y: 1.2, z: -60 },
  { x: 60, y: 1.2, z: -60 },
  { x: 60, y: 1.2, z: 60 },
  { x: 180, y: 1.2, z: 60 },
  { x: 180, y: 1.2, z: 180 },
  { x: -60, y: 1.2, z: 180 },
  { x: -60, y: 1.2, z: -180 },
  { x: -180, y: 1.2, z: -180 },
  { x: -180, y: 1.2, z: -300 },
];

/** UAV-02：城市上空三维建模航线（含跨江段） */
export const UAV_ROUTE: RoutePoint[] = [
  { x: -320, y: 150, z: -320 },
  { x: 60, y: 168, z: -300 },
  { x: 300, y: 156, z: -120 },
  { x: 120, y: 176, z: 120 },
  { x: -60, y: 158, z: 300 },
  { x: -300, y: 172, z: 120 },
  { x: -180, y: 162, z: -60 },
  { x: 0, y: 182, z: 380 },
  { x: 160, y: 170, z: 540 },
  { x: -180, y: 164, z: 520 },
];

/* ═════════════════════════════════════════════════════════
 * 7. AI 任务调度数据
 * ═════════════════════════════════════════════════════════ */
export const TASK_SEED: AITask[] = [
  {
    id: 'TSK-20260928-001',
    name: '城市道路三维测绘',
    status: 'running',
    device: '测绘机器人-01',
    deviceKind: 'robot',
    progress: 68,
    metric: '点云 4.82M',
    metricLabel: '数据',
    priority: '高',
    startedAt: '16:42:10',
    eta: '17:36',
    scene: '城市道路',
  },
  {
    id: 'TSK-20260928-002',
    name: '高层建筑三维建模',
    status: 'pending',
    device: '无人机-02',
    deviceKind: 'uav',
    progress: 0,
    metric: '待起飞',
    metricLabel: '状态',
    priority: '中',
    startedAt: '—',
    eta: '18:05',
    scene: '建筑立面',
  },
  {
    id: 'TSK-20260928-003',
    name: '城市道路AI识别',
    status: 'done',
    device: 'AI识别引擎',
    deviceKind: 'cloud',
    progress: 100,
    aiAccuracy: 96.8,
    metric: '96.8%',
    metricLabel: 'AI识别',
    priority: '中',
    startedAt: '15:10:22',
    eta: '已完成',
    scene: '道路要素',
  },
  {
    id: 'TSK-20260928-004',
    name: 'GNSS控制点复测',
    status: 'running',
    device: 'RTK Rover-03',
    deviceKind: 'gnss',
    progress: 42,
    metric: '±2.1cm',
    metricLabel: '平面精度',
    priority: '高',
    startedAt: '17:02:48',
    eta: '17:52',
    scene: '控制测量',
  },
  {
    id: 'TSK-20260928-005',
    name: '中心广场点云精细配准',
    status: 'running',
    device: '云端算力节点 A',
    deviceKind: 'cloud',
    progress: 81,
    metric: '配准残差 0.9cm',
    metricLabel: '精度',
    priority: '中',
    startedAt: '16:58:03',
    eta: '17:31',
    scene: '点云配准',
  },
  {
    id: 'TSK-20260928-006',
    name: '东湖绿地植被覆盖提取',
    status: 'done',
    device: 'AI识别引擎',
    deviceKind: 'cloud',
    progress: 100,
    aiAccuracy: 94.2,
    metric: '94.2%',
    metricLabel: 'AI识别',
    priority: '低',
    startedAt: '14:22:11',
    eta: '已完成',
    scene: '地物分类',
  },
  {
    id: 'TSK-20260928-007',
    name: '南区高程异常区域核查',
    status: 'error',
    device: '无人机-05',
    deviceKind: 'uav',
    progress: 36,
    metric: '高程异常 3 处',
    metricLabel: '异常',
    priority: '高',
    startedAt: '16:20:37',
    eta: '已挂起',
    scene: '异常核查',
  },
];

export const TASK_STATS = { total: 28, running: 3, done: 22, error: 3 };

/* ═════════════════════════════════════════════════════════
 * 8. 三端协同 / 云通信
 * ═════════════════════════════════════════════════════════ */
export const DEVICE_ENDPOINTS: DeviceEndpoint[] = [
  { id: 'web', name: 'Web 平台', kind: 'web', online: true, detail: '指挥调度端 · Chrome 大屏', latency: 12 },
  { id: 'robot', name: '测绘机器人', kind: 'robot', online: true, detail: '测绘机器人-01 · RTK FIX', latency: 28 },
  { id: 'uav', name: '无人机', kind: 'uav', online: true, detail: 'UAV-02 · 测绘作业中', latency: 34 },
  { id: 'gnss', name: 'GNSS 基准站', kind: 'gnss', online: true, detail: 'CORS 基准站 · FIX', latency: 19 },
];

export const CLOUD_LINKS = [
  { key: 'sync', label: '云端数据同步', value: '正常', rate: '2.4 MB/s' },
  { key: 'comm', label: '任务通信', value: '正常', rate: 'MQTT · 18 msg/s' },
  { key: 'realtime', label: '实时数据', value: '正常', rate: 'WebSocket · 1 Hz' },
];

/* ═════════════════════════════════════════════════════════
 * 9. 智能处理流程（采集 → 感知 → 分析 → 建模 → 调度 → 成果）
 * ═════════════════════════════════════════════════════════ */
export const FLOW_STEPS: FlowStep[] = [
  { id: 'f1', name: '多源数据输入', short: 'INPUT', desc: '无人机 / 机器人 / RTK / 影像' },
  { id: 'f2', name: '点云预处理', short: 'DENOISE', desc: '去噪 · 滤波 · 抽稀' },
  { id: 'f3', name: 'AI目标识别', short: 'AI-DET', desc: '建筑 / 道路 / 植被语义分割' },
  { id: 'f4', name: '点云精细配准', short: 'REGISTER', desc: 'ICP 配准 · 残差 0.9cm' },
  { id: 'f5', name: '三维建模', short: '3D-MODEL', desc: '白模 + 纹理 + 语义属性' },
  { id: 'f6', name: '空间分析', short: 'ANALYSIS', desc: '高程 / 土方 / 通视 / 日照' },
  { id: 'f7', name: '测绘成果输出', short: 'OUTPUT', desc: 'DLG / DEM / DOM / 模型 / 报告' },
];

/* ═════════════════════════════════════════════════════════
 * 10. AI 语音指令
 * ═════════════════════════════════════════════════════════ */
export const VOICE_FLOW = ['语音识别', '指令解析', '任务验证', '设备匹配', '任务下发', '执行反馈'];

export const VOICE_SAMPLES = [
  '开始城市道路三维测绘',
  '对高层建筑进行三维建模',
  '启动GNSS控制点复测',
  '生成跨江大桥点云配准任务',
];

export const VOICE_REPLIES = [
  '已识别指令。',
  '正在生成城市道路三维测绘任务。',
  '已分配测绘机器人-01。',
  '任务开始执行。',
];

export const INITIAL_VOICE: VoiceState = {
  listening: true,
  recognizing: false,
  stage: -1,
  command: VOICE_SAMPLES[0],
  replies: VOICE_REPLIES,
  visibleReplies: 0,
};

/* ═════════════════════════════════════════════════════════
 * 11. 应急测绘能力
 * ═════════════════════════════════════════════════════════ */
export const EMERGENCY_FLOW = [
  'AI识别异常',
  '自动标记异常区域',
  '生成应急测绘任务',
  '调度无人机/测绘机器人',
  '快速采集数据',
  '更新三维模型',
  '生成应急测绘成果',
];

export const EMERGENCY_LOGS = [
  '检测到空间异常区域',
  '正在生成应急测绘任务',
  '已调度测绘机器人-02',
  '无人机-05 已切换至应急航线',
  '应急测绘成果已生成',
];

/* ═════════════════════════════════════════════════════════
 * 12. 测绘成果标准化交付
 * ═════════════════════════════════════════════════════════ */
export const RESULT_FIELDS: ResultField[] = [
  { label: '项目名称', value: '城市三维数字孪生基础测绘项目' },
  { label: '任务名称', value: '城市道路与高层建筑三维测绘' },
  { label: '作业时间', value: '2026-09-28 09:12 ~ 17:26' },
  { label: '测区面积', value: SURVEY_AREA_KM2.toFixed(2), unit: 'km²' },
  { label: '点云数量', value: '12.68', unit: 'M pts', highlight: true },
  { label: 'GNSS控制点', value: '46', unit: '个' },
  { label: 'AI识别目标', value: '128', unit: '个', highlight: true },
  { label: '三维模型', value: '428 栋 / 2.68 M 面', highlight: true },
  { label: '高程数据', value: '1:500 DEM 全覆盖' },
  { label: '异常区域', value: '3', unit: '处', highlight: true },
];

export const RESULT_ACTIONS = [
  { key: 'view', label: '查看成果' },
  { key: 'report', label: '导出报告' },
  { key: 'coord', label: '导出坐标' },
  { key: 'model', label: '导出模型' },
];

export const RESULT_FILES = [
  { name: 'DLG_城市道路_20260928.dwg', size: '48.2 MB', type: '矢量成果' },
  { name: 'DEM_1_500_测区.tif', size: '216.7 MB', type: '高程成果' },
  { name: 'DOM_正射影像.tif', size: '1.24 GB', type: '影像成果' },
  { name: 'CityTwin_3DModel.osgb', size: '862.4 MB', type: '三维模型' },
  { name: 'PointCloud_merged.las', size: '2.08 GB', type: '点云成果' },
  { name: '测绘成果报告_20260928.pdf', size: '12.6 MB', type: '报告' },
];

/* ═════════════════════════════════════════════════════════
 * 13. 左侧点云趋势 / AI 分析脚本
 * ═════════════════════════════════════════════════════════ */
export const POINT_CLOUD_TREND = [
  11.42, 11.58, 11.51, 11.72, 11.86, 11.79, 11.98, 12.06, 11.99, 12.14, 12.26, 12.19,
  12.31, 12.28, 12.36, 12.42, 12.38, 12.47, 12.52, 12.49, 12.57, 12.61, 12.64, 12.68,
];

export const AI_ANALYSIS_SCRIPT = [
  '正在分析点云……',
  '检测到建筑物：428',
  '检测到道路：86',
  '检测到异常高程区域：3',
  '检测到测绘数据缺失区域：1',
  'AI分析完成。',
];

export const AI_ANALYSIS_POOL = [
  '语义分割模型推理完成，建筑轮廓闭合度 98.6%',
  '点云配准残差 0.9cm，满足 1:500 精度要求',
  '道路中心线提取完成，共 86.4km',
  '高程异常区域已标记，等待无人机核查',
  '三维模型与实测控制点比对：ΔH ≤ 2.4cm',
  '数据缺失区域已生成补测任务建议',
];

/* ═════════════════════════════════════════════════════════
 * 14. 演示模式脚本（11 个阶段，合计约 180 秒 ≈ 3 分钟）
 * ═════════════════════════════════════════════════════════ */
export const DEMO_STAGES: DemoStageDef[] = [
  {
    key: 'd1',
    index: 0,
    title: '城市三维模型加载',
    message: '正在加载城市三维空间数据……',
    detail: '读取城市白模 + 语义图层，构建数字孪生底座',
    duration: 14,
    tags: ['3D Tiles', '城市白模', '数字孪生底座'],
  },
  {
    key: 'd2',
    index: 1,
    title: '多源设备接入',
    message: '多源测绘设备连接成功。',
    detail: 'GNSS 基准站 / 无人机 / 地面机器人三端上线',
    duration: 12,
    tags: ['GNSS FIX', 'UAV-02 在线', '机器人-01 在线'],
  },
  {
    key: 'd3',
    index: 2,
    title: '点云采集',
    message: '正在采集城市空间点云……',
    detail: '机器人沿城市道路扫描 + 无人机倾斜摄影',
    duration: 16,
    tags: ['LiDAR', '12.68M pts', '实时回传'],
  },
  {
    key: 'd4',
    index: 3,
    title: 'AI 空间目标识别',
    message: 'AI空间目标识别中……',
    detail: '建筑 / 道路 / 植被 / 车辆语义分割',
    duration: 16,
    tags: ['AI 视觉', '96.8%', '128 目标'],
  },
  {
    key: 'd5',
    index: 4,
    title: '点云精细配准',
    message: '点云精细配准中……',
    detail: 'ICP 全局配准，残差收敛至 0.9cm',
    duration: 15,
    tags: ['ICP', '残差 0.9cm', '多站融合'],
  },
  {
    key: 'd6',
    index: 5,
    title: '三维模型更新',
    message: '城市三维模型更新完成。',
    detail: '模型面数 2.68M，428 栋建筑完成更新',
    duration: 15,
    tags: ['2.68M 面', '428 栋', 'LOD2'],
  },
  {
    key: 'd7',
    index: 6,
    title: '发现异常空间区域',
    message: 'AI检测到异常空间数据。',
    detail: '东侧街区高程突变，疑似沉降 / 数据缺失',
    duration: 13,
    tags: ['高程异常 3 处', '缺失 1 处', '橙色告警'],
  },
  {
    key: 'd8',
    index: 7,
    title: 'AI 自动创建任务',
    message: '正在生成智能测绘任务。',
    detail: '任务验证 → 设备匹配 → 自动下发',
    duration: 13,
    tags: ['任务编排', '设备匹配', '自动下发'],
  },
  {
    key: 'd9',
    index: 8,
    title: '机器人执行任务',
    message: '测绘机器人-01 开始执行任务。',
    detail: '机器人沿城市道路移动，实时采集点云',
    duration: 22,
    tags: ['路径规划', '沿路测绘', '实时定位'],
  },
  {
    key: 'd10',
    index: 9,
    title: '数据回传',
    message: '测绘数据实时回传云端……',
    detail: '点云数量持续增长，云端增量建模',
    duration: 24,
    tags: ['增量更新', '云端同步', 'MQTT'],
  },
  {
    key: 'd11',
    index: 10,
    title: '测绘成果生成',
    message: '测绘成果生成完成。',
    detail: 'DLG / DEM / DOM / 三维模型 / 报告 一键交付',
    duration: 18,
    tags: ['标准化交付', '成果报告', '一键导出'],
  },
];

export const DEMO_TOTAL_SECONDS = DEMO_STAGES.reduce((s, d) => s + d.duration, 0);

/* ═════════════════════════════════════════════════════════
 * 15. 图层控制 & 中央实时数据条
 * ═════════════════════════════════════════════════════════ */
export const LAYER_DEFS = [
  { key: 'buildings', label: '建筑物' },
  { key: 'roads', label: '道路' },
  { key: 'pointCloud', label: '点云' },
  { key: 'gnss', label: 'GNSS控制点' },
  { key: 'uavTrail', label: '无人机轨迹' },
  { key: 'robotTrail', label: '机器人轨迹' },
  { key: 'aiTargets', label: 'AI识别目标' },
  { key: 'elevation', label: '高程数据' },
] as const;

export const CITY_HEADLINE_STATS = [
  { key: 'building', label: '城市建筑', unit: '栋' },
  { key: 'road', label: '道路', unit: 'km' },
  { key: 'point', label: '点云', unit: 'M' },
  { key: 'gnss', label: 'GNSS', unit: '' },
  { key: 'model', label: '模型更新', unit: '' },
  { key: 'ai', label: 'AI目标', unit: '个' },
];

/* ═════════════════════════════════════════════════════════
 * 16. 底部状态栏
 * ═════════════════════════════════════════════════════════ */
export const BOTTOM_ACTIONS = [
  { key: 'result', label: '测绘成果' },
  { key: 'report', label: '数据报告' },
  { key: 'export', label: '导出' },
  { key: 'demo', label: '开始演示' },
];

export const SYSTEM_LOGS_SEED = [
  '平台启动完成，Mock 数据服务已就绪',
  'GNSS 基准站连接成功：CORS-City-01',
  '城市三维模型底座加载完成（428 栋 / 2.68M 面）',
  'AI 推理引擎启动：building-seg-v3 / roadnet-v2',
  '云端任务调度器在线，等待任务下发',
];

/* ── 便捷取值函数 ─────────────────────────────────────── */
export const pickRandom = <T,>(arr: readonly T[]): T => arr[Math.floor(Math.random() * arr.length)];
export { pick };
