# 数智睿测 —— AI+测绘机器人智慧服务平台

> 融合 **AI + 测绘机器人 + 无人机 + GNSS/RTK + 点云 + 三维建模 + AI视觉识别 + 云端任务调度** 的城市三维数字孪生测绘平台前端系统。
> 中央主视觉为 **城市三维数字孪生（城市建筑 / 道路网络 / 城市广场 / 绿地公园 / 跨江大桥）**，矿山应急仅作为平台可服务的应用场景之一（右侧「应急测绘能力」模块）。

---

## 一、如何启动

### 方式 0：公网稳定链接（比赛提交用）★

平台是纯前端静态站点，产物 `dist/` 可直接上传到任意静态托管，得到**长期有效的公网 HTTPS 链接**：

- 上传包：`数智睿测-静态托管上传包.zip`（解压后拖到托管平台即可，无需构建）
- 详细步骤、平台对比、提交前自检清单、提交材料范文：见 **`比赛提交-公网链接方案.md`**
- 局域网内部查看（评委不适用，仅现场演示用）：`npm run serve` → 终端打印 `http://<本机IP>:8080/`

> 切勿把局域网地址或临时内网穿透链接提交给评委（会失效 / 打不开）。

### 方式 A：单文件离线版（最简单，双击即可打开）

```bash
npm run build:single
```

生成一个**自包含网页文件**：

```
dist-single/数智睿测-AI测绘机器人智慧服务平台.html   （约 1.8 MB）
```

JS / CSS 全部内联在这一个 HTML 里：**不需要 Node、不需要本地服务器、不联网**。
双击它就能用浏览器（Chrome / Edge）打开，也可以拷到 U 盘、发给评委老师，或直接挂到任意静态服务器（IIS / Nginx / GitHub Pages）。

> 已验证：直接以 `file://` 方式打开时 WebGL 三维城市、ECharts 图表、全部交互均正常，控制台 0 报错。

### 方式 B：开发模式（改代码用）

```bash
npm install     # 安装依赖（Node ≥ 18）
npm run dev     # 启动开发服务器 → http://127.0.0.1:5183/
```

其它命令：

| 命令 | 说明 |
| --- | --- |
| `npm run build` | 常规生产构建（先 `tsc -b` 类型检查，再 `vite build`，多文件产物在 `dist/`，适合服务器部署） |
| `npm run build:single` | 构建单文件离线版（产物在 `dist-single/`） |
| `npm run serve` | **把平台变成固定链接**：托管 `dist/` 到 0.0.0.0:8080，终端会打印局域网访问地址（另见 `部署与链接指南.md`） |
| `npm run serve:single` | 同上，托管单文件离线版 |
| `npm run preview` | 本地预览 `dist/` 构建产物 |
| `npm run typecheck` | 仅做 TypeScript 类型检查 |
| `npm run smoke` | 运行 Mock 数据 / 仿真引擎 / 演示时间轴自检脚本（`scripts/smoke.ts`） |

Windows 上还有两个双击即用的脚本：`启动平台链接服务.bat`（一键起站点）、`放行局域网访问(右键管理员运行).bat`（放行 8080 端口）。

**适配说明**：界面按 **1920×1080** 设计稿等比缩放（`transform: scale()`），1920×1080、1600×900、1280×720 均可完整呈现；建议演示时按 `F11` 全屏。
带 `?capture=1` 打开（开发地址如 `http://127.0.0.1:5183/?capture=1`，或单文件加参数）会保留 WebGL 绘图缓冲，便于截图 / 录屏留档。

**三维调试句柄**：浏览器控制台可用 `window.__DSH_CITY__` 读取三维场景状态（`renderer.info.render`、`camera`、`scene`、`buildingMeshes` 等），也便于二次开发：
`__DSH_CITY__.renderer.info.render.calls`（每帧绘制批次）／`__DSH_CITY__.camera.position`。

---

## 二、核心页面与区域

| 区域 | 组件 | 内容 |
| --- | --- | --- |
| 顶部导航 | `Header.tsx` | 品牌「数智睿测」+ 副标题、5 个功能按钮（城市三维 / 数据分析 / AI任务 / 测绘成果 / 系统设置）、系统在线 · GNSS · AI引擎 · 数据同步 状态、实时时钟（1s 刷新） |
| 左侧（22%） | `LeftAnalytics.tsx` | 「可视化分析与深度学习」6 张数据卡（点云数据 / GNSS-RTK / AI视觉识别 / 三维模型 / 高程分析 / 数据融合，含 ECharts 折线图与高程直方图，数字滚动动画）、「AI空间智能分析」实时日志窗、「智能处理流程」7 节点链路（可点击切换、当前步骤动态高亮） |
| 中央（56%） | `CityTwin.tsx` | 「城市三维数字孪生」Three.js 场景 + 场景上方 6 项实时数据条 + 8 项图层控制 + 建筑/设备信息卡 + 图例/比例尺/坐标基准 HUD |
| 右侧（22%） | `TaskCenter.tsx` `VoiceCommand.tsx` `DeviceStatus.tsx` | 「云通信与AI全域任务调度」任务统计 + AI 任务列表 + 应急测绘能力；「AI语音指令」识别链路与 AI 回复；「三端协同」设备在线状态 + 云端链路 + 云端算力 |
| 底部 | `BottomStatus.tsx` | 专业测绘数据状态栏（GNSS / 点云 / 三维模型 / AI识别 / 机器人 / 无人机 / 数据同步）+ 系统日志滚动 + 【测绘成果】【数据报告】【导出】【开始演示】 |
| 浮层 | `MeasurementResult.tsx` `DemoMode.tsx` | 测绘成果标准化交付抽屉（成果字段 / 生产流水线 / 文件清单 / 4 个导出按钮）、3 分钟答辩演示模式 |

### 中央三维城市包含的测绘元素

- **城市建筑**：126 栋逐栋渲染（数据显示 428 栋），高度 12 ~ 168 m，半透明材质 + 线框轮廓 + 屋顶面，含高层建筑 / 低层建筑 / 商业综合体 / 公共建筑四类
- **道路网络**：经/纬各 6 条主路 + 支路，Canvas 生成沥青路面、中心虚线、路缘线、交叉口斑马线
- **城市广场 / 绿地公园 / 跨江大桥 / 城市水系**
- **点云**：建筑立面 + 地面约 9000 个 LiDAR 点（加色混合、呼吸动效）
- **GNSS 控制点**：7 个（GNSS-001 ~ 007），发光球 + 脉冲环 + 标签（FIX / FLOAT、卫星数、PDOP）
- **轨迹**：测绘机器人沿城市道路的闭合巡检测绘轨迹（已行进段高亮）、无人机 UAV-02 虚线航线 + 航点 WP
- **设备**：测绘机器人-01（沿路移动、扫描头旋转、点选弹出设备卡）、无人机 UAV-02（旋翼旋转、警示灯闪烁、点选弹出设备卡）
- **AI 识别框**：建筑 / 道路 / 车辆 / 植被 / 异常区域共 20 个识别框 + 置信度标签
- **高程数据**：49 个 DEM 采样柱（按高程着色）

---

## 三、交互与实时动效

| 能力 | 说明 |
| --- | --- |
| 建筑点击 | 射线拾取 → 高亮建筑 + 弹出「建筑物空间信息」卡（编号 / 高度 / 面积 / 楼层 / 点云数量 / GNSS 状态 / 模型状态 / 精度 / AI 置信度 / CGCS2000 坐标 X-Y-H） |
| 设备点击 | 点击机器人或无人机 → 设备状态卡（在线状态 / 电量 / RTK / 卫星数 / 任务 / 进度） |
| 图层控制 | 8 个图层独立开关（建筑物 / 道路 / 点云 / GNSS控制点 / 无人机轨迹 / 机器人轨迹 / AI识别目标 / 高程数据）+ 全部开启/关闭 |
| 视角控制 | OrbitControls 拖拽旋转 / 滚轮缩放 / 右键平移，全景视角、聚焦城区按钮 |
| 智能处理流程 | 点击节点手动切换当前步骤，演示模式自动推进 |
| AI 语音指令 | 「模拟语音指令」触发 6 步链路（语音识别→指令解析→任务验证→设备匹配→任务下发→执行反馈）+ 4 条 AI 回复 + 语音波形动画 + 任务队列联动 |
| 应急测绘 | 「模拟异常」→ 直接进入应急演示阶段，7 步应急链路进度条 + 提示滚动（检测到空间异常区域 / 正在生成应急测绘任务 / 已调度测绘机器人-02 …） |
| 测绘成果 | 抽屉展示 10 项成果字段 + 生产流水线 + 6 个成果文件；【查看成果】【导出报告】【导出坐标】【导出模型】点击后提示「成果文件已生成」 |
| 实时数据 | 1 Hz 心跳：点云增长、AI 识别数量、模型面数、GNSS 状态、平面/高程精度、机器人/无人机遥测、任务进度、模型更新时间、云端链路质量 |
| 演示模式 | 11 阶段约 178 s：镜头飞行 + 阶段解说打字机 + 阶段刻度可点击跳转 + 暂停/继续/上一阶段/下一阶段 + 实时指标 + 结算卡 |

---

## 四、哪些功能使用 Mock 数据

**当前全部数据均为 Mock，无任何后端依赖。** 数据统一集中在 `src/data/mockData.ts`，仿真逻辑集中在 `src/utils/simulation.ts`：

- 城市模型（建筑、路网、广场、绿地、桥梁、水系、点云、GNSS 控制点、AI 目标、高程采样、机器人/无人机轨迹）
- AI 任务列表（7 条）、任务统计（28 / 3 / 22 / 3）
- GNSS/RTK 精度、点云数量、模型面数、AI 识别率、平均高程、异常区域数
- 语音指令样例与 AI 回复、应急测绘链路、测绘成果交付字段与文件清单
- 演示模式 11 阶段脚本与镜头机位
- 所有导出按钮：仅弹出「成果文件已生成」提示（Mock 逻辑）

---

## 五、如何进入演示模式

三种入口，效果一致：

1. 底部状态栏右下角 **【开始演示】**
2. 右侧「应急测绘能力」中的 **【模拟异常】**（直接跳到第 7 阶段「发现异常空间区域」）
3. 顶部演示浮层出现后，可 **点击任意阶段刻度** 跳转，或用 **上一阶段 / 下一阶段 / 暂停 / 退出**

演示 11 个阶段（合计约 178 s ≈ 3 分钟）：
`城市三维模型加载 → 多源设备接入 → 点云采集 → AI空间目标识别 → 点云精细配准 → 三维模型更新 → 发现异常空间区域 → AI自动创建任务 → 机器人执行任务 → 数据回传 → 测绘成果生成`
结束后弹出结算卡「城市三维测绘任务完成」，展示 点云 / GNSS / 三维模型 / AI识别 / 测绘报告 五项成果。

---

## 六、如何替换为真实后端 API

所有外部数据都经过 `simulation.ts` 与 `PlatformContext.tsx` 两层，替换成本很低：

1. **替换实时数据源**：`src/store/PlatformContext.tsx` 中的 1 Hz `setInterval` → `dispatch({ type: 'TICK' })` 即实时数据入口。
   改为真实推送只需把它换成 WebSocket / MQTT 订阅，例如：

   ```ts
   // 现状（Mock）
   useEffect(() => {
     const t = setInterval(() => dispatch({ type: 'TICK' }), 1000);
     return () => clearInterval(t);
   }, []);

   // 真实后端（示例）
   useEffect(() => {
     const ws = new WebSocket(import.meta.env.VITE_WS_ENDPOINT); // 如 wss://api.xxx.com/realtime
     ws.onmessage = (e) => dispatch({ type: 'PATCH_STATE', payload: JSON.parse(e.data) });
     return () => ws.close();
   }, []);
   ```

2. **新增 `PATCH_STATE` reducer 分支**：后端字段（点云数量、GNSS 状态、任务进度、机器人位姿…）直接合并进 `PlatformState`，UI 无需改动。

3. **替换静态数据**：把 `src/data/mockData.ts` 的常量换成 `fetch('/api/...')` 返回值（或 React Query / SWR 缓存），保持导出名一致即可零改动。建议映射：
   - `/api/city/buildings` → `BUILDINGS`（含 id / 坐标 / 高度 / 面积 / 点云数量）
   - `/api/gnss/control-points` → `GNSS_POINTS`
   - `/api/tasks` → `TASK_SEED`（任务增删改 → `TASK_SEED` → 状态机）
   - `/api/survey/result` → `RESULT_FIELDS` / `RESULT_FILES`
4. **三维场景接真实数据**：`src/utils/cityScene.ts` 的 `createCityScene()` 中，建筑由 `BUILDINGS` 生成 → 可替换为 3D Tiles / glTF / GeoJSON 白模加载（`Cesium3DTileset`、`GLTFLoader`、`OBJLoader` 均可直接接入），道路可换成真实矢量路网。
5. **导出按钮接真实下载**：`src/components/MeasurementResult.tsx` 的 `onAction()` 中，把 Mock 提示替换为 `window.open(fileUrl)` 或 `fetch` 下载接口。
6. **语音指令接真实 ASR/NLU**：`src/components/VoiceCommand.tsx` 的 `runVoice()` 中，用 `MediaRecorder` + ASR 服务替换定时器模拟，返回的指令文本继续走同一套 `VOICE_FLOW` 链路与 `dispatch` 调度。
7. **环境变量**：在项目根目录新建 `.env.local`，如 `VITE_API_BASE=https://api.example.com`、`VITE_WS_ENDPOINT=wss://api.example.com/realtime`，通过 `import.meta.env.VITE_*` 读取。

---

## 七、目录结构

```
├─ index.html
├─ vite.config.ts / tailwind.config.js / postcss.config.js / tsconfig*.json
├─ scripts/smoke.ts              # Mock 数据 + 仿真 + 演示时间轴自检
└─ src
   ├─ main.tsx / App.tsx / index.css / types.ts
   ├─ components
   │  ├─ Header.tsx               # 顶部导航 + 实时时钟 + 系统状态
   │  ├─ LeftAnalytics.tsx        # 左侧：6 张数据卡 + AI空间智能分析 + 智能处理流程
   │  ├─ CityTwin.tsx             # 中央：城市三维数字孪生（Three.js 交互）
   │  ├─ TaskCenter.tsx           # 右侧：AI 任务调度 + 应急测绘能力
   │  ├─ VoiceCommand.tsx         # 右侧：AI 语音指令
   │  ├─ DeviceStatus.tsx         # 右侧：三端协同 + 云通信链路 + 云端算力
   │  ├─ MeasurementResult.tsx    # 测绘成果标准化交付抽屉
   │  ├─ DemoMode.tsx             # 3 分钟答辩演示模式
   │  ├─ BottomStatus.tsx         # 底部测绘数据状态栏
   │  └─ ui/                      # Panel / Chip / Progress / KV / ECharts 图表等基础组件
   ├─ data/mockData.ts            # 全部 Mock 数据（唯一数据源）
   ├─ utils
   │  ├─ simulation.ts            # 仿真引擎：状态初始化 / 实时漂移 / 演示时间轴
   │  └─ cityScene.ts             # Three.js 城市场景构建器
   ├─ store/PlatformContext.tsx   # 全局状态中枢（reducer + 1 Hz 心跳）
   └─ hooks/                      # useECharts / useCountUp（数字滚动）
```

## 八、技术栈

React 18 · TypeScript 5 · Vite 6 · Tailwind CSS 3 · ECharts 5 · Three.js（OrbitControls）· Lucide React
